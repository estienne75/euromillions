/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.listener;

import euromillions.event.NumberGridEvent;
import java.util.EventListener;
/**
 *
 * @author Stéphane
 */
public interface CycleNumberGridListener extends EventListener {

    /**
     *
     * @param nge
     */
    public void cyleNumberNewGrid(NumberGridEvent nge);
    public void cycleNumberGridRemoved();
}

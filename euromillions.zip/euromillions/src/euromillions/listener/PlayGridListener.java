/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.listener;

import euromillions.event.PlayGridEvent;
import euromillions.event.PlayedGridEvent;
import java.util.EventListener;
/**
 *
 * @author Stéphane
 */
public interface PlayGridListener extends EventListener {

    /**
     *
     * @param pge
     */
    public void PlayGridChange(PlayGridEvent pge);
    public void newPlayedGridSet();
    public void endPlayedGridSet();
    public void PlayedGridFeched(PlayedGridEvent pge);
}

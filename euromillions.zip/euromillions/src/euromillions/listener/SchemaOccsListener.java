/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.listener;

import euromillions.event.SchemaOccsEvent;
import java.util.EventListener;
/**
 *
 * @author Stéphane
 */
public interface SchemaOccsListener extends EventListener {

    /**
     *
     * @param soe
     */
    public void newSchemasInProgress();
    public void newSchema(SchemaOccsEvent soe);
}

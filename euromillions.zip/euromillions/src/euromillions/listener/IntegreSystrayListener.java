/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.listener;

import euromillions.event.IntegreSystrayMessageEvent;
import java.util.EventListener;

/**
 *
 * @author Stéphane
 */
public interface IntegreSystrayListener extends EventListener {
    public void SystrayMessage(IntegreSystrayMessageEvent ime);
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.listener;

import euromillions.event.SynthesesAvTirageEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import euromillions.event.SynthesesNbTirageEvent;
import java.util.EventListener;
/**
 *
 * @author Stéphane
 */
public interface DrawListener extends EventListener {

    /**
     *
     * @param nte
     */
    public void NewDrawRow(DrawEvent nte);
    public void EndDraw(DrawEvent nte);
    public void DrawBallSelected(DrawBallEvent tbe);
    public void StatNbDraw(SynthesesNbTirageEvent snte);
    public void StatAvNbDraw(SynthesesAvTirageEvent sate);
    public void StatNbDrawE(SynthesesNbTirageEvent snte);
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.listener;



import euromillions.event.DateEvent;
import euromillions.event.GrouppEvent;
import java.util.EventListener;
/**
 *
 * @author Stéphane
 */
public interface DateDetailRowListener extends EventListener {

    /**
     *
     * @param dce
     */
    public void dateDetailRowSelected(DateEvent dce);
}

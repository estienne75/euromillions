/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.listener;



import euromillions.event.MHMIHideEvent;
import euromillions.event.MHMIShowEvent;
import java.util.EventListener;
/**
 *
 * @author Stéphane
 */
public interface MHMIListener extends EventListener {

    /**
     *
     * @param mhmie
     */
    public void hideMHMI(MHMIHideEvent mhmie);

    /**
     *
     * @param mhmie
     */
    public void showMHMI(MHMIShowEvent mhmie);
}

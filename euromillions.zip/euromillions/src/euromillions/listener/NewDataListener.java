/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.listener;

import java.util.EventListener;

/**
 *
 * @author Stéphane
 */
public interface NewDataListener extends EventListener {
    public void newCycleDate();
    public void newNumber();
    public void newLinearGap();
    public void newTirage();
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.listener;


import euromillions.event.SynthesisEvent;
import java.util.EventListener;
/**
 *
 * @author Stéphane
 */
public interface SynthesisListener extends EventListener {
    public void SyntheseCycles(SynthesisEvent se);
}

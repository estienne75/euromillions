/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.listener;



import euromillions.event.DateEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import java.util.EventListener;
/**
 *
 * @author Stéphane
 */
public interface IntegrationListener extends EventListener {

    /**
     *
     * @param ie
     */
    public void integrationStart(IntegrationEvent ie);

    /**
     *
     * @param ie
     */
    public void integrationEnd(IntegrationEvent ie);

    public void integrationAddGrpRow(GrouppEvent gce);

    public void integrationAddDateRow(DateEvent dce);
}

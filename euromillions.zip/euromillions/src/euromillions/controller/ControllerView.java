/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.controller;

import euromillions.listener.DateDetailRowListener;
import euromillions.listener.MHMIListener;
import euromillions.model.ModelView;
import euromillions.view.MainHMI;
import euromillions.view.SysTray;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import euromillions.listener.GrpDetailRowListener;
import euromillions.listener.IntegreSystrayListener;
import java.awt.GridBagLayout;
import javax.swing.JFrame;

/**
 *
 * @author Stéphane
 */
public final class ControllerView {

    private         ModelView   mdlvw;
    private         Controller  ctrlr;

    private final   GridBagLayout       grdBgLyt;
    private final   SysTray     systray;
    private final   MainHMI     mhmi;

    public ControllerView(ModelView _mdlvw, Controller _ctrlr) {
        mdlvw =_mdlvw;
        ctrlr = _ctrlr;

        // Installe l'apparence Nimbus.
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
            //UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        } catch (UnsupportedLookAndFeelException    |
                IllegalAccessException              |
                InstantiationException              |
                ClassNotFoundException ex) {
            System.err.println("Pas de Nimbus! Tant pis pour vos yeux.");
            System.exit(-1);
        }

        mhmi = new MainHMI(_ctrlr, this);
        mhmi.setSize(mhmi.getToolkit().getScreenSize());
        //mhmi.setPreferredSize(mhmi.getToolkit().getScreenSize());
        mhmi.setExtendedState(JFrame.MAXIMIZED_BOTH);

        grdBgLyt    =   new GridBagLayout();
        mhmi.setLayout(grdBgLyt);



        mhmi.addWindowListener(mhmi);
        addMHMIListener(mhmi);

        systray = new SysTray(this, _ctrlr);
        addIntegreSystrayListener(systray);

        if(systray.show()) {
            mdlvw.showMHMI(this);
       }
    }

    public void makeIHM() {
        mhmi.makeIHM();
    }

    // Invocation du controleur.
    // --------------------------
    public void integre() {
        mdlvw.integre();
    }

    private void addIntegreSystrayListener(IntegreSystrayListener _lstnr) {
        mdlvw.addIntegrationDialogListener(_lstnr);
    }

    public void addCycleDetailrowListener(GrpDetailRowListener _cdrl) {
        mdlvw.addGrpDetailRowListener(_cdrl);
    }

    public void grpDetailRowSelected(Object _obj,
                                      String _nbCycle,
                                      String _nbTirage,
                                      String _cycleType) {
        mdlvw.grpDetailRowSelected(_obj, _nbCycle, _nbTirage, _cycleType);
    }

    public void addDateDetailRowListener(DateDetailRowListener _listener) {
        mdlvw.addDateDetailRowListener(_listener);
    }

    public void dateDetailRowSelected(  Object  _obj,
                                        String  _begindate,
                                        String  _enddate,
                                        String  _cycletype) {
        mdlvw.dateDetailRowSelected(_obj, _begindate, _enddate, _cycletype);
    }

    public void addMHMIListener(MHMIListener _lstnr) {
        mdlvw.addMHMIListener(_lstnr);
    }

    public void showMHMI(Object _obj) {
        mdlvw.showMHMI(_obj);
    }

    public void hideMHMI(Object _obj) {
        mdlvw.hideMHMI(_obj);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.controller;

import euromillions.listener.CycleNumberGridListener;
import euromillions.listener.DateDetailRowListener;
import euromillions.listener.IntegrationListener;
import euromillions.listener.NewDataListener;
import euromillions.model.Model;
import euromillions.listener.GrpDetailRowListener;
import euromillions.listener.DateSecondaryListener;
import euromillions.listener.SynthesisListener;
import euromillions.listener.DrawListener;
import euromillions.listener.PlayGridListener;
import euromillions.view.schemas.PnlSchemasList;
import org.joda.time.DateTime;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class Controller {
    private final Model     mdl;
    private ControllerView  ctrlrvw;

    public Controller(Model _mdl) {
       mdl      = _mdl;
    }

    public void setControllerView(ControllerView _ctrlrvw) {
        ctrlrvw = _ctrlrvw;
    }

    public void exit() {
        mdl.exit();
        System.exit(0);
    }

    public void conserve(boolean _conserve) {
        mdl.conserveSelectBall(_conserve);
    }

    public void reset(Object _obj) {
        mdl.resetSelectedball(_obj);
    }

    public void addDateSecondaryCycle(DateSecondaryListener _l) {
        mdl.addDateSecondaryCycle(_l);
    }
    public void cycleDateSecondaryCycle(Object _obj, boolean _selected) {
        mdl.DateSecondaryCycle(_obj, _selected);
    }

    public void removeDateSecondaryCycle(DateSecondaryListener _l) {
        mdl.removeDateSecondaryCycle(_l);
    }

    public void addIntegrationListener(IntegrationListener _il) {
        mdl.addIntegrationListener(_il);
    }

    public void Integre(Object _obj) {
        mdl.Integre(_obj);
    }

    public void getGrouppsCycle(Object _obj) {
        mdl.getGrouppsCycle(_obj);
    }

    public void addCycleDetailRowListener(GrpDetailRowListener _lstnr) {
        ctrlrvw.addCycleDetailrowListener(_lstnr);
    }

    public void grpDetailRowSelected(Object _obj,
                                      String _nbCycle,
                                      String _nbTirage,
                                      String _cycleType) {
        ctrlrvw.grpDetailRowSelected(_obj, _nbCycle, _nbTirage, _cycleType);
        mdl.grpDetailRowSelected(_obj, _nbCycle, _nbTirage, _cycleType);
    }

    public void addDateDetailRowListener(DateDetailRowListener _listener) {
        ctrlrvw.addDateDetailRowListener(_listener);
    }

    public void cyleDateDetailRowSelected(  Object _obj,
                                            String _begindate,
                                            String _enddate,
                                            String _cycletype,
                                            String _nbtirage) {
        ctrlrvw.dateDetailRowSelected(_obj, _begindate, _enddate, _cycletype);
        mdl.getCycleNumbers(_obj, _begindate, _enddate, _cycletype, _nbtirage);
    }

    public void addTirageListener(DrawListener _tl) {
        mdl.addDrawListener(_tl);
    }

    public void removeTirageListener(DrawListener _tl) {
        mdl.removeDrawListener(_tl);
    }

    public void addSynthesisListener(SynthesisListener _synthlistnr) {
        mdl.addSynthesisListener(_synthlistnr);
    }

    public void removeSynthesisListener(SynthesisListener _synthlistnr) {
        mdl.removeSynthesisListener(_synthlistnr);
    }

    public void addNewDataListener(NewDataListener _nwdtalstnr) {
        mdl.addNewDataListener(_nwdtalstnr);
    }

    public void addCycleNumberGridListener(CycleNumberGridListener _cngl) {
        mdl.addCycleNumberGridListener(_cngl);
    }

    public void numberGridReseted() {
        mdl.numberGridReseted();
    }

    public void selectBall(Object _obj, String _ballnumber) {
        mdl.selectBall(_obj, _ballnumber);
    }

    public void playGridStarSelected(   Object _obj,
                                        String _starnum,
                                        boolean _starselected) {
        mdl.playGridStarSelected(_obj, _starnum, _starselected);
    }


    public void addPlayGridListener(PlayGridListener _pgl) {
        mdl.addPlayGridListener(_pgl);
    }

    public void removePalyGridListener(PlayGridListener _pgl) {
        mdl.removePlayGridListener(_pgl);
    }

    public void validatePlayGrid(DateTime _dt) {
        mdl.validatePlayGrid(_dt);
    }

    public void loadPlayedGrids(Object _obj) {
        mdl.loadPlayedGrids(_obj);
    }

    public void addSchemasListener(PnlSchemasList aThis) {
        mdl.addSchemaOccssisListener(aThis);
    }

    public void selectSchema(Object _obj, int _schemanumber) {
        mdl.selectSchema(_obj, _schemanumber);
    }

}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class NumberGridEvent extends EventObject{

    private final String    beginDate;
    private final String    endDate;
    private final String    cycletype;
    private final int[]     occurence;
    private final int[]     lineargap1;
    private final int[]     lineargap2;




    public NumberGridEvent( Object  _source,
                            String  _beginDate,
                            String  _endDate,
                            String  _cycletype,
                            int[]   _occ,
                            int[]   _lineargap1,
                            int[]   _lineargap2) {
        super(_source);

        beginDate   = _beginDate;
        endDate     = _endDate;
        cycletype   = _cycletype;

        occurence   = _occ;
        lineargap1  = _lineargap1;
        lineargap2  = _lineargap2;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public String getEnDate() {
        return endDate;
    }

    public String getCycleType() {
        return cycletype;
    }

    public int[] getOccurences() {
        return occurence;
    }

    public int[] getLinearGap1() {
        return lineargap1;
    }

    public int[] getLinearGap2() {
        return lineargap2;
    }
}

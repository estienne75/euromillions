/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class PlayedGridEvent extends EventObject{

    private int[] playedballs;
    private int[] playedstars;

    private String  drawdate;
    private String  playeddate;

    private int     playerid;

    private String  firstname;
    private String  lastname;

    private int     gridnumber;


    public PlayedGridEvent( Object  _source,
                            int[]   _playedballs,
                            int[]   _playedstars,
                            String  _drawdate,
                            String  _playeddate,
                            int     _plyerid,
                            String  _firstname,
                            String  _lastname,
                            int     _gridnumber) {
        super(_source);

        playedballs =   _playedballs;
        playedstars =   _playedstars;

        drawdate    =   _drawdate;

        playerid    =   _plyerid;
        playeddate  =   _playeddate;

        firstname   =   _firstname;
        lastname    =   _lastname;

        gridnumber   = _gridnumber;
    }

    public int[] getPlyedBalls() {
        return playedballs;
    }

    public int[] getPlayedStars() {
        return playedstars;
    }

    public String getDrawDate() {
        return drawdate;
    }

    public String getPlayedDate() {
        return playeddate;
    }

    public int getPlayedId() {
        return playerid;
    }

    public String getFirsName() {
        return firstname;
    }

    public String getLastName() {
        return lastname;
    }

    public int getGridNumber() {
        return gridnumber;
    }
}
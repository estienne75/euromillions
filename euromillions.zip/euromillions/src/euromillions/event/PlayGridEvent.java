/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class PlayGridEvent extends EventObject{

    private final boolean playgridvalid;

    public PlayGridEvent(Object _source, boolean _playgridvalid) {
        super(_source);
        playgridvalid = _playgridvalid;
    }

    public boolean isPlayGridValid() {
        return playgridvalid;
    }
}

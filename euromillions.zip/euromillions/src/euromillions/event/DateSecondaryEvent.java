/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class    DateSecondaryEvent extends EventObject{

    private final boolean selectedstate;

    public      DateSecondaryEvent(Object _source, boolean _selectedstate) {
        super(_source);
        selectedstate = _selectedstate;

    }

    public boolean getSelectedState() {
        return selectedstate;
    }
}

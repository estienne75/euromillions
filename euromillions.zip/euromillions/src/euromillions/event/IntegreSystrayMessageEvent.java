/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class IntegreSystrayMessageEvent extends EventObject {

    private final String message;

    public IntegreSystrayMessageEvent(Object source, String _message) {
        super(source);

        message = _message;
    }

    public String getMessage() {
        return message;
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class SynthesesAvTirageEvent extends EventObject{

    private int nbcycle,
                nbtirage;

    private final int[] avocc,
                        avgap;

    public SynthesesAvTirageEvent(  Object  _source,
                                    int     _nbcycle,
                                    int     _nbtirage,
                                    int[]   _avocc,
                                    int[]   _avgap) {

        super(_source);

        nbcycle     = _nbcycle;
        nbtirage    = _nbtirage;
        avocc       = _avocc;
        avgap       = _avgap;
    }


    public int getNbCycle() {
        return nbcycle;
    }

    public int getNbTirage() {
        return nbtirage;
    }

    public int[] getAvOcc() {
        return      avocc;
    }

    public int[] getAvGap() {
        return avgap;
    }
}

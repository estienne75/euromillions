/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class SynthesisEvent extends EventObject{
    private final Object    source;
    private boolean         selectedcycle;
    private final String    datedeb;
    private final String    datefin;
    private final String    refdatedeb;
    private final String    refdatefin;

    private final int[]     glboccurs;
    private final int[]     occ;
    private final int[]     gap;

    private final String    cycletype;
    private final int       nbcycle;
    private final int       nbtirage;

    public SynthesisEvent(  Object  _source,
                            boolean _selectedcycle,
                            String  _datedeb,
                            String  _datefin,
                            String  _refdatedeb,
                            String  _refdatefin,
                            int[]   _glbocc,
                            int[]   _occ,
                            int[]   _gap,
                            String  _cycletype,
                            int     _nbcycle,
                            int     _nbtirage) {
        super(_source);

        source = _source;

        selectedcycle   = _selectedcycle;

        datedeb     = _datedeb;
        datefin     = _datefin;
        refdatedeb  = _refdatedeb;
        refdatefin  = _refdatefin;

        glboccurs   = _glbocc;
        occ         = _occ;
        gap         = _gap;

        cycletype   = _cycletype;
        nbcycle     = _nbcycle;
        nbtirage    = _nbtirage;
    }

    public Object getSource() {
        return source;
    }
    public boolean isSelectedCycle() {
        return selectedcycle;
    }
    public String getDateDeb() {
        return datedeb;
    }
    public String getDateFin() {
        return datefin;
    }

    public String getRefDateDeb() {
        return refdatedeb;
    }

    public String getRefDateFin() {
        return refdatefin;
    }

    public int[] getGloablOccurences() {
        return glboccurs;
    }
    
    public int[] getOccurences() {
        return occ;
    }

    public int[] getLinearGap() {
        return gap;
    }


    public String getCycleType() {
        return cycletype;
    }

    public int getNbCycle() {
        return nbcycle;
    }

    public int getNbTirage() {
        return nbtirage;
    }
}

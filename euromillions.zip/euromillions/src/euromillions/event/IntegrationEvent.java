/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;


import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class IntegrationEvent extends EventObject{
    private static final long serialVersionUID = 21L;

    public IntegrationEvent(Object _source) {
        super(_source);
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class GrouppEvent extends EventObject{

    private String nbcycle;
    private String nbtirage;
    private String cycletype;


    public GrouppEvent(Object _source, String _nbcycle, String _nbtirage, String _cycletype) {
        super(_source);

        cycletype   = _cycletype;
        nbcycle     = _nbcycle;
        nbtirage    = _nbtirage;
    }

    public String getNbCycle() {
        return nbcycle;
    }

    public String getNbTirage() {
        return nbtirage;
    }

    public String getCycleType() {
        return cycletype;
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class DrawBallEvent extends EventObject{

    private final String    ballnumber;
    private final boolean   ballstatus;

    public DrawBallEvent(   Object  _source,
                            String  _ballNumber,
                            boolean _ballsataus) {
        super(_source);

        ballnumber  = _ballNumber;
        ballstatus  = _ballsataus;
    }

    public String getBallNumber() {
        return ballnumber;
    }

    public boolean getBallStatus() {
        return ballstatus;
    }
}

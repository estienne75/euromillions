/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class DateEvent extends EventObject{

    private final String beginDate;
    private final String endDate;
    private final String cycleType;
    private final String nbtirage;


    public DateEvent(Object _source,
                          String _beginDate,
                          String _endDate,
                          String _cycleType,
                          String _nbtirage) {
        super(_source);

        beginDate   = _beginDate;
        endDate     = _endDate;
        cycleType   = _cycleType;
        nbtirage    = _nbtirage;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public String getEnDate() {
        return endDate;
    }

    public String getCycleType() {
        return cycleType;
    }

    public String getNbTirage() {
        return nbtirage;
    }
}

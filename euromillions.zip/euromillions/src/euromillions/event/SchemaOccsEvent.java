/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class SchemaOccsEvent extends EventObject{

    private final String    cycletype;
    private final String    drawdate;
    private final String    startdate;
    private final String    enddate;
    private final String    refstartdate;
    private final String    refenddate;
    private final long      schemaweight;
    private final int[]     schemaoccs;


    public SchemaOccsEvent( Object  _source,
                            String  _cycletype,
                            String  _drawdate,
                            String  _startDate,
                            String  _endDate,
                            String  _refstartdate,
                            String  _refenddate,
                            int[]   _schemaoccs,
                            long    _schemaweight) {
        super(_source);

        cycletype       = _cycletype;
        drawdate        = _drawdate;
        startdate       = _startDate;
        enddate         = _endDate;
        refstartdate    = _refstartdate;
        refenddate      = _refenddate;
        schemaoccs      = _schemaoccs;
        schemaweight    = _schemaweight;
    }

    public String getCycleType() {
        return cycletype;
    }
    public String getDrawDate() {
        return drawdate;
    }

    public String getStartDate() {
        return startdate;
    }

    public String getEndDate() {
        return enddate;
    }

    public String getRefStartDate() {
        return refstartdate;
    }

    public String getRedEndDate() {
        return refenddate;
    }

    public int[] getSchemaOccs() {
        return schemaoccs;
    }

    public long getSchemaWeight() {
        return schemaweight;
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class SynthesesNbTirageEvent extends EventObject{

    private final int   nbtirage;
    private final int[] aocc,
                        agap;
    private String      startdate,
                        enddate;
    
    public SynthesesNbTirageEvent(   Object  _source,
                                int     _nbtirage,
                                int[]   _aocc,
                                int[]   _agap,
                                String _startdate,
                                String _enddate) {
        super(_source);

        nbtirage    =   _nbtirage;
        aocc        =   _aocc;
        agap        =   _agap;
        startdate   =   _startdate;
        enddate     =   _enddate;
    }
    
    public int getNbTirage() {
        return nbtirage;
    }
    
    public int[] getAOcc() {
        return      aocc;
    }
    
    public int[] getAGap() {
        return agap;
    }
    
    public String getStartDate() {
        return startdate;
    }
    
    public String getEndDate() {
        return enddate;
    }
}

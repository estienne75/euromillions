/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.event;

import java.util.EventObject;

/**
 *
 * @author Stéphane
 */
public class DrawEvent extends EventObject{

    private final String    firstdate;
    private final String    dateTirage;
    private final int[]     boules;
    private final int[]     occurence;
    private final int[]     lineargapstart;
    private final int[]     lineargapsend;
    private final int       rowcount;

    public DrawEvent( Object  _source,
                        String  _firstdate,
                        String  _datetirage,
                        int[]   _boules,
                        int[]   _occ,
                        int[]   _lineatgapstart,
                        int[]   _lineargapsend,
                        int     _rowcount) {
        super(_source);

        firstdate       = _firstdate;
        dateTirage      = _datetirage;

        boules          = _boules;
        occurence       = _occ;
        lineargapstart  = _lineatgapstart;
        lineargapsend   = _lineargapsend;
        rowcount        = _rowcount;
    }

    public String getFirstDate() {
        return firstdate;
    }
    public String getDateTirage() {
        return dateTirage;
    }

    public int[] getBoules() {
        return boules;
    }

    public int[] getOccurences() {
        return occurence;
    }

    public int[] getLinearGapStart() {
        return lineargapstart;
    }
    public int[] getLinearGapEnd() {
        return lineargapsend;
    }

    public int getRowCount() {
        return rowcount;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions;

//import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;
import euromillions.model.ModelView;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class EuromillionsIntergre {
    /**
     * @param _conn Connection to euromillions database shema.
     * @param _modelvw
     */
    public void integre(Connection _conn, ModelView _modelvw) {
        // TODO code application logic here

        Connection conn = _conn;

        if(conn != null) {
            File file2004 = new File("C:\\Users\\steph\\Downloads\\euromillions_2004_2011\\euromillions.csv");
            File file2011 = new File("C:\\Users\\steph\\Downloads\\euromillions_2011_2014\\euromillions_2.csv");
            File file2014 = new File("C:\\Users\\steph\\Downloads\\euromillions_2014_2016\\euromillions_3.csv");
            File file2016 = new File("C:\\Users\\steph\\Downloads\\euromillions_2016_++\\euromillions_4.csv");

            try {
                Statement sttmnt;
                sttmnt = conn.createStatement();

                System.out.println("Remise à plat de la base.");
                _modelvw.sendMessageToSystray(this, "Remise à plat de la base");
                sttmnt.executeUpdate("delete from cycles_head");
                sttmnt.executeUpdate("delete from euromillions");
                sttmnt.executeUpdate("delete from grpnbtirage");
                sttmnt.executeUpdate("delete from lineargap");
                sttmnt.executeUpdate("delete from schemaoccs");
                sttmnt.executeUpdate("delete from synthese");
            } catch (SQLException ex) {
                Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.SEVERE, null, ex);
            }

            try {
                System.out.println("Intègre 2004-2011.");
                _modelvw.sendMessageToSystray(this, "Intègre 2004-2011");
                integreFiles(conn, file2004);

                System.out.println("Intègre 2011-2014.");
                _modelvw.sendMessageToSystray(this, "Intègre 2011-2014");
                integreFiles(conn, file2011);

                System.out.println("Intègre 2014 2016.");
                _modelvw.sendMessageToSystray(this, "Intègre 2014 2016");
                integreFiles(conn, file2014);

                System.out.println("Intègre 2016 ++.");
                _modelvw.sendMessageToSystray(this, "Intègre 2016 ++");
                integreFiles(conn, file2016);
            } catch (FileNotFoundException ex) {
                try {
                    conn.close();
                } catch (SQLException ex1) {
                    Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex1);
                    return;
                }

                Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex);
                return;
            }

            System.out.println("Ecarts linéaires.");
            _modelvw.sendMessageToSystray(this, "Ecarts linéaires.");
            linearGap(conn);

            System.out.println("Recherche des cycles primaires, secondaires et en cours.");
            _modelvw.sendMessageToSystray(this, "Recherche des cycles primaires, secondaires et en cours.");
            findCycles(conn, _modelvw);

            System.out.println("Evaluation des schémas.");
            _modelvw.sendMessageToSystray(this, "Evaluation des schémas.");
            prepareSchema(conn, _modelvw);

            System.out.println("Grouppage des cycles par nombre de tirage.");
            _modelvw.sendMessageToSystray(this, "Grouppage des cycles par nombre de tirage.");
            grpCycles(conn, _modelvw);

            System.out.println("Synthèse des Occurences et des Ecarts linéaires par nombre de tirage.");
            _modelvw.sendMessageToSystray(this, "Synthèse des Occurences et des Ecarts linéaires par nombre de tirage.");
            synthesisGrp(conn, _modelvw);

            System.out.println("Synthèse des Occurences et des Ecarts linéaires du cycle en cours.");
            _modelvw.sendMessageToSystray(this, "Synthèse des Occurences et des Ecarts linéaires du cycle en cours.");
            synthesisOfCycleInProgress(conn, _modelvw);
        }
    }

    /*-----------------------*/
    /*- i n t e g r e (...) -*/
    /*-----------------------*/
    private void integreFiles(Connection _conn, File _file) throws FileNotFoundException {
        File file;
        RandomAccessFile raf;

        raf = new RandomAccessFile(_file, "r");

        String line;
        boolean boolrang13      = false;
        boolean booleuroplus    = false;
        int linenum = 0;

        try {
            while( (line = raf.readLine()) != null) {
                linenum++;
                if(line.contains("annee_numero_de_tirage")) {
                    if(line.contains("rang13")) {
                        boolrang13 = true;

                        if(line.contains("Etoile+"))
                            booleuroplus = true;
                        else
                            booleuroplus = false;
                    }
                    else
                        boolrang13 = false;

                    continue;
                }

                if(!insert(_conn, line.trim(), boolrang13, booleuroplus, linenum))
                    break;
            }



        } catch (IOException ex) {
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex);
        }

        try {
            raf.close();
        } catch (IOException ex) {
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex);
        }
    }

    private boolean insert(Connection _conn, String _line, boolean _rang13, boolean _booleuroplus, int _linenum) {
        int idx1=0;
        int idx2=0;
        int idx3=0;

        /*----*/
        String  anneenum = null, nomjour = null, datetirage = null, dateforclusion = null,
                boule1, boule2, boule3, boule4, boule5, etoile1, etoile2,
                tirboulecroi, tiretoilcroi,
                nbgagn01fr, nbgagn01eu, rapport01, nbgagn02fr, nbgagn02eu, rapport02,
                nbgagn03fr, nbgagn03eu, rapport03, nbgagn04fr, nbgagn04eu, rapport04,
                nbgagn05fr, nbgagn05eu, rapport05, nbgagn06fr, nbgagn06eu, rapport06,
                nbgagn07fr, nbgagn07eu, rapport07, nbgagn08fr, nbgagn08eu, rapport08,
                nbgagn09fr, nbgagn09eu, rapport09, nbgagn10fr, nbgagn10eu, rapport10,
                nbgagn11fr, nbgagn11eu, rapport11, nbgagn12fr, nbgagn12eu, rapport12,
                nbgagn13fr="0", nbgagn13eu="0", rapport13="0.00",
                jocker, devise;
        /*----*/

        // anneenum - Année et numéro de tirage dans l'année.
        // --------------------------------------------------
        idx2 = _line.indexOf(";", idx1);

        if(idx2>0)
            anneenum = _line.substring(idx1, idx2);

        // nomjour - Nom du jour de la semaine "MA", "VE".
        // -----------------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        if(idx2>0)
            nomjour = _line.substring(idx1, idx2); // Peut être le noçm du jour complêt ou abrégé sur les deux premiers caractère..

        nomjour = nomjour.substring(0, 2); // Dans tous les cas il n'est retenu que les 2 premiers caractères.


        // datetirage - Date iso (aaaa-mm-jj) du tirage.
        // ---------------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        if(idx2>0)
            datetirage  = _line.substring(idx1, idx2);


        if(_rang13) {
            try {
                datetirage  = datetirage.substring(6, 10)   + '-'
                            + datetirage.substring(3, 5)    + '-'
                            + datetirage.substring(0, 2);
            }
            catch(StringIndexOutOfBoundsException siobe) {
                System.err.println("Erreur siobe ligne: " + _linenum + " : " + datetirage + "\n" + _line + "\n" + siobe.toString());
                return false;
            }
        }
        else {
            datetirage  = datetirage.substring(0, 4) + '-'
                        + datetirage.substring(4, 6) + '-'
                        + datetirage.substring(6, 8);
        }

        // Numéro de tirage.
        // -----------------
        if(_booleuroplus) {
            idx1 = idx2+1;
            idx2 = _line.indexOf(";", idx1);
        }

        // dateforclusion - Date iso (aaaa-mm-jj) de forclusion des gains.
        // ---------------------------------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        if(idx2>0)
            dateforclusion  = _line.substring(idx1, idx2);


        if(_rang13) {
            dateforclusion  = dateforclusion.substring(6, 10)   + '-'
                            + dateforclusion.substring(3, 5)    + '-'
                            + dateforclusion.substring(0, 2);
        }
        else {
            dateforclusion  = dateforclusion.substring(0, 4)    + '-'
                            + dateforclusion.substring(4, 6)    + '-'
                            + dateforclusion.substring(6, 8);
        }

        // Boule 1.
        // --------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        boule1 = _line.substring(idx1, idx2);

        if(boule1.length() == 1)
            boule1 = "0" + _line.substring(idx1, idx2);

        // Boule 2.
        // --------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        boule2 = _line.substring(idx1, idx2);

        if(boule2.length() == 1)
            boule2 = "0" + _line.substring(idx1, idx2);

        // Boule 3.
        // --------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        boule3 = _line.substring(idx1, idx2);

        if(boule3.length() == 1)
            boule3 = "0" + _line.substring(idx1, idx2);

        // Boule 4.
        // --------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        boule4 = _line.substring(idx1, idx2);

        if(boule4.length() == 1)
            boule4 = "0" + _line.substring(idx1, idx2);

        // Boule 5.
        // --------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        boule5 = _line.substring(idx1, idx2);

        if(boule5.length() == 1)
            boule5 = "0" + _line.substring(idx1, idx2);

        // Etoile 1.
        // ---------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        etoile1 = _line.substring(idx1, idx2);

        if(etoile1.length() == 1)
            etoile1 = "0" + _line.substring(idx1, idx2);

        // Etoile 2.
        // ---------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        etoile2 = _line.substring(idx1, idx2);

        if(etoile2.length() == 1)
            etoile2 = "0" + _line.substring(idx1, idx2);

        // Boules par ordre croissant.
        // ---------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        tirboulecroi = _line.substring(idx1, idx2);

        // Etoiles par ordre croissant.
        // ----------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        tiretoilcroi = _line.substring(idx1, idx2);

        // Nombre de gagnant au 1er rang en france.
        // ----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn01fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 1er rang en europe.
        // ----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn01eu = _line.substring(idx1, idx2);

        // Rapport du 1er rang.
        // --------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport01 = _line.substring(idx1, idx2);

        idx3 = rapport01.indexOf(",");

        if(idx3 >=0)
            rapport01 = rapport01.replace(',', '.');
        else
            rapport01 = rapport01 + ".00";

        // Nombre de gagnant au 2ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn02fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 2ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn02eu = _line.substring(idx1, idx2);

        // Rapport du 2ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport02 = _line.substring(idx1, idx2);

        idx3 = rapport02.indexOf(",");

        if(idx3 >=0)
            rapport02 = rapport02.replace(',', '.');
        else
            rapport02 = rapport02 + ".00";

        // Nombre de gagnant au 3ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn03fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 3ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn03eu = _line.substring(idx1, idx2);

        // Rapport du 3ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport03 = _line.substring(idx1, idx2);

        idx3 = rapport03.indexOf(",");

        if(idx3 >=0)
            rapport03 = rapport03.replace(',', '.');
        else
            rapport03 = rapport03 + ".00";

        // Nombre de gagnant au 4ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn04fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 4ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn04eu = _line.substring(idx1, idx2);

        // Rapport du 4ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport04 = _line.substring(idx1, idx2);

        idx3 = rapport04.indexOf(",");

        if(idx3 >=0)
            rapport04 = rapport04.replace(',', '.');
        else
            rapport04 = rapport04 + ".00";

        // Nombre de gagnant au 5ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn05fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 5ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn05eu = _line.substring(idx1, idx2);

        // Rapport du 5ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport05 = _line.substring(idx1, idx2);

        idx3 = rapport05.indexOf(",");

        if(idx3 >=0)
            rapport05 = rapport05.replace(',', '.');
        else
            rapport05 = rapport05 + ".00";

        // Nombre de gagnant au 6ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn06fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 6ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn06eu = _line.substring(idx1, idx2);

        // Rapport du 6ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport06 = _line.substring(idx1, idx2);

        idx3 = rapport06.indexOf(",");

        if(idx3 >=0)
            rapport06 = rapport06.replace(',', '.');
        else
            rapport06 = rapport06 + ".00";

        // Nombre de gagnant au 7ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn07fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 7ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn07eu = _line.substring(idx1, idx2);

        // Rapport du 7ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport07 = _line.substring(idx1, idx2);

        idx3 = rapport07.indexOf(",");

        if(idx3 >=0)
            rapport07 = rapport07.replace(',', '.');
        else
            rapport07 = rapport07 + ".00";

        // Nombre de gagnant au 8ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn08fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 8ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn08eu = _line.substring(idx1, idx2);

        // Rapport du 8ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport08 = _line.substring(idx1, idx2);

        idx3 = rapport08.indexOf(",");

        if(idx3 >=0)
            rapport08 = rapport08.replace(',', '.');
        else
            rapport08 = rapport08 + ".00";

        // Nombre de gagnant au 9ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn09fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 9ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn09eu = _line.substring(idx1, idx2);

        // Rapport du 9ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport09 = _line.substring(idx1, idx2);

        idx3 = rapport09.indexOf(",");

        if(idx3 >=0)
            rapport09 = rapport09.replace(',', '.');
        else
            rapport09 = rapport09 + ".00";

        // Nombre de gagnant au 10ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn10fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 10ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn10eu = _line.substring(idx1, idx2);

        // Rapport du 10ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport10 = _line.substring(idx1, idx2);

        idx3 = rapport10.indexOf(",");

        if(idx3 >=0)
            rapport10 = rapport10.replace(',', '.');
        else
            rapport10 = rapport10 + ".00";

        // Nombre de gagnant au 11ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn11fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 11ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn11eu = _line.substring(idx1, idx2);

        // Rapport du 11ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport11 = _line.substring(idx1, idx2);

        idx3 = rapport11.indexOf(",");

        if(idx3 >=0)
            rapport11 = rapport11.replace(',', '.');
        else
            rapport11 = rapport11 + ".00";

        // Nombre de gagnant au 12ièm rang en france.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn12fr = _line.substring(idx1, idx2);

        // Nombre de gagnant au 12ièm rang en europe.
        // -----------------------------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        nbgagn12eu = _line.substring(idx1, idx2);

        // Rapport du 12ièm rang.
        // ---------------------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        rapport12 = _line.substring(idx1, idx2);

        idx3 = rapport12.indexOf(",");

        if(idx3 >=0)
            rapport12 = rapport12.replace(',', '.');
        else
            rapport12 = rapport12 + ".00";

        if(_rang13) {
            // Nombre de gagnant au 13ièm rang en france.
            // -----------------------------------------
            idx1 = idx2+1;
            idx2 = _line.indexOf(";", idx1);

            nbgagn13fr = _line.substring(idx1, idx2);

            // Nombre de gagnant au 13ièm rang en europe.
            // -----------------------------------------
            idx1 = idx2+1;
            idx2 = _line.indexOf(";", idx1);

            nbgagn13eu = _line.substring(idx1, idx2);

            // Rapport du 13ièm rang.
            // ---------------------
            idx1 = idx2+1;
            idx2 = _line.indexOf(";", idx1);

            rapport13 = _line.substring(idx1, idx2);

            idx3 = rapport13.indexOf(",");

            if(idx3 >=0)
                rapport13 = rapport13.replace(',', '.');
            else
                rapport13 = rapport13 + ".00";
        }

        jocker = " ";
        devise = "eur";

        /*
        // Etoile + (zappé)
        // ----------------

        // Jocker + (zapé)
        // --------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        jocker = _line.substring(idx1, idx2);

        devise = "eur";

        if(!_booleuroplus) {
        // Devise. (zapé)
        // -------
        idx1 = idx2+1;
        idx2 = _line.indexOf(";", idx1);

        devise = _line.substring(idx1, idx2);
        }
        */

        //------------------------------
        //- Build insert Sql statement -
        //------------------------------
        String insertinto;
        String insertvalues;

        insertinto  =   "insert into euromillions (anneenum, nomjour, datetirage, dateforclu, "
                    +   "boule1, boule2, boule3, boule4, boule5, etoile1, etoile2, trgboulecroiss, trgetoilecroiss, "
                    +   "nbgagnant01fr, nbgagnant01eu, rapport01, "
                    +   "nbgagnant02fr, nbgagnant02eu, rapport02, "
                    +   "nbgagnant03fr, nbgagnant03eu, rapport03, "
                    +   "nbgagnant04fr, nbgagnant04eu, rapport04, "
                    +   "nbgagnant05fr, nbgagnant05eu, rapport05, "
                    +   "nbgagnant06fr, nbgagnant06eu, rapport06, "
                    +   "nbgagnant07fr, nbgagnant07eu, rapport07, "
                    +   "nbgagnant08fr, nbgagnant08eu, rapport08, "
                    +   "nbgagnant09fr, nbgagnant09eu, rapport09, "
                    +   "nbgagnant10fr, nbgagnant10eu, rapport10, "
                    +   "nbgagnant11fr, nbgagnant11eu, rapport11, "
                    +   "nbgagnant12fr, nbgagnant12eu, rapport12, "
                    +   "nbgagnant13fr, nbgagnant13eu, rapport13, "
                    +   "jockerplus, devise) ";

        insertvalues    = "values ("
                        + "'" + anneenum        + "', "
                        + "'" + nomjour         + "', "
                        + "'" + datetirage      + "', "
                        + "'" + dateforclusion  + "', "
                        + "'" + boule1          + "', "
                        + "'" + boule2          + "', "
                        + "'" + boule3          + "', "
                        + "'" + boule4          + "', "
                        + "'" + boule5          + "', "
                        + "'" + etoile1         + "', "
                        + "'" + etoile2         + "', "
                        + "'" + tirboulecroi    + "', "
                        + "'" + tiretoilcroi    + "', "
                              + nbgagn01fr + ", "      + nbgagn01eu + ", "     + rapport01  + ", "
                              + nbgagn02fr + ", "      + nbgagn02eu + ", "     + rapport02  + ", "
                              + nbgagn03fr + ", "      + nbgagn03eu + ", "     + rapport03  + ", "
                              + nbgagn04fr + ", "      + nbgagn04eu + ", "     + rapport04  + ", "
                              + nbgagn05fr + ", "      + nbgagn05eu + ", "     + rapport05  + ", "
                              + nbgagn06fr + ", "      + nbgagn06eu + ", "     + rapport06  + ", "
                              + nbgagn07fr + ", "      + nbgagn07eu + ", "     + rapport07  + ", "
                              + nbgagn08fr + ", "      + nbgagn08eu + ", "     + rapport08  + ", "
                              + nbgagn09fr + ", "      + nbgagn09eu + ", "     + rapport09  + ", "
                              + nbgagn10fr + ", "      + nbgagn10eu + ", "     + rapport10  + ", "
                              + nbgagn11fr + ", "      + nbgagn11eu + ", "     + rapport11  + ", "
                              + nbgagn12fr + ", "      + nbgagn12eu + ", "     + rapport12  + ", "
                              + nbgagn13fr + ", "      + nbgagn13eu + ", "     + rapport13  + ", "
                        + "'" +  jocker    + "', "     +  "'" + devise + "')";

        String query = insertinto + insertvalues;

        Statement sttmnt;

        try {
            sttmnt = _conn.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex);
            return false;
        }

        try {
            sttmnt.execute(query);
        } catch (SQLException ex) {
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex);

            try {
                sttmnt.close();
            } catch (SQLException ex1) {
                Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex1);
            }
            return false;
        }

        try {
            sttmnt.close();
        } catch (SQLException ex1) {
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex1);
        }

        return true;
    }

    /*-----------------------------*/
    /*- f i n d C y c l e s (...) -*/
    /*-----------------------------*/
    private boolean findCycles(Connection _conn, ModelView _mdlvw) {
        long newcycle_mask      = 0b0000000000000011111111111111111111111111111111111111111111111111L,
             currentcycle_mask  = 0b0000000000000000000000000000000000000000000000000000000000000000L;
        boolean query=true, secondread=false;
        int nbtirage=0, nbcyle=0;
        String firstdate            = null;
        String datefrom             = "0001-01-01";
        String lastdate             = null;
        String previouslastdate     = "0001-01-01";
        String refdebcycle          = null, reffincycle = null;
        String cycletype            = null;
        String previouscycletype    = "P";

        Statement sttmnt = null;

        try {
            sttmnt =  _conn.createStatement();

            String query_nbofrows = "select count(*) from cycles_head";
            int nbofrows;

            sttmnt.execute(query_nbofrows);
            nbofrows = sttmnt.getFetchSize();
            sttmnt.close();

            String querycycle;

            if(nbofrows>0) {
                sttmnt = _conn.createStatement();

                String querycycles_e = "delete from cycles_head "
                                    + "where cycletype = 'E'";
                sttmnt.execute(querycycles_e);
                sttmnt.close();

                String querymaxdate = "select max(debcycle) from cycles_head";

                sttmnt.execute(querymaxdate);

                if(sttmnt.getFetchSize()>0) {
                    datefrom = sttmnt.getResultSet().getString(0);
                }

                if(!datefrom.equalsIgnoreCase("0001-01-01"))
                    querycycle  = "select * from euromillions "
                                + "where datetirage > '" + datefrom + "' "
                                + "order by datetirage ";
                else
                    querycycle  = "select * from euromillions "
                                + "order by datetirage ";
            }
            else {
                querycycle  = "select * from euromillions "
                            + "order by datetirage ";
            }

            sttmnt.close();

            ResultSet rseuromillions;
            int[]   occurs  = new int[50];
            int[]   schemat = new int[5];

            query:
            while(query) {
                sttmnt = _conn.createStatement();
                rseuromillions = sttmnt.executeQuery(querycycle);
                nbtirage = 0;

                cycle:
                while(rseuromillions.next()) {
                    lastdate = rseuromillions.getString("datetirage");

                    if(secondread) {
                        datefrom = rseuromillions.getString("datetirage");
                        secondread = false;
                    }

                    if(rseuromillions.isFirst()) {
                        nbtirage=1;
                        cycletype = "E";
                        datefrom = "0001-01-01";
                        firstdate = rseuromillions.getString("datetirage");
                        secondread  = true;

                        for(int i = 0; i<50; i++) {
                            occurs[i] = 0;
                        }
                    }

                    int iboule1, iboule2, iboule3, iboule4, iboule5;
                    String sboule1, sboule2, sboule3, sboule4, sboule5;

                    iboule1 = Integer.parseInt((sboule1 = rseuromillions.getString("boule1")));
                    iboule2 = Integer.parseInt((sboule2 = rseuromillions.getString("boule2")));
                    iboule3 = Integer.parseInt((sboule3 = rseuromillions.getString("boule3")));
                    iboule4 = Integer.parseInt((sboule4 = rseuromillions.getString("boule4")));
                    iboule5 = Integer.parseInt((sboule5 = rseuromillions.getString("boule5")));

                    currentcycle_mask |= 1L<<(iboule1-1);
                    currentcycle_mask |= 1L<<(iboule2-1);
                    currentcycle_mask |= 1L<<(iboule3-1);
                    currentcycle_mask |= 1L<<(iboule4-1);
                    currentcycle_mask |= 1L<<(iboule5-1);

                    if(currentcycle_mask == newcycle_mask) {
                        currentcycle_mask = 0L;
                        nbtirage    += 1;
                        nbcyle      += 1;

                        if(previouslastdate.equalsIgnoreCase("0001-01-01")) {
                            cycletype = "P";
                            previouscycletype = cycletype;
                            refdebcycle = firstdate;
                            reffincycle = lastdate;
                        }
                        else if(previouslastdate.equalsIgnoreCase(rseuromillions.getString("datetirage"))) {
                            cycletype = "S";
                            previouscycletype = cycletype;

                            // refdebcycle = ---> Donné précédement dans le <else> qui suit
                            //                    puisqu'un cycle primaire ('P') est déduit avant
                            //                    un cycle secondaire.
                            // -------------------------------------------------------------------
                        }
                        else {
                            cycletype = "P";
                            previouscycletype = cycletype;
                            refdebcycle = firstdate;
                            reffincycle = lastdate;
                        }

                        previouslastdate = rseuromillions.getString("datetirage");

                        occurs[(iboule1-1)] += 1;
                        occurs[(iboule2-1)] += 1;
                        occurs[(iboule3-1)] += 1;
                        occurs[(iboule4-1)] += 1;
                        occurs[(iboule5-1)] += 1;

                        // Insert section in cycles_head table.
                        // ------------------------------------
                        String queryinsert;

                        queryinsert ="insert into cycles_head values("  +   "'" +   firstdate           + "', "
                                                                        +   "'" +   previouslastdate    + "', "
                                                                        +   "'" +   refdebcycle         + "', "
                                                                        +   "'" +   reffincycle         + "', "
                                                                        +   "'" +   cycletype           + "', "
                                                                        + nbtirage + ", 0, "; // nbtirage, nbintercycle

                        for(int i=0; i<50; i++) {
                            queryinsert = queryinsert + occurs[i] + ", ";
                        }

                        StringBuilder sbld = new StringBuilder(queryinsert);
                        sbld.replace(queryinsert.length()-2, queryinsert.length(), ")");

                        queryinsert = sbld.toString();

                        try (Statement sttinsert = _conn.createStatement()) {
                            sttinsert.execute(queryinsert);
                            sttinsert.close();
                        }

                        // Recherche le prochain cycle à partir de <datefrom>.
                        // ---------------------------------------------------
                        querycycle  = "select * from euromillions "
                                    + "where datetirage >= '" + datefrom + "' "
                                    + "order by datetirage ";

                        sttmnt.close();

                        continue query; // execute <querycycle> pour rechercher le cycle suivant.
                    }
                    else {
                        if(!secondread)
                            nbtirage  += 1;

                        occurs[(iboule1-1)] += 1;
                        occurs[(iboule2-1)] += 1;
                        occurs[(iboule3-1)] += 1;
                        occurs[(iboule4-1)] += 1;
                        occurs[(iboule5-1)] += 1;
                    }
                }

                if(cycletype.equalsIgnoreCase("E")) {
                    previouscycletype = cycletype;

                    // insert in cycle_head table.
                    // ---------------------------
                    String queryinsert;

                    //queryinsert ="insert into cycles_head values("  +   "'" +   (datefrom.equalsIgnoreCase("0001-01-01")? lastdate: datefrom)   + "', "
                    queryinsert ="insert into cycles_head values("  +   "'" +   firstdate   + "', "
                                                                    +   "'" +   lastdate            + "', "
                                                                    +   "'" +   "0001-01-01"        + "', "
                                                                    +   "'" +   "0001-01-01"        + "', "
                                                                    +   "'" +   cycletype           + "', "
                                                                            +   nbtirage + ", 0, "; // nbtirage, nbintercycle

                    for(int i=0; i<50; i++) {
                        queryinsert = queryinsert + occurs[i] + ", ";
                    }

                    StringBuilder sbld = new StringBuilder(queryinsert);
                    sbld.replace(queryinsert.length()-2, queryinsert.length(), ")");

                    queryinsert = sbld.toString();

                    //System.out.println( "queryinsert:\n"
                    //                    + queryinsert);

                    try (Statement sttinsert = _conn.createStatement()) {
                        sttinsert.execute(queryinsert);
                        sttinsert.close();
                    }


                    if(!firstdate.equalsIgnoreCase(lastdate)) {
                        querycycle  = "select * from euromillions "
                                    + "where datetirage >= '" + datefrom + "' "
                                    + "order by datetirage ";
                    }
                    else
                        break query;
                }

                sttmnt.close();
            }

            sttmnt.close();
        } catch (SQLException ex) {
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex);

            try {
                sttmnt.close();
            } catch (SQLException ex1) {
                Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex1);
                return false;
            }

            return false;
        }

        _mdlvw.sendMessageToSystray(this, "Number of cycle found: " + nbcyle);
        return true;
    }

    /*----------------------------------------------*/
    /*- Evaluate number of draw from <grpnbtirage> -*/
    /*----------------------------------------------*/
    private void synthesisGrp(Connection _conn, ModelView _modelvw) {
        try {
            String query_1  = "select   * "
                            + "from     grpnbtirage "
                            + "where    cycletype not in ('E') "
                            + "order by nbtirage";
            Statement sttmnt_1 = _conn.createStatement();
            sttmnt_1.execute(query_1);
            ResultSet rslt_1 = sttmnt_1.getResultSet();

            while(rslt_1.next()) {
                synthesisCyclesInsert(_conn, rslt_1.getInt("nbtirage"), _modelvw);
            }
        }   catch(SQLException e) {
            System.out.println("euromillions.EuromillionsIntergre.SynthesisGrp()");
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    /*-------------------------------------------------*/
    /*- Insert synthesis cycles and average synthesis -*/
    /*-------------------------------------------------*/
    @SuppressWarnings("CallToPrintStackTrace")
    private void synthesisCyclesInsert(Connection _conn, int _nbtirage, ModelView _modelvw) {
        String insertstatmenttmpl   = "insert into synthese ",
               insertstatment       = null;

        Statement sttmnt_2 = null;
        ResultSet rslt_2 = null;

        try {
            String query_2  = "select   a.debcycle, a.fincycle, a.refdebcycle, a.reffincycle, a.cycletype "
                            + "from     cycles_head a "
                            + "where    a.cycletype not in('E') "
                            + "and      a.nbtirage = "  + _nbtirage;

            String dstr, dend, refdstr, refdend;

            int nbcycle=0;

            int avocc[] = new int[100],
                avgap[] = new int[100];

            sttmnt_2    = _conn.createStatement();
            rslt_2      = sttmnt_2.executeQuery(query_2);

            while(rslt_2.next()) {
                dstr = rslt_2.getString("debcycle");
                dend = rslt_2.getString("fincycle");
                refdstr = rslt_2.getString("refdebcycle");
                refdend = rslt_2.getString("reffincycle");

                int[]   pocc = new int[50],
                        aocc = new int[101],
                        agap = new int[100];

                String  query_3  =   "select * "
                                +   "from    cycles_head a "
                                +           "left join lineargap b on a.debcycle = b.lindate "
                                +   "where  a.cycletype not in('E') "
                                +   "and    a.debcycle between '" + dstr + "' and '" + dend + "' "
                                // +   "and    a.nbtirage = "  + (_nbtirage) + " "
                                +   "order by a.debcycle, a.fincycle ";

                Statement sttmnt_3 = _conn.createStatement();
                ResultSet rslt_3 = sttmnt_3.executeQuery(query_3);

                while(rslt_3.next()) {
                    for(int g=0; g<50; g++) {
                        String lingap = "lingap" + (g<9? "0" + (g+1): "" + (g+1));
                        String strgap = rslt_3.getString(lingap);
                        int gap = Integer.parseInt(strgap);

                        String occur    =  "occ" + (g<9? "0" + (g+1): "" + (g+1));
                        String strocc   = rslt_3.getString(occur);
                        int occ =   Integer.parseInt(strocc);

                        if(gap < 0) {
                            gap *= -1;

                            agap[gap-1] ++;
                            aocc[occ-1] ++;
                            //pocc[g] ++;
                        }
                    }
/*
                    for(int i=0; i<pocc.length; i++)
                        if(pocc[i]>0)
                            aocc[pocc[i]] += 1;
*/
                }

                nbcycle++;
                for(int i=0; i<100; i++) {
                    avocc[i] += aocc[i];
                    avgap[i] += agap[i];
                }

                rslt_3.close();
                sttmnt_3.close();

                /*--------------------------------------*/
                /*- insert 'P' and 'S' cycle synthesis -*/
                /*--------------------------------------*/
                insertstatment   =   insertstatmenttmpl;
                String insertvalues     =   "values(";

                insertvalues    += "'" + dstr       + "', '" + dend     + "', "; // Start and endt date of cycle.
                insertvalues    += "'" + refdstr    + "', '" + refdend  + "', "; // Start and end date of the reference cycle - Same //as <dstr> and <dend> if primary cycle.

                insertvalues    += _nbtirage + ", ";
                insertvalues    += "'" + rslt_2.getString("cycletype") + "', ";

                for(int i=0; i<100; i++) {
                    insertvalues    += "" + aocc[i+1] + ", ";
                }

                for(int i=0; i<100; i++) {
                    insertvalues    += "" + agap[i] + ", ";
                }

                insertvalues    = insertvalues.substring(0, insertvalues.length() -2) + ") ";

                insertstatment   += insertvalues;

                Statement sttmnt_4 = _conn.createStatement();
                sttmnt_4.execute(insertstatment);
                sttmnt_4.close();

                //System.out.println(insertstatment);
            }

            rslt_2.close();
            sttmnt_2.close();

            /*--------------------------------------*/
            /*- insert average synthesis 'A' cycle -*/
            /*--------------------------------------*/
            //System.out.println("nbt/nbc: " + _nbtirage + "/" + nbcycle);
            //if(_nbtirage==26)
                //System.out.println("avocc[0] = " + avocc[0] + " - " + nbcycle);

            for(int i=0; i<100; i++) {
                avocc[i] /= nbcycle;
                avgap[i] /= nbcycle;
            }

            insertstatment   =   insertstatmenttmpl;
            String insertvalues     =   "values(";

            insertvalues    += "'0001-01-01', '0001-01-01', "; // Start and endt date of cycle.
            insertvalues    += "'0001-01-01', '0001-01-01', "; // Start and end date of the reference cycle

            insertvalues    += _nbtirage + ", ";
            insertvalues    += "'A', ";

            for(int i=0; i<100; i++)
                insertvalues    += "" + avocc[i] + ", ";

            for(int i=0; i<100; i++)
                insertvalues    += "" + avgap[i] + ", ";

            insertvalues    = insertvalues.substring(0, insertvalues.length() -2) + ") ";

            insertstatment   += insertvalues;

            Statement sttmnt_4 = _conn.createStatement();
//                    System.out.println(insertstatment);
            try {
                sttmnt_4.execute(insertstatment);
            }
            catch(MySQLIntegrityConstraintViolationException micve) {
                //System.out.println( "Duplicate entry: '" + debcycle + " - '" + fincycle + "' - '" + refdebcycle + "' - '" + reffincycle + "' " + rslt_1.getString("nbtirage") + " "
                //                    + cycletype_2 + " - " + cycletype_3);
                //System.out.println("Insert: " + insertstatment);
                //Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.SEVERE, null, micve);
            }
            catch(Exception e) {
                System.err.println("Insert error: " + insertstatment);
                //Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.SEVERE, null, e);
            }
        }   catch(SQLException e) {
            System.out.println("euromillions.EuromillionsIntergre.synthesisCyclesInsert()");
            System.out.println(insertstatment);
            e.printStackTrace();
            try {
                //Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.SEVERE, null, e);
                rslt_2.close();
            } catch (SQLException ex) {
                Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                sttmnt_2.close();
            } catch (SQLException ex) {
                Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /*-----------------------------------------------------------*/
    /*- s y n t h e s i O f C y c l e I n P r o g r e s s (...) -*/
    /*-----------------------------------------------------------*/
    private void synthesisOfCycleInProgress(Connection _conn, ModelView _modelvw) {
        int nbtirage = 0;

        int[]   pocc = new int[50],
                aocc = new int[101],
                agap = new int[100];

        String  strd=null, endd=null;

        ResultSet   rslt;
        String      query1  =   "select * "
                            +   "from    cycles_head a "
                            +           "left join lineargap b on a.debcycle = b.lindate "
                            +   "where  a.cycletype in('E') "
                            +   "order by a.debcycle, a.fincycle ";

        try (Statement sttmnt = _conn.createStatement()) {
            rslt = sttmnt.executeQuery(query1);

            while(rslt.next()) {
                nbtirage ++;

                if(strd==null) {
                    strd = rslt.getString("debcycle");
                    endd = rslt.getString("fincycle");
                }

                for(int i=0; i<50; i++) {
                    String lingap = "lingap" + (i<9? "0" + (i+1): "" + (i+1));
                    String strgap = rslt.getString(lingap);
                    int gap = Integer.parseInt(strgap);

                    String occur    =  "occ" + (i<9? "0" + (i+1): "" + (i+1));
                    String strocc   = rslt.getString(occur);
                    int occ =   Integer.parseInt(strocc);

                    if(gap <= 0) {
                        gap *= -1;

                        agap[gap-1] ++;
                        aocc[occ-1] ++;
                        //pocc[i] ++;
                    }
                }
            }
        }
           catch (SQLException ex) {
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.SEVERE, null, ex);
        }
/*
        for(int i=0; i<pocc.length; i++) {
            if(pocc[i]>0) {
                //System.out.println("pocc[" + i + "] = " + pocc[i]);
                aocc[pocc[i]] += 1;
                //System.out.println("aocc[pocc[" + i + "]] = " + aocc[pocc[i]] );
            }
        }
*/
//System.out.println("nbt/nbc: " + _nbtirage + "/" + nbcycle);
        String insertstatment   =   "Insert into synthese ";
        String insertvalues     =   "values(";

        insertvalues    += "'" + strd + "', '" + endd + "', ";  // Start and endt date of cycle.
        insertvalues    += "'0001-01-01', '0001-01-01', ";      // Start and end date of the reference cycle

        insertvalues    += nbtirage + ", ";
        insertvalues    += "'E', ";

        for(int i=0; i<100; i++) {
            insertvalues    += "" + aocc[i] + ", ";
        }

        for(int i=0; i<100; i++)
            insertvalues    += "" + agap[i] + ", ";

        insertvalues    = insertvalues.substring(0, insertvalues.length() -2) + ") ";

        insertstatment   += insertvalues;

        try {
            Statement sttmnt_4 = _conn.createStatement();
//                    System.out.println(insertstatment);
            sttmnt_4.execute(insertstatment);
        }
        catch(MySQLIntegrityConstraintViolationException micve) {
            //System.out.println("Insert: " + insertstatment);
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.SEVERE, null, micve);
        }
        catch(Exception e) {
            System.err.println("Insert error: " + insertstatment);
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    /*------------------------------------*/
    /*-  p r e p a r e S c h e m a (...) -*/
    /*------------------------------------*/
    private void prepareSchema(Connection _conn, ModelView _mdlvw) {
        String query_1_1    = "select debcycle, refdebcycle, reffincycle "
                            + "from   cycles_head "
                            + "where  cycletype not in('E') "
                            + "group by refdebcycle, reffincycle "
                            + "order by debcycle";

        String query_1_2    = "select   debcycle, refdebcycle, reffincycle "
                            + "from     cycles_head "
                            + "where    cycletype in('E') "
                            + "group by refdebcycle, reffincycle "
                            + "order by debcycle "
                            + "limit    1";
        try {
            Statement sttmnt_1  = _conn.createStatement();
            sttmnt_1.execute(query_1_1);

            ResultSet rslt_1 = sttmnt_1.getResultSet();

            while(rslt_1.next()) {
                if(false == setSchema(  _conn,
                                        _mdlvw,
                                        rslt_1.getString("refdebcycle"),
                                        rslt_1.getString("reffincycle"))) {

                    System.err.println("setSchema() return false.");
                    rslt_1.close();
                    sttmnt_1.close();
                    return;
                }
            }

            rslt_1.close();
            sttmnt_1.close();

            sttmnt_1 = _conn.createStatement();
            sttmnt_1.execute(query_1_2);

            rslt_1  = sttmnt_1.getResultSet();
            rslt_1.next();

            if(false == setSchema(  _conn,
                                    _mdlvw,
                                    rslt_1.getString("refdebcycle"),
                                    rslt_1.getString("reffincycle"))) {

                System.err.println("setSchema() return false.");
                rslt_1.close();
                sttmnt_1.close();
                return;
            }

            rslt_1.close();
            sttmnt_1.close();
        }
        catch(SQLException se) {
            se.printStackTrace();
        }
    }

    /*-----------------------------*/
    /*- s e t S c h e m a (...) -*/
    /*-----------------------------*/
    private boolean setSchema( Connection _conn, ModelView _mdlvw,
                            String _refdebcycle, String _reffincycle) {
        int[] occ    = new int[50];

        String insertstatment   = null;
        String insertvalues     = null;
        String debcycle         = null;
        Statement sttmnt_2      = null;
        ResultSet rslt_2        = null;
        Statement sttmnt_3      = null;
        String query_2          = null;

        if(!_refdebcycle.equalsIgnoreCase("0001-01-01")) {
            query_2 = "select * "
                    + "from   cycles_head a "
                    +         "left join lineargap b on b.lindate = a.debcycle "
                    + "where  a.debcycle between " + "'" + _refdebcycle + "' and '" + _reffincycle + "' "
                    + "order by a.debcycle";
        }
        else {
            query_2 = "select   * "
                    + "from     cycles_head a "
                    +           "left join lineargap b on b.lindate = a.debcycle "
                    + "where    a.cycletype = 'E' "
                    + "order by a.debcycle";
        }

        try {
            //System.err.println("Sql open");
            //System.err.println(query_2);

            sttmnt_2 = _conn.createStatement();
            sttmnt_2.execute(query_2);

            rslt_2 = sttmnt_2.getResultSet();
            int[] gap   = new int[50];
            int occc;

            while(rslt_2.next()) {
                int[] schema = new int[5];
                occc=0;

                for (int i=0; i<50; i++) {
                    gap[i] = rslt_2.getInt( "lingap" + ((i+1)<10?   "0" +   (i+1):
                                                                    ""  +   (i+1) ));

                    if(gap[i] <= 0) {
                        occ[i]  ++;

                        schema[occc] = occ[i];

                        occc    ++;

                        if(occc == (schema.length))
                            break;
                    }
                }

                // Order schema - buble sort
                // -------------------------
                boolean again = true;
                int     limit = schema.length-1;
                int     temp;

                while(again) {
                    again = false;

                    for(int i=0; i<limit; i++) {
                        if(schema[i] > schema[i+1]) {
                            again = true;

                            temp = schema[i];
                            schema[i]   = schema[i+1];
                            schema[i+1] = temp;
                        }
                    }

                    limit --;
                }

                // schema indentity
                // ----------------
                long schemabit = 0L;

                for(int i=0; i<schema.length; i++)
                    schemabit |= 1<<schema[i];


                // Insert shema.
                // -------------
                insertstatment   =   "insert into schemaoccs ";
                insertvalues     =   "values(";

                debcycle = rslt_2.getString("debcycle");
                //System.out.println(debcycle);

                insertvalues += "'" + debcycle + "', '";
                insertvalues += _refdebcycle + "', '";
                insertvalues += _reffincycle + "', ";

                for(int i=0; i<schema.length; i++) {
                    insertvalues    += schema[i] + ", ";
                }

                insertvalues        += schemabit + ", ";

                insertvalues        = insertvalues.substring(0, insertvalues.length() -2) + ") ";
                insertstatment      += insertvalues;

                sttmnt_3 = _conn.createStatement();
                sttmnt_3.execute(insertstatment);
                sttmnt_3.close();
            }

            //System.err.println("sql close");
            rslt_2.close();
            sttmnt_2.close();
        }
        catch(SQLException se) {
            System.err.println("***" + debcycle + " / " + _refdebcycle + " / " + _reffincycle);
            System.err.println(insertstatment);
            se.printStackTrace();

            try {
                rslt_2.close();
                sttmnt_2.close();
                sttmnt_3.close();
            } catch (SQLException se2) {}

            return false;
        }

        return true;
    }

    private void grpCycles(Connection _conn, ModelView _mdlvw) {
        try (Statement sttmnt = _conn.createStatement()) {

            sttmnt.execute("delete from grpnbtirage");

            sttmnt.execute(     "insert into grpnbtirage "
                            +   "select nbtirage, ' ', count(*) "
                            +   "from   cycles_head "
                            +   "where  cycletype <> 'E' "
                            +   "group by nbtirage");

            sttmnt.execute(     "insert into grpnbtirage "
                            +   "select nbtirage, 'E', count(*) "
                            +   "from   cycles_head "
                            +   "where  cycletype = 'E' "
                            +   "group by nbtirage");

            sttmnt.execute(     "select max(nbtirage) "
                            +   "from grpnbtirage "
                            +   "where cycletype = 'E'");

            ResultSet rs = sttmnt.getResultSet();

            if(rs.next()) {
                String maxtir = rs.getString(1);

                sttmnt.execute(     "delete from grpnbtirage "
                                +   "Where  cycletype = 'E' "
                                +   "And    nbtirage < "    + maxtir);
            }
        } catch (SQLException ex) {
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex);
        }
    }

    private void linearGap(Connection _conn) {
        String request  = "select datetirage, boule1, boule2, boule3, boule4, boule5 "
                        + "from euromillions "
                        + "Order by datetirage";
        String inserttmpl = "insert into lineargap values(";
        String insert= null;
        ResultSet rsetlinearg;

        int iboule1, iboule2, iboule3, iboule4, iboule5;
        int iboule[] = new int[5];
        String sboule1, sboule2, sboule3, sboule4, sboule5;
        int lineargap[] = new int[50];
        String datetirage = null;

        try (Statement sttmnt = _conn.createStatement()) {
            rsetlinearg = sttmnt.executeQuery(request);

            while(rsetlinearg.next()) {
                datetirage = rsetlinearg.getString("datetirage");
                iboule1 = Integer.parseInt((sboule1 = rsetlinearg.getString("boule1")));
                iboule2 = Integer.parseInt((sboule2 = rsetlinearg.getString("boule2")));
                iboule3 = Integer.parseInt((sboule3 = rsetlinearg.getString("boule3")));
                iboule4 = Integer.parseInt((sboule4 = rsetlinearg.getString("boule4")));
                iboule5 = Integer.parseInt((sboule5 = rsetlinearg.getString("boule5")));

                iboule[0] = iboule1;
                iboule[1] = iboule2;
                iboule[2] = iboule3;
                iboule[3] = iboule4;
                iboule[4] = iboule5;

                for(int i=0; i<50; i++)
                    if(i!= (iboule1-1) &&
                       i!= (iboule2-1) &&
                       i!= (iboule3-1) &&
                       i!= (iboule4-1) &&
                       i!= (iboule5-1)) {
                        if(lineargap[i] < 0)
                            lineargap[i] = 1;
                        else
                            lineargap[i] += 1;
                    }
                    else {
                        //if(lineargap[i] < 0)
                        //    lineargap[i] = lineargap[i];
                        if(lineargap[i] >= 0) //else
                            lineargap[i] *= -1;
                    }

                insert = inserttmpl + "'" + datetirage + "', ";

                for(int i=0; i<50; i++) {
                    insert += lineargap[i] + ", ";
                }

                insert = insert.substring(0, insert.length()-2) + ")"; // -2 to eliminate space and comma previously seted by the last iteration of while and for.

                try (Statement sttinsert = _conn.createStatement()) {
                        sttinsert.execute(insert);
                        sttinsert.close();
                    }
            }

            sttmnt.close();
        }
        catch (SQLException ex) {
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex);
        }


        }
    }

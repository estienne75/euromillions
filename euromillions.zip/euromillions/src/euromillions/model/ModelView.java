/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.model;

import euromillions.event.DateEvent;
import euromillions.event.IntegreSystrayMessageEvent;
import euromillions.event.MHMIHideEvent;
import euromillions.event.MHMIShowEvent;
import euromillions.listener.DateDetailRowListener;
import euromillions.listener.MHMIListener;
import euromillions.view.datescycles.PnlDatesDetailRows;
import euromillions.view.grouppcycles.PnlGrpDetailRows;
import javax.swing.event.EventListenerList;
import euromillions.listener.GrpDetailRowListener;
import euromillions.listener.IntegreSystrayListener;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class ModelView {
    private final EventListenerList mhmiListeners;
    private final EventListenerList grpDtlRwListeners;
    private final EventListenerList dateDtlRwListeners;
    private final EventListenerList integreSystrayListeners;

    private Object selectedCycleDetailRow;
    private Object selectedDateDetailRow;

    public ModelView() {
        mhmiListeners           = new EventListenerList();
        grpDtlRwListeners       = new EventListenerList();
        dateDtlRwListeners      = new EventListenerList();
        integreSystrayListeners  = new EventListenerList();
    }

    public void integre(){
        selectedCycleDetailRow = null;
    }

    public void addIntegrationDialogListener(IntegreSystrayListener _lstnr){
        integreSystrayListeners.add(IntegreSystrayListener.class, _lstnr);
    }

    public void removeIntegrationDialogListener(IntegreSystrayListener _lstnr){
        integreSystrayListeners.remove(IntegreSystrayListener.class, _lstnr);
    }

    public void sendMessageToSystray(Object _object, String _message) {
        IntegreSystrayListener[] lstnrlist;
        lstnrlist = integreSystrayListeners.getListeners(IntegreSystrayListener.class);

        for(IntegreSystrayListener lstnr: lstnrlist) {
            lstnr.SystrayMessage(new IntegreSystrayMessageEvent(_object, _message));
        }
    }

    // Main Human Machine Interface.
    // -----------------------------
    public void addMHMIListener(MHMIListener _mhmilstnr) {
        mhmiListeners.add(MHMIListener.class, _mhmilstnr);
    }

    public void removeMHMIListener(MHMIListener _mhmilstnr) {
        mhmiListeners.remove(MHMIListener.class, _mhmilstnr);
    }


    public void showMHMI(Object _obj) {
        MHMIListener[] listenerlist = mhmiListeners
                                           .getListeners(MHMIListener.class);

        for(MHMIListener listener : listenerlist) {
            listener.showMHMI(new MHMIShowEvent(_obj));
        }
    }

    public void hideMHMI(Object _obj) {
        MHMIListener[] listenerlist = mhmiListeners
                                           .getListeners(MHMIListener.class);

        for(MHMIListener listener : listenerlist) {
            listener.hideMHMI(new MHMIHideEvent(_obj));
        }
    }

    // Groupp Detail Row
    // -----------------
    public void addGrpDetailRowListener(GrpDetailRowListener _lstnr) {
        grpDtlRwListeners.add(GrpDetailRowListener.class, _lstnr);
    }

    public void removeGrpDetailRowListener(GrpDetailRowListener _lstnr) {
        grpDtlRwListeners.remove(GrpDetailRowListener.class, _lstnr);
    }

    public void grpDetailRowSelected(Object _obj,
                                      String _nbCycle,
                                      String _nbTirage,
                                      String _cycleType) {
        if(selectedCycleDetailRow != null)
            ((PnlGrpDetailRows) selectedCycleDetailRow).switchSelectedState();
        selectedCycleDetailRow = _obj;
        ((PnlGrpDetailRows) selectedCycleDetailRow).switchSelectedState();
    }

    public void addDateDetailRowListener(DateDetailRowListener _lstnr) {
        dateDtlRwListeners.add(DateDetailRowListener.class, _lstnr);
    }

    public void removeDateDetailRowListener(DateDetailRowListener _lstnr) {
        dateDtlRwListeners.remove(DateDetailRowListener.class, _lstnr);
    }


    public void dateDetailRowSelected(  Object _obj,
                                            String _beginDate,
                                            String _endDate,
                                            String _cycletype) {
        if(selectedDateDetailRow != null)
            ((PnlDatesDetailRows) selectedDateDetailRow).switchSelectedState();
        selectedDateDetailRow = _obj;
        ((PnlDatesDetailRows) selectedDateDetailRow).switchSelectedState();

        DateDetailRowListener[] listenerlist = dateDtlRwListeners
                                     .getListeners(DateDetailRowListener.class);

        for(DateDetailRowListener listener : listenerlist) {
            listener.dateDetailRowSelected(new DateEvent(  _obj,
                                                                _beginDate,
                                                                _endDate,
                                                                _cycletype,
                                                                null));
        }
    }
}
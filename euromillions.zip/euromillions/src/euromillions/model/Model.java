/*PnlNumberCycleDetail
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.model;

/*- Java util -*/
/*-------------*/
import java.util.logging.Level;
import java.util.logging.Logger;

/*- Java  event -*/
/*---------------*/
import javax.swing.event.EventListenerList;

/*- Java  sql -*/
/*-------------*/
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

/*_ euromillions Integre -*/
/*------------------------*/
import euromillions.EuromillionsIntergre;

/*_ euromillions listeners -*/
/*--------------------------*/
import euromillions.listener.CycleNumberGridListener;
import euromillions.listener.DateSecondaryListener;
import euromillions.listener.SynthesisListener;
import euromillions.listener.SchemaOccsListener;
import euromillions.listener.DrawListener;
import euromillions.listener.IntegrationListener;
import euromillions.listener.NewDataListener;

/*_ euromillions Events -*/
/*-----------------------*/
import euromillions.event.DateEvent;
import euromillions.event.DateSecondaryEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import euromillions.event.NumberGridEvent;
import euromillions.event.SchemaOccsEvent;
import euromillions.event.SynthesisEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import euromillions.event.PlayGridEvent;
import euromillions.event.PlayedGridEvent;
import euromillions.listener.PlayGridListener;
import org.joda.time.DateTime;

/*****************/
/** Class Model **/
/*****************/
/**
 * <h1>Model</h1>
 * La classe Model tient plusieurs tôle dans le cadre de l'acheminement des données:
 *  <p>
 *      <ul>
 *          <li>L'ouverture d'une connexion à la base de données MySQL (Cconstructeur).</li>
 *          <li>L'enregistrement des écouteurs (Listeners).</li>
 *          <li>La collecte de données provenant de la base de données heureuxmillions (schéma) et la livraison de celles-ci via les écouteurs (listeners).</li>
 *          <li>Le maintient de donnés booléennes ainsi que de tableaux.</li>
 *      </ul>
 *</p>
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 * @version 1.0
 * @since 01-01-2013
 */
public class Model {

    Connection cnnctn;

    private EventListenerList   integrationlisteners,
                                newdatalisteners,
                                cyclenumbergridlisteners,
                                secondarycyclelisteners,
                                drawlisteners,
                                synthesislisteners,
                                schemaoccslisteners,
                                playgridlisteners;

    private final   int[]   lingapstart = new int[50];
    private final   int[]   lingapend   = new int[50];
    private final   int[]   glboccurs   = new int[50];

    private final boolean[] ballsselected;
    private final boolean[] starsselected;

    private boolean conserve = true;

    private final ModelView modelvw;

    /*-------------------------------*/
    /*- C o n s t r u c t o r (...) -*/
    /*-------------------------------*/
    /**
     * <h1>Model</h1>
     * <p>
     * Assure la connextion à la base de donnée heureuxmillions ainsi que la création des listes de Listeners.
     * </p>
     *
     * @param _modelvw Modèle complémentaire de gestion des vues.
     */
    public Model(ModelView _modelvw) {
        modelvw = _modelvw;

        try {
            // The newInstance() call is a work around for some
            // broken Java implementations
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException ex) {
            // handle the error
            System.err.println("Message: " + ex.getMessage());
            System.exit(-1);
        }

        try {
            cnnctn =
            DriverManager.getConnection("jdbc:mysql://localhost/heureuxmillions?" +
                                        "useSSL=false&user=Stephane&password=MSQ19Stef69;");

        } catch (SQLException ex) {
            // handle any errors
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: "     + ex.getSQLState());
            System.out.println("VendorError: "  + ex.getErrorCode());
            System.exit(-1);
        }

        createListenersList();

        ballsselected = new boolean[50];
        starsselected = new boolean[12];
    }

    /*---------------*/
    /*- e x i t ( ) -*/
    /*---------------*/
    public void exit() {
        try {
            cnnctn.close();
        } catch (SQLException ex) {
            Logger.getLogger(EuromillionsIntergre.class.getName()).log(Level.INFO, null, ex);
        }

        //System.exit(0);
    }

    /*---------------------------------------------*/
    /*- c r e a t e L i s t e n e r L i s t (...) -*/
    /*---------------------------------------------*/
    private void createListenersList() {
        integrationlisteners        = new EventListenerList();
        newdatalisteners            = new EventListenerList();
        cyclenumbergridlisteners    = new EventListenerList();
        synthesislisteners          = new EventListenerList();
        drawlisteners               = new EventListenerList();
        secondarycyclelisteners     = new EventListenerList();
        schemaoccslisteners         = new EventListenerList();
        playgridlisteners           = new EventListenerList();
    }

    /*--------------------------------------------*/
    /*- c o n s e r ve S e l e c t B a l l (...) -*/
    /*--------------------------------------------*/
    public void conserveSelectBall(boolean _conserve) {
        conserve = _conserve;
    }

    /*-------------------------------------------*/
    /*- r e s e t S e l e c t e d b a l l (...) -*/
    /*-------------------------------------------*/
    public void resetSelectedball(Object _obj) {
        for(int i =0; i<50; i++) {
            if(ballsselected[i]) {
                selectBall(_obj, (i+1)<10? "0" + (i+1): "" + (i+1));
                ballsselected[i] = false;
            }
        }
    }

    public void selectSchema(Object _obj, int _schemanumber) {
       for (int i=0; i<glboccurs.length; i++)
           if(glboccurs[i] == _schemanumber)
               this.selectBall( _obj,
                                (i<9) ? "0" + (i+1): "" + (i+1) );
    }

    /*---------------------------------------------------*/
    /*- a d d D a t e S e c o n d a r y C y c l e (...) -*/
    /*---------------------------------------------------*/
    public void addDateSecondaryCycle(DateSecondaryListener _l) {
        secondarycyclelisteners.add(DateSecondaryListener.class, _l);
    }

    /*---------------------------------------------------------*/
    /*- r e m o v e D a t e S e c o n d a r y C y c l e (...) -*/
    /*---------------------------------------------------------*/
    public void removeDateSecondaryCycle(DateSecondaryListener _l) {
        secondarycyclelisteners.remove(DateSecondaryListener.class, _l);
    }

    /*---------------------------------------------*/
    /*- D a t e S e c o n d a r y C y c l e (...) -*/
    /*---------------------------------------------*/
    public void DateSecondaryCycle(Object _obj, boolean _selected) {
        DateSecondaryListener[] dsclist = secondarycyclelisteners
                                       .getListeners(DateSecondaryListener.class);

        for(DateSecondaryListener l: dsclist) {
            l.headerSecondaryStateChanged(new DateSecondaryEvent(_obj,
                                                                 _selected));
        }
    }

    /*---------------------------------------*/
    /*- g e t G r o u p p s C y c l e (...) -*/
    /*---------------------------------------*/
    public void getGrouppsCycle(Object _obj) {
        IntegrationListener[] itllist = integrationlisteners
                                       .getListeners(IntegrationListener.class);

        ResultSet rslt;

        // Tous les cycles en premier, exceptés ceux en cours.
        // ---------------------------------------------------
        String querycc  = "Select   count(*) "
                        + "From     cycles_head "
                        + "Where    cycletype <> 'E'";

        try (Statement sttmnt = cnnctn.createStatement()) {
            rslt = sttmnt.executeQuery(querycc);
            rslt.next();

            String nbcycle;
            nbcycle = rslt.getString(1);

            for(IntegrationListener l: itllist) {
                    l.integrationAddGrpRow(new GrouppEvent(_obj, nbcycle, "Tous", "Sauf E"));
            }

            rslt.close();

            // Cycle en cours en second.
            // -------------------------
            querycc = "select nbtirage, cycletype, nbcycle "
                    + "from grpnbtirage "
                    + "Where cycletype = 'E'";



            rslt = sttmnt.executeQuery(querycc);

            String nbtirage;
            String cycletype;

            while(rslt.next()) {
                nbcycle     = rslt.getString("nbcycle");
                nbtirage    = rslt.getString("nbtirage");
                cycletype   = rslt.getString("cycletype");

                for(IntegrationListener l: itllist) {
                    l.integrationAddGrpRow(new GrouppEvent(_obj, nbcycle, nbtirage, cycletype));
                }
            }

            rslt.close();

            // Autres cycles en dernier.
            // -------------------------
            querycc = "select nbtirage, cycletype, nbcycle "
                    + "from grpnbtirage "
                    + "Where cycletype <> 'E'";

            rslt = sttmnt.executeQuery(querycc);

            while(rslt.next()) {
                nbcycle     = rslt.getString("nbcycle");
                nbtirage    = rslt.getString("nbtirage");
                cycletype   = rslt.getString("cycletype");

                for(IntegrationListener l: itllist) {
                    l.integrationAddGrpRow(new GrouppEvent(_obj, nbcycle, nbtirage, cycletype));
                }
            }

            rslt.close();
            sttmnt.close();

        } catch (SQLException ex) {
            Logger.getLogger(Model.class.getName()).log(Level.INFO, null, ex);
        }
    }

    /*-----------------------------------------------------*/
    /*- a d d I n t e g r a t i o n L i s t e n e r (...) -*/
    /*-----------------------------------------------------*/
    public void addIntegrationListener(IntegrationListener _intgrt) {
        integrationlisteners.add(IntegrationListener.class, _intgrt);
    }

    /*-----------------------------------------------------------*/
    /*- r e m o v e I n t e g r a t i o n L i s t e n e r (...) -*/
    /*-----------------------------------------------------------*/
    public void removeIntegrationListener(IntegrationListener _intgrt) {
        integrationlisteners.remove(IntegrationListener.class, _intgrt);
    }

    /*-----------------------*/
    /*- I n t e g r e (...) -*/
    /*-----------------------*/
    public void Integre(Object _obj) {
        integration intgr = new integration(_obj, modelvw);
        integrationBegin(_obj);
        new Thread(intgr).start();
    }

    /*-----------------------------------------*/
    /*- i n t e g r a t i o n B e g i n (...) -*/
    /*-----------------------------------------*/
    private void integrationBegin(Object _obj) {
        IntegrationListener[] itllist = integrationlisteners
                                       .getListeners(IntegrationListener.class);

        for(IntegrationListener l: itllist) {
            l.integrationStart(new IntegrationEvent(_obj));
        }
    }

    /*-------------------------------------*/
    /*- i n t e g r a t i o n E n d (...) -*/
    /*-------------------------------------*/
    private void integrationEnd(Object _obj) {
        IntegrationListener[] itllist = integrationlisteners
                                       .getListeners(IntegrationListener.class);

        for(IntegrationListener l: itllist) {
            l.integrationEnd(new IntegrationEvent(_obj));
        }
    }

    /*-------------------------------------------------*/
    /*- g r p D e t a i l R o w S e l e c t e d (...) -*/
    /*-------------------------------------------------*/
    public void grpDetailRowSelected( Object  _obj,
                                        String  _nbCycle,
                                        String  _nbTirage,
                                        String  _cycleType) {
        IntegrationListener[] itllist = integrationlisteners
                                       .getListeners(IntegrationListener.class);

        newCycleDate();

        String querycc;
        // Cycle en cours en premier.

        if(_cycleType.equalsIgnoreCase("Sauf E")) {
            querycc = "select debcycle, fincycle, cycletype, nbtirage "
                    + "from cycles_head "
                    + "Where cycletype <> 'E' "
                    + "Order By debcycle Desc";
        }
        else if(_cycleType.equalsIgnoreCase("E"))
            querycc = "select debcycle, fincycle, cycletype, nbtirage "
                    + "from cycles_head "
                    + "Where cycletype = 'E' "
                    + "Order By debcycle Asc";
        else {
            querycc = "select debcycle, fincycle, cycletype, nbtirage "
                    + "from cycles_head "
                    + "Where cycletype <> 'E' "
                    + "And   nbtirage = " + _nbTirage + " "
                    + "Order By debcycle Desc";
        }

        ResultSet rslt;

        try (Statement sttmnt = cnnctn.createStatement()) {
            rslt = sttmnt.executeQuery(querycc);

            String begindate;
            String enddate;
            String cycletype;
            String nbtirage;

            while(rslt.next()) {
                begindate   = rslt.getString("debcycle");
                enddate     = rslt.getString("fincycle");
                cycletype   = rslt.getString("cycletype");
                nbtirage    = rslt.getString("nbtirage");

                for(IntegrationListener l: itllist) {
                    l.integrationAddDateRow(new DateEvent(_obj,
                                                                begindate,
                                                                enddate,
                                                                cycletype,
                                                                nbtirage));
                }
            }

            rslt.close();
            sttmnt.close();
        } catch (SQLException ex) {
            Logger.getLogger(Model.class.getName()).log(Level.INFO, null, ex);
        }
    }

    /*------------------------------------------------------------*/
    /*- a d d C y c l e N u m b e r G r i d L i s t e n e r(...) -*/
    /*------------------------------------------------------------*/
    /**
     *
     * @param _cngl
     */
    public void addCycleNumberGridListener(CycleNumberGridListener _cngl) {
        cyclenumbergridlisteners.add(CycleNumberGridListener.class, _cngl);
    }

    /*---------------------------------------------------*/
    /*- r e m o v e N e w D a t a L i s t e n e r (...) -*/
    /*---------------------------------------------------*/
    public void removeNewDataListener(CycleNumberGridListener _cngl) {
        cyclenumbergridlisteners.remove(CycleNumberGridListener.class, _cngl);
    }

    /*-----------------------------*/
    /*- s e l e c t B a l l (...) -*/
    /*-----------------------------*/
    public void selectBall(Object _obj, String _ballnumber) {
        String ballnbr = _ballnumber.substring(0, 2);

        ballsselected[Integer.parseInt(ballnbr)-1] =
                !ballsselected[Integer.parseInt(ballnbr)-1];

        DrawListener[] adrawlisteners = drawlisteners
                                       .getListeners(DrawListener.class);

        for(DrawListener l: adrawlisteners)
            l.DrawBallSelected(new DrawBallEvent(   _obj,
                                                    ballnbr,
                                                    ballsselected[Integer.parseInt(ballnbr)-1]));

        PlayGridListener[] pglist = playgridlisteners
                                       .getListeners(PlayGridListener.class);

        boolean boolpg = checkPlayGrid();

        for(PlayGridListener pgl: pglist)
            pgl.PlayGridChange(new PlayGridEvent(_obj, boolpg));

    }

    /*------------------------------------------------*/
    /*-  a d d P l a y G r i d L i s t e n e r (...) -*/
    /*------------------------------------------------*/
    public void addPlayGridListener(PlayGridListener _pgl) {
        playgridlisteners.add(PlayGridListener.class, _pgl);
    }

    /*------------------------------------------------------*/
    /*-  r e m o v e P l a y G r i d L i s t e n e r (...) -*/
    /*------------------------------------------------------*/
    public void removePlayGridListener(PlayGridListener _pgl) {
        playgridlisteners.remove(PlayGridListener.class, _pgl);
    }

    /*------------------------------------*/
    /*- l o a d P l a y e d G r i d s () -*/
    /*------------------------------------*/
    public void loadPlayedGrids(Object _obj) {
        Statement   sttmnt_1;
        ResultSet   rslt_1;

        String      smaxdrawdate;
        DateTime    maxdrawdate;

        String query_1 =    "select max(pgdrawdate) "+
                            "from   playgrids";

        PlayGridListener[] pglist = playgridlisteners
                                       .getListeners(PlayGridListener.class);

        for(PlayGridListener pgl: pglist)
            pgl.newPlayedGridSet();

        try {
            sttmnt_1    = cnnctn.createStatement();
            rslt_1      = sttmnt_1.executeQuery(query_1);

            if(rslt_1.next())
                smaxdrawdate = rslt_1.getString(1);
            else {
                rslt_1.close();
                sttmnt_1.close();
                return;
            }
        }
        catch(SQLException sqle) {
            Logger.getLogger(Model.class.getName()).log(Level.WARNING, null, sqle);
            return;
        }

        maxdrawdate = new DateTime(Integer.parseInt(smaxdrawdate.substring(0, 4)),  // Year.
                                   Integer.parseInt(smaxdrawdate.substring(5, 7)),  // Month.
                                   Integer.parseInt(smaxdrawdate.substring(8, 10)), // Day.
                                   0,0,0);

        String query_2  = "Select       * "
                        + "from         playgrids a "
                        + "right join   players   b on a.pgplayerid = b.plid "
                        + "where        pgdrawdate between '" + maxdrawdate.minusMonths(3). toString("yyyy-MM-dd") + "' "
                        +                             "and '" + maxdrawdate.                toString("yyyy-MM-dd") + "' "
                        + "order by     pgdrawdate desc, pgplayerid, pggridnumber desc, pgcreatedate desc";

        try {
            sttmnt_1    = cnnctn.createStatement();
            rslt_1      = sttmnt_1.executeQuery(query_2);

            while(rslt_1.next()) {
                int[] aballs = new int[10];
                int[] astars = new int[12];

                String  drawdatetable   = rslt_1.getString("pgdrawdate");
                int     playerid        = rslt_1.getInt("pgplayerid");
                String  firstname       = rslt_1.getString("plfirstname");
                String  lastname        = rslt_1.getString("pllastname");
                int     gridnumber      = rslt_1.getShort("pggridnumber");
                String  playeddate      = rslt_1.getString("pgcreatedate");

                for(int i=0; i<10; i++)
                   aballs[i] = rslt_1.getInt("pgball" + (i<9?   "0" + (i+1):
                                                                ""  + (i+1)));

                for(int i=0; i<12; i++)
                    astars[i] = rslt_1.getInt("pgstar" + (i<9?  "0" + (i+1):
                                                                ""  + (i+1)));
                // -----------------
                // fire played grid.
                // -----------------
                for(PlayGridListener pgl: pglist)
                    pgl.PlayedGridFeched(new PlayedGridEvent(   _obj,
                                                                aballs, astars,
                                                                drawdatetable, playeddate,
                                                                playerid,
                                                                firstname, lastname,
                                                                gridnumber));
            }

            rslt_1.close();
            sttmnt_1.close();

            for(PlayGridListener pgl: pglist)
                pgl.endPlayedGridSet();

        }
        catch(SQLException sqle) {
            Logger.getLogger(Model.class.getName()).log(Level.WARNING, null, sqle);

            try {
                rslt_1.close();
                sttmnt_1.close();
            }
            catch(SQLException sqle2) {
                Logger.getLogger(Model.class.getName()).log(Level.WARNING, null, sqle2);
            }
        }
    }

    private DateTime getNextDrawDate() {
        DateTime dt = new DateTime();

        switch(dt.getDayOfWeek()) {
            case 1:                 // Monday   ->  Tuesday -> +1
                dt = dt.plusDays(1);
                break;

            case 3:                 // Wednesday -> Friday  -> +2
                dt = dt.plusDays(2);
                break;

            case 4:                // Thurday   ->  Friday  -> +1
                dt = dt.plusDays(1);
                break;

            case 6:                 // Saturday ->  Tuesday -> +3
                dt = dt.plusDays(3);
                break;

            case 7:                 // Sunday   ->  Tuesday -> +2
                dt = dt.plusDays(2);
                break;
        }


        return dt;
    }

    /*-------------------------------------------------*/
    /*- p l a y G r i d S t a r S e l e c t e d (...) -*/
    /*-------------------------------------------------*/
    public void playGridStarSelected(Object _obj, String _starnum, boolean _starselected) {
        starsselected[Integer.parseInt(_starnum)-1] = _starselected;
        PlayGridListener[] pglist = playgridlisteners
                                       .getListeners(PlayGridListener.class);

        boolean boolpg = checkPlayGrid();

        for(PlayGridListener pgl: pglist)
            pgl.PlayGridChange(new PlayGridEvent(_obj, boolpg));
    }

    /*--------------------------------*/
    /*- c h e c k P l a y G r i d () -*/
    /*--------------------------------*/
    public boolean checkPlayGrid() {
        int numberofselectedball=0;
        int numberofselectedstar=0;

        for(int i=0; i<ballsselected.length; i++)
            if(ballsselected[i])
                numberofselectedball += 1;

        for(int i=0; i<starsselected.length; i++)
            if(starsselected[i])
                numberofselectedstar += 1;

        switch(numberofselectedball) {
            case 5:
            case 6:
                if(numberofselectedstar<2)
                    return false;
                return true;

            case 7:
                if(numberofselectedstar<2 || numberofselectedstar>6)
                    return false;
                return true;

            case 8:
                if(numberofselectedstar<2 || numberofselectedstar>4)
                    return false;
                return true;

            case 9:
                if(numberofselectedstar<2 || numberofselectedstar>3)
                    return false;
                return true;

            case 10:
                if(numberofselectedstar<2 || numberofselectedstar>2)
                    return false;
                return true;

            default:
                return false;
        }
    }

    /*-----------------------------------------*/
    /*- v a l i d a t e P l a y G r i d (...) -*/
    /*-----------------------------------------*/
    public void validatePlayGrid(DateTime _drawdate) {
        DateTime today = new DateTime();
        int maxgridnumber=0;

        Statement sttmnt_1  = null;
        ResultSet rslt_1    = null;

        String query_1  = "select   max(pggridnumber) "
                        + "from     playgrids "
                        + "where    pgdrawdate  = '"  + _drawdate.toString("yyyy-MM-dd") + "' "
                        + "and      pgplayerid = 19690511 ";

        try {
             sttmnt_1  = cnnctn.createStatement();
             rslt_1    = sttmnt_1.executeQuery(query_1);

            if(rslt_1.next())
                maxgridnumber = rslt_1.getInt(1);

            rslt_1.close();
            sttmnt_1.close();
        }
        catch(SQLException sqle) {
            System.out.println("qyery: " +  query_1);
            Logger.getLogger(Model.class.getName()).log(Level.WARNING, null, sqle);

            try {
                if(rslt_1!=null)
                    rslt_1.close();

                if(sttmnt_1!=null)
                    sttmnt_1.close();
            } catch (SQLException ex) {
                Logger.getLogger(Model.class.getName()).log(Level.WARNING, null, ex);
            }

            return;
        }

        String insert = "insert into playgrids ";
        String values = "values('"   + _drawdate.toString("yyy-MM-dd")  + "', "
                                     + 19690511 + ", "
                                     + (maxgridnumber + 1) + ", '"
                                     + today.toString("yyyy-MM-dd")     + "', ";
        // Balls
        // -----
        int numberofballsselected = 0;

        for(int i=0; i<ballsselected.length; i++) {
            if(ballsselected[i]) {
                values += "" + (i+1) + ", ";
                numberofballsselected ++;
            }
        }

        if(numberofballsselected < 10)
            for(int i=(numberofballsselected + 1); i<11; i++)
                    values +=  "0, ";

        // Stars
        // -----
        int numberofstarsselected = 0;

        for(int i=0; i<starsselected.length; i++) {
            if(starsselected[i]) {
                values += "" + (i+1) + ", ";
                numberofstarsselected ++;
            }
        }

        if(numberofstarsselected < 12)
            for(int i=(numberofstarsselected + 1); i<13; i++)
                values +=  "0, ";

        values = values.substring(0, (values.length()-2));
        values += ")";

        insert += values;

        Statement sttmnt_2 = null;

        try {
            sttmnt_2 = cnnctn.createStatement();
            sttmnt_2.executeUpdate(insert);
            sttmnt_2.close();
        }
        catch(SQLException sqle) {
            System.out.println("insert: " + insert);
            Logger.getLogger(Model.class.getName()).log(Level.WARNING, null, sqle);

            try {
                if(sttmnt_2!=null)
                    sttmnt_2.close();
            } catch (SQLException ex) {
                Logger.getLogger(Model.class.getName()).log(Level.WARNING, null, ex);
            }
        }
    }

    /*-------------------------------------------*/
    /*- a d d D r a w L i s t e n e r (...)     -*/
    /*-------------------------------------------*/
    public void addDrawListener(DrawListener _tl) {
        drawlisteners.add(DrawListener.class, _tl);
    }

    /*---------------------------------------------*/
    /*- r e m o v e D r a w L i s t e n e r (...) -*/
    /*---------------------------------------------*/
    public void removeDrawListener(DrawListener _tl) {
        drawlisteners.remove(DrawListener.class, _tl);
    }

    /*---------------------------------------*/
    /*- g e t C y c l e N u m b e r s (...) -*/
    /*---------------------------------------*/
    public void getCycleNumbers(    Object  _obj,
                                    String  _startdate,
                                    String  _enddate,
                                    String  _cycletype,
                                    String  _nbTirage) {
        /*------------------*/
        /*- Draw and Stats -*/
        /*------------------*/
        CycleNumber cyclenumber = new CycleNumber(  _obj,
                                                    _startdate, _enddate,
                                                    _cycletype, _nbTirage);
        new Thread(cyclenumber).start();

        /*-------------*/
        /*- Synthesis -*/
        /*-------------*/
        Synthesis synthesis     = new Synthesis(_obj,
                                                _startdate, _enddate,
                                                _cycletype, _nbTirage);
        new Thread(synthesis).start();

        /*----------*/
        /*- Shemas -*/
        /*----------*/
        SchemaOccs schemaoccs     = new SchemaOccs( _obj,
                                                    _startdate, _enddate, _cycletype);

        SchemaOccsListener[] solist = schemaoccslisteners
                                       .getListeners(SchemaOccsListener.class);

        for(SchemaOccsListener s: solist)
                s.newSchemasInProgress();
        // Will fire SchemaOccsListener.newSchema(SchemaOccsEvent).
        new Thread(schemaoccs).start();
    }

    /*********************************/
    /** Runnable Class: CycleNumber **/
    /*********************************/
    private class CycleNumber implements Runnable {
        private final Object obj;
        private final String startdate;
        private final String enddate;
        private final String cycletype;
        private final String nbTirage;

        /*-------------------------*/
        /*- C o n s t r u c t o r -*/
        /*-------------------------*/
        public CycleNumber( Object  _obj,
                            String  _startdate,
                            String  _enddate,
                            String  _cycletype,
                            String  _nbTirage)  {
            obj         = _obj;
            startdate   = _startdate;
            enddate     = _enddate;
            cycletype   = _cycletype;
            nbTirage    = _nbTirage;
        }

        @Override
        public void run() {
            String  cycletyp    = null;
            int[]   aoccur      = new int[50];

            String query1   =   "Select * "
                            +   "From   cycles_head "
                            +   "Where  debcycle    = '"    + startdate    + "' "
                            +   "And    fincycle    = '"    + enddate      + "'";

            String query2_1 =   "Select * "
                            +   "From   lineargap "
                            +   "Where  lindate = '"  +   startdate  +   "'";

            String query2_2 =   "Select * "
                            +   "From   lineargap "
                            +   "Where  lindate = '"  +   enddate  +   "'";

            ResultSet rslt;

            NewDataListener[] nwdatalstnr = newdatalisteners
                                           .getListeners(NewDataListener.class);

            for(NewDataListener l: nwdatalstnr) {
                l.newNumber();
            }


            try (Statement sttmnt = cnnctn.createStatement()) {
                rslt = sttmnt.executeQuery(query1);

                if(rslt.next()) {
                    for(int i=0; i<50; i++) {
                        aoccur[i]    = rslt.getInt("occ" + ((i+1)<10? "0" + (i+1): "" + (i+1)));
                    }

                    cycletyp = rslt.getString("cycletype");
                }

                rslt.close();

                rslt = sttmnt.executeQuery(query2_1);

                if(rslt.next())
                    for(int i=0; i<50; i++)
                        lingapstart[i]   = rslt.getInt("lingap" + ((i+1)<10? "0" + (i+1): "" + (i+1)));

                rslt.close();

                rslt = sttmnt.executeQuery(query2_2);

                if(rslt.next())
                    for(int i=0; i<50; i++)
                        lingapend[i]   = rslt.getInt("lingap" + ((i+1)<10? "0" + (i+1): "" + (i+1)));

                rslt.close();

                CycleNumberGridListener[] cnglist = cyclenumbergridlisteners
                                .getListeners(CycleNumberGridListener.class);

                for(CycleNumberGridListener l: cnglist) {
                    l.cyleNumberNewGrid(new NumberGridEvent(obj,
                                                            startdate,
                                                            enddate,
                                                            cycletyp,
                                                            aoccur,
                                                            lingapstart,
                                                            lingapend));
                }

                String query3   = "Select datetirage, boule1, boule2, boule3, boule4, boule5 "
                                + "From   euromillions "
                                + "Where  datetirage between '" + startdate + "' And '" + enddate + "'";

                String  datetirage  = null;
                int     boules[]    = new int[5];


                for(int i=0; i<50; i++) {
                    aoccur[i]       = 0;
                    lingapstart[i]  = 0;
                }

                rslt = sttmnt.executeQuery(query3);

                String  firstdate = null;
                int     count=0;

                while(rslt.next()) {
                    int tmp;

                    count++;

                    datetirage  = rslt.getString("datetirage");

                    if(count==1)
                        firstdate = datetirage;

                    for(int i=0; i<5; i++)
                        boules[i] = Integer.parseInt(rslt.getString("boule" + (i+1)));

                    // Trie les boules.
                    // ----------------
                    boolean found   = true;
                    int     limite  = 4;

                    while(found) {
                        found = false;

                        for(int i=0; i<limite; i++) {
                            if(boules[i] > boules[i+1]) {
                                found = true;
                                tmp         = boules[i];
                                boules[i]   = boules[i+1];
                                boules[i+1] = tmp;
                            }
                        }

                        if(found)
                            limite -=1;
                    }

                    for(int i=0; i<50; i++) {
                        if( i == boules[0]-1 ||
                            i == boules[1]-1 ||
                            i == boules[2]-1 ||
                            i == boules[3]-1 ||
                            i == boules[4]-1)
                            aoccur[i] += 1;
                    }

                    try (Statement sttmnt2 = cnnctn.createStatement()) {
                        String query4   = "Select * "
                                        + "From   lineargap "
                                        + "Where  lindate = '" + datetirage + "'";

                        try (ResultSet rslt2 = sttmnt2.executeQuery(query4)) {
                            if(rslt2.next()) {
                                for(int b=0; b<5; b++) {
                                    lingapstart[boules[b]-1] = rslt2.getInt(boules[b]<10? "lingap0" + boules[b]: "lingap" + boules[b]);
                                }
                            }
                        }

                        sttmnt2.close();
                    }

                    /*---------------------------------*/
                    /*- envoi du tirage aux listeners -*/
                    /*---------------------------------*/
                    DrawListener[] tlist = drawlisteners
                                            .getListeners(DrawListener.class);

                    for(DrawListener l: tlist)
                        l.NewDrawRow(new DrawEvent( obj,
                                                    firstdate,
                                                    datetirage,
                                                    boules,
                                                    aoccur,
                                                    lingapstart,
                                                    null,
                                                    count));
                }

                System.arraycopy(aoccur, 0, glboccurs, 0, glboccurs.length);

                rslt.close();
                sttmnt.close();

                DrawListener[] tlist = drawlisteners
                                            .getListeners(DrawListener.class);

                for(DrawListener l: tlist)
                    l.EndDraw(new DrawEvent(obj,
                                                firstdate,
                                                datetirage,
                                                boules,
                                                aoccur,
                                                lingapstart,
                                                lingapend,
                                                count));

                for(int i=0; i<50; i++) {
                    if(conserve) {
                        if(ballsselected[i]) {
                            ballsselected[i] = false;
                            selectBall(obj, (i+1)<10? "0" + (i+1): "" + (i+1));
                        }
                    }
                    else {
                        ballsselected[i] = false;
                    }
                }
            } catch (SQLException ex) {
                Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void numberGridReseted() {
        CycleNumberGridListener[] cnglist = cyclenumbergridlisteners
                                .getListeners(CycleNumberGridListener.class);

        for(CycleNumberGridListener l: cnglist) {
            l.cycleNumberGridRemoved();
        }
    }

    /*--------------------------------------------------*/
    /*- a d d S y n t h e s i s L i s t e n e r (...)  -*/
    /*--------------------------------------------------*/
    public void addSynthesisListener(SynthesisListener _synthlistnr) {
        synthesislisteners.add(SynthesisListener.class, _synthlistnr);
    }

    /*--------------------------------------------------------*/
    /*-  r e m o v e S y n t h e s i s L i s t e n e r (...) -*/
    /*--------------------------------------------------------*/
    public void removeSynthesisListener(SynthesisListener _synthListnr) {
        synthesislisteners.remove(SynthesisListener.class, _synthListnr);
    }

    /***************************************/
    /** Runnable Class: S y n t h e s i s **/
    /***************************************/
    private class Synthesis implements Runnable {
        private final Object  obj;
        private final String startdate;
        private final String enddate;
        private final String cycletype;
        private final String nbTirage;

        /*-------------------------*/
        /*- C o n s t r u c t o r -*/
        /*-------------------------*/
        public Synthesis( Object  _obj,
                            String  _startdate,
                            String  _enddate,
                            String  _cycletype,
                            String  _nbTirage) {

            obj         = _obj;
            startdate   = _startdate;
            enddate     = _enddate;
            cycletype   = _cycletype;
            nbTirage    = _nbTirage;
        }

        @Override
        public void run() {
            int nbtirage = Integer.parseInt(nbTirage);

            if(cycletype.equalsIgnoreCase("P") || cycletype.equalsIgnoreCase("S"))
                synthesisOfSelectedCycle(obj, nbtirage, startdate, enddate);

            if(cycletype.equalsIgnoreCase("E"))
                synthesisOfInProgressCycle(obj, nbtirage, startdate, enddate);

            synthesisOfProspectCycle(obj, nbtirage+1, startdate, enddate);

            synthesisOfAverageCycles(obj, nbtirage+1, startdate, enddate);
        }

        /*----------------------------------------------------------*/
        /*- s y n t h e s i s O f S e l e c t e d C y c l e (...)  -*/
        /*----------------------------------------------------------*/
        private void synthesisOfSelectedCycle(Object _obj, int _nbtirage, String _startdate, String _enddate) {
            int[] aocc   = new int[100],
                  agap   = new int[100];

            String query_1  = "select   * "
                            + "from     synthese "
                            + "where    synthdatedeb    = '" +  _startdate   +   "' "
                            + "and      synthdatefin    = '" +  _enddate     +   "' "
                            + "and      synthnbtirage   =  " +  _nbtirage;

            try {
                Statement sttmnt_1 = cnnctn.createStatement();
                sttmnt_1.execute(query_1);
                ResultSet rslt_1 = sttmnt_1.getResultSet();

                rslt_1.next();

                String occprefix    = "synthocc";
                String gapprefix    = "synthgap";
                String coloccnm;
                String colgapnm;

                for(int i=0; i<100; i++) {
                    coloccnm = occprefix + ((i<9)? "0" + (i+1): "" + (i+1));
                    colgapnm = gapprefix + ((i<9)? "0" + (i+1): "" + (i+1));

                    aocc[i] = rslt_1.getInt(coloccnm);
                    agap[i] = rslt_1.getInt(colgapnm);
                }

                SynthesisListener[] slist = synthesislisteners
                                        .getListeners(SynthesisListener.class);
                for(SynthesisListener s: slist)
                    s.SyntheseCycles(new SynthesisEvent(_obj,
                                                        true,
                                                        _startdate, _enddate,
                                                        rslt_1.getString("synthrefdebcycle"),
                                                        rslt_1.getString("synthreffincycle"),
                                                        null, aocc, agap,
                                                        rslt_1.getString("synthcycletype"),
                                                        1,
                                                        _nbtirage));
            }
            catch (SQLException ex) {
                Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        /*----------------------------------------------------------*/
        /*- s y n t h e s i s O f P r o s p e c t C y c l e (...)  -*/
        /*----------------------------------------------------------*/
        private void synthesisOfProspectCycle(Object _obj, int _nbtirage, String _startdate, String _enddate) {
            int[] aocc, agap;

            String query_1  = "select   * "
                            + "from     synthese "
                            + "Where    synthnbtirage   =  " +  _nbtirage + " "
                            + "And      synthcycletype not in('A', 'E') "
                            + "Order by synthdatedeb ";

            try {
                Statement sttmnt_1 = cnnctn.createStatement();
                sttmnt_1.execute(query_1);
                ResultSet rslt_1 = sttmnt_1.getResultSet();

                String occprefix    = "synthocc";
                String gapprefix    = "synthgap";

                while(rslt_1.next()) {
                    aocc   = new int[100];
                    agap   = new int[100];

                    String coloccnm;
                    String colgapnm;

                    for(int i=0; i<100; i++) {
                        coloccnm = occprefix + ((i<9)? "0" + (i+1): "" + (i+1));
                        colgapnm = gapprefix + ((i<9)? "0" + (i+1): "" + (i+1));

                        aocc[i] = rslt_1.getInt(coloccnm);
                        agap[i] = rslt_1.getInt(colgapnm);
                    }

                    SynthesisListener[] slist = synthesislisteners
                                        .getListeners(SynthesisListener.class);

                    for(SynthesisListener s: slist)
                        s.SyntheseCycles(new SynthesisEvent(_obj,
                                                            false,
                                                            _startdate, _enddate,
                                                            rslt_1.getString("synthrefdebcycle"), rslt_1.getString("synthreffincycle"),
                                                            null, aocc, agap,
                                                            rslt_1.getString("synthcycletype"),
                                                            1,
                                                            _nbtirage));

                }
            }
            catch (SQLException ex) {
                Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        /*-------------------------------------------------------------*/
        /*- s y n t h e s i s O f I n P r o g r e s s C y c l e (...) -*/
        /*-------------------------------------------------------------*/
        private void synthesisOfInProgressCycle(Object _obj, int _nbtirage, String _startdate, String _enddate) {
            int[] aocc, agap;

            String query_1  = "select   * "
                            + "from     synthese "
                            + "Where    synthnbtirage   =  " +  _nbtirage + " "
                            + "And      synthcycletype not in('P', 'S', 'A') "
                            + "Order by synthdatedeb ";

            try {
                Statement sttmnt_1 = cnnctn.createStatement();
                sttmnt_1.execute(query_1);
                ResultSet rslt_1 = sttmnt_1.getResultSet();

                String occprefix    = "synthocc";
                String gapprefix    = "synthgap";

                while(rslt_1.next()) {
                    aocc   = new int[100];
                    agap   = new int[100];

                    String coloccnm;
                    String colgapnm;

                    for(int i=0; i<100; i++) {
                        coloccnm = occprefix + ((i<9)? "0" + (i+1): "" + (i+1));
                        colgapnm = gapprefix + ((i<9)? "0" + (i+1): "" + (i+1));

                        aocc[i] = rslt_1.getInt(coloccnm);
                        agap[i] = rslt_1.getInt(colgapnm);
                    }

                    SynthesisListener[] slist = synthesislisteners
                                        .getListeners(SynthesisListener.class);

                    for(SynthesisListener s: slist)
                        s.SyntheseCycles(new SynthesisEvent(_obj,
                                                            false,
                                                            _startdate, _enddate,
                                                            rslt_1.getString("synthrefdebcycle"), rslt_1.getString("synthreffincycle"),
                                                            glboccurs, aocc, agap,
                                                            rslt_1.getString("synthcycletype"),
                                                            1,
                                                            _nbtirage));

                }
            }
            catch (SQLException ex) {
                Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        /*---------------------------------------------------------*/
        /*- s y n t h e s i s O f A v e r a g e C y c l e s (...) -*/
        /*---------------------------------------------------------*/
        private void synthesisOfAverageCycles(Object _obj, int _nbtirage, String _startdate, String _enddate) {
            int[] aocc, agap;

            String query_1  = "select   * "
                            + "from     synthese "
                            + "Where    synthnbtirage   =  " +  _nbtirage + " "
                            + "And      synthcycletype not in('P', 'S', 'E') "
                            + "Order by synthdatedeb ";

            try {
                Statement sttmnt_1 = cnnctn.createStatement();
                sttmnt_1.execute(query_1);
                ResultSet rslt_1 = sttmnt_1.getResultSet();

                String occprefix    = "synthocc";
                String gapprefix    = "synthgap";

                while(rslt_1.next()) {
                    aocc   = new int[100];
                    agap   = new int[100];

                    String coloccnm;
                    String colgapnm;

                    for(int i=0; i<100; i++) {
                        coloccnm = occprefix + ((i<9)? "0" + (i+1): "" + (i+1));
                        colgapnm = gapprefix + ((i<9)? "0" + (i+1): "" + (i+1));

                        aocc[i] = rslt_1.getInt(coloccnm);
                        agap[i] = rslt_1.getInt(colgapnm);
                    }

                    SynthesisListener[] slist = synthesislisteners
                                       .getListeners(SynthesisListener.class);

                    for(SynthesisListener s: slist)
                        s.SyntheseCycles(new SynthesisEvent(_obj,
                                                            false,
                                                            _startdate, _enddate,
                                                            rslt_1.getString("synthrefdebcycle"), rslt_1.getString("synthreffincycle"),
                                                            null, aocc, agap,
                                                            rslt_1.getString("synthcycletype"),
                                                            1,
                                                            _nbtirage));
                }
            }
            catch (SQLException ex) {
                Logger.getLogger(Model.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /*----------------------------------------------------*/
    /*- a d d S c h e m a O c c s L i s t e n e r (...)  -*/
    /*----------------------------((----------------------*/
    public void addSchemaOccssisListener(SchemaOccsListener _shemaoccslstnr) {
       schemaoccslisteners.add(SchemaOccsListener.class, _shemaoccslstnr);
    }

    /*----------------------------------------------------------*/
    /*-  r e m o v e S c h e m a O c c s L i s t e n e r (...) -*/
    /*----------------------------------------------------------*/
    public void removeSchemaOccsListener(SchemaOccsListener _shemaoccslstnr) {
        synthesislisteners.remove(SchemaOccsListener.class, _shemaoccslstnr);
    }

    /*****************************************/
    /** Runnable Class: S c h e m a O c c s **/
    /*****************************************/
    private class SchemaOccs implements Runnable {
        private final   Object  obj;
        private final   String  startdate,
                                enddate;
        private final   String  cycletype;

        /*-------------------------*/
        /*- C o n s t r u c t o r -*/
        /*-------------------------*/
        public SchemaOccs( Object  _obj,
                            String  _startdate,
                            String  _enddate,
                            String  _cycletype) {

            obj             = _obj;
            startdate    = _startdate;
            enddate      = _enddate;
            cycletype       = _cycletype;
        }

        @Override
        public void run() {
            Statement sttmnt_1  = null;
            ResultSet rslt_1    = null;

            SchemaOccsListener[] solist = schemaoccslisteners
                                       .getListeners(SchemaOccsListener.class);

            try {
                String query_1;

                if( cycletype.equalsIgnoreCase("E"))
                    query_1 = "Select   * "
                            + "From     schemaoccs "
                            + "Where    schorefdebcycle between '0001-01-01' And '0001-01-01' "
                            + "Order by schodrawdate desc";
                else
                    query_1 = "Select   * "
                            + "From     schemaoccs "
                            + "Where    schorefdebcycle = '" + startdate + "' And schoreffincycle = '" + enddate + "' "
                            //+ "Where    schodrawdate between '" + startdate + "' And '" + enddate + "' "
                            + "Order by schodrawdate desc";

                sttmnt_1 = cnnctn.createStatement();
                sttmnt_1.execute(query_1);

                rslt_1 = sttmnt_1.getResultSet();

                while(rslt_1.next()) {
                    int[] aschoccs = new int[5];

                    for(int i=0; i<aschoccs.length; i++) {
                        aschoccs[i] = rslt_1.getInt("schemao" + (i+1) );
                    }

                    for(SchemaOccsListener s: solist)
                        s.newSchema(new SchemaOccsEvent(obj,
                                                        null,
                                                        rslt_1.getString("schodrawdate"),
                                                        startdate,
                                                        enddate,
                                                        rslt_1.getString("schorefdebcycle"),
                                                        rslt_1.getString("schoreffincycle"),
                                                        aschoccs,
                                                        rslt_1.getLong("schemaobit")
                                                        ));
                }

                rslt_1.close();
                sttmnt_1.close();
            }
            catch(SQLException ex) {
                ex.printStackTrace();

                try {
                    if(rslt_1   != null) rslt_1.close();
                    if(sttmnt_1 != null) sttmnt_1.close();
                }
                catch(SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /*--------------------------------------------*/
    /*- a d d N e w D a t aL i s t e n e r (...) -*/
    /*--------------------------------------------*/
    public void addNewDataListener(NewDataListener _nwdta) {
        newdatalisteners.add(NewDataListener.class, _nwdta);
    }

    /*---------------------------------------------------*/
    /*- r e m o v e N e w D a t a L i s t e n e r (...) -*/
    /*---------------------------------------------------*/
    public void removeNewDataListener(NewDataListener _nwdta) {
        newdatalisteners.remove(NewDataListener.class, _nwdta);
    }

    /*-------------------------------*/
    /*- n e w C y c l e D a t e ( ) -*/
    /*-------------------------------*/
    private void newCycleDate() {
        NewDataListener[] nwdatatlstnr = newdatalisteners
                                           .getListeners(NewDataListener.class);

        for(NewDataListener l: nwdatatlstnr) {
                    l.newCycleDate();
        }
    }

    //==========================================================================

    /*********************************/
    /** Runnable Class: integration **/
    /*********************************/
    private class integration implements Runnable {
        private final Object obj;

        /*-------------------------*/
        /*- C o n s t r u c t o r -*/
        /*-------------------------*/
        public integration(Object _obj, ModelView _mdlvw ) {
            obj = _obj;
        }

        @Override
        public void run() {
            System.out.println("Début d'intégration.");
            modelvw.sendMessageToSystray(obj, "Début d'intégration");

            new EuromillionsIntergre().integre(cnnctn, modelvw);

            System.out.println("Fin d'intégration.");
            modelvw.sendMessageToSystray(obj, "Fin d'intégration");

            getGrouppsCycle(obj);
            integrationEnd(obj);
        }
    }
}



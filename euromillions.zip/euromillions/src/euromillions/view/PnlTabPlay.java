/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view;

import euromillions.view.playgrid.PnlPlayGridValidation;
import euromillions.view.playgrid.PnlPlayBallsGrid;
import euromillions.view.playgrid.PnlPlayStarsGrid;
import euromillions.controller.Controller;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class PnlTabPlay extends     JPanel {
    private final   Controller  ctrlr;

    private         PnlPlayBallsGrid        playballgrid;
    private         PnlPlayStarsGrid        playstargrid;
    private         PnlPlayGridValidation   playvalidate;

    public PnlTabPlay(Controller _ctrlr) {
        ctrlr = _ctrlr;
    }

    public void mkView() {
        if(playballgrid!=null)
            return;

        setLayout(new MigLayout("wrap 1"));

        // Titre général.
        // --------------
        PnlTitle pnlgridtitle = new PnlTitle(   FlowLayout.CENTER,
                                                "Grille des jeux",
                                                euromillions.EuroMillions.SELECTED_COLOR,
                                                40);
        pnlgridtitle.mkView();
        add(pnlgridtitle);

        // Grille de billess.
        // ------------------
        PnlTitle pnlballstitle = new PnlTitle(   FlowLayout.LEFT,
                                                "Billess",
                                                Color.blue,
                                                20);
        pnlballstitle.mkView();
        add(pnlballstitle);

        playballgrid = new PnlPlayBallsGrid(ctrlr);
        playballgrid.mkView();
        add(playballgrid);

        // Grille de étoiles.
        // ------------------
        PnlTitle pnlstarstitle = new PnlTitle(  FlowLayout.LEFT,
                                                "Etoiles",
                                                Color.blue,
                                                20);
        pnlstarstitle.mkView();
        add(pnlstarstitle);

        playstargrid = new PnlPlayStarsGrid(ctrlr);
        playstargrid.mkView();
        add(playstargrid);

        // Panneau de validation du jeu.
        // -----------------------------
        PnlTitle pnlvalidatetitle = new PnlTitle(   FlowLayout.LEFT,
                                                    "Validation",
                                                    Color.blue,
                                                    20);
        pnlvalidatetitle.mkView();
        add(pnlvalidatetitle);

        playvalidate = new PnlPlayGridValidation(ctrlr);
        playvalidate.mkView();
        add(playvalidate);


    }

    private void resetPanel() {
        this.removeAll();
        getParent().getParent().getParent().revalidate();
        this.repaint();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.statscycle;

import euromillions.controller.Controller;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;

/**
 *
 * @author Stéphane
 */
public class PnlStatsList extends JPanel{

    private final Controller ctrlr;

    private final PnlStatsHeader    pnlStatsHeader;
    private final JScrollPane       scrlStatsDetail;
    private final PnlStatsDetail    pnlStatsListDetail;

    public PnlStatsList(Controller _ctrlr) {
        ctrlr   =   _ctrlr;

        pnlStatsHeader      =   new PnlStatsHeader(ctrlr);
        pnlStatsListDetail  =   new PnlStatsDetail(ctrlr);
        scrlStatsDetail     =   new JScrollPane(pnlStatsListDetail);
        scrlStatsDetail.getVerticalScrollBar().setUnitIncrement(16);
    }

    public void mkView() {
        setLayout(new BorderLayout());
        setBorder(new LineBorder(Color.pink));

        add(pnlStatsHeader, BorderLayout.NORTH);
        add(scrlStatsDetail, BorderLayout.CENTER);
    }
}

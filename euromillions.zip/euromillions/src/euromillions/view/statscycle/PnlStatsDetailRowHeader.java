/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.statscycle;

import euromillions.controller.Controller;
import java.awt.Font;
import java.awt.font.TextAttribute;
import java.util.Map;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlStatsDetailRowHeader  extends JPanel {
    private Controller ctrlr;

    private final JLabel  lblTitle;

    private final MigLayout mglyt;

    private final Font font;

    public PnlStatsDetailRowHeader(Controller _ctrlr, String _title) {
        ctrlr = _ctrlr;


        mglyt = new MigLayout("wrap 1");
        this.setLayout(mglyt);

        font = new Font("Courrie New", Font.BOLD, 20);

        lblTitle = new JLabel(_title);

        Map attributes = font.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
        lblTitle.setFont(font.deriveFont(attributes));

        setOpaque(true);

        add(lblTitle);
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.statscycle;

import euromillions.controller.Controller;
import euromillions.event.SynthesesAvTirageEvent;
import euromillions.event.SynthesesNbTirageEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import euromillions.listener.DrawListener;

/**
 *
 * @author Stéphane
 */
public class PnlStatsDetailRowFinal extends     JPanel
                                    implements  DrawListener {
    private Controller ctrlr;

    private final MigLayout mglyt;

    private final Font  font12,
                        font16;

    private final   JButton[][] btnOccurs;
    private final   JButton[][] btnGaps;
    private final   JButton[][] btnGapsEnd;
    private final   JButton[][] btnGapsDiff;

    private final   int[]   occurs;
    private final   int[]   gaps;
    private final   int[]   gapsend;

    private final   boolean booloccurs;
    private final   boolean boolgaps;

    private final   String  occurence   =   "occurence",
                            occurences  =   "occurences",
                            tirage      =   "tirage",
                            tirages     =   "tirages";

    int ball=0;

    public PnlStatsDetailRowFinal(  Controller _ctrlr,
                                    DrawEvent _lastTirage,
                                    int[]       _occurs,
                                    int[]       _gaps,
                                    int[]       _gapsend) {
        ctrlr = _ctrlr;

        //boules = _boules;
        mglyt = new MigLayout("wrap 51", "3 [7] 3 [7] 3[7]");
        this.setLayout(mglyt);

        setOpaque(true);

        font12 = new Font("Courrier New", Font.PLAIN, 12);
        font16 = new Font("Courrier New", Font.BOLD, 16);

        occurs      = _lastTirage.getOccurences();
        gaps        = _lastTirage.getLinearGapStart();
        gapsend     = _gapsend;

        booloccurs  =  _occurs   !=  null;
        boolgaps    = _gaps     !=  null;

        btnOccurs   = new JButton[100][50];
        btnGaps     = new JButton[100][50];
        btnGapsEnd  = new JButton[100][50];
        btnGapsDiff = new JButton[200][50]; // 0 à 99 écart négatif. 100 à 199 écart positif.

        /* Panneau des occurences. */
        /* ----------------------- */
        if(booloccurs) {
            //Prépare la création des boutons à afficher.
            // ------------------------------------------
            for(int i=0; i<occurs.length; i++) {
                if(occurs[i]> 0) {
                    btnOccurs[occurs[i]-1][i] = new JButton(    ((i+1)<10?
                                                                    "0" + (i+1):
                                                                    "" +  (i+1))
                                                                + "," + gapsend[i]);
                    btnOccurs[occurs[i]-1][i].setForeground(Color.black);
                }
            }


            boolean newline = true;

            for(int i=0; i<100; i++) {
                int last = 0;

                    // Detrmine le dernier bouton pour
                    // pouvoir faire un saut de ligne.
                    // -------------------------------
                    for(int j=49; j>=0; j--)
                        if(btnOccurs[i][j]!=null) {
                            last = j;
                            break;
                        }

                    // Affiche les boutons créés.
                    // -------------------------
                    for(int j=0; j<50; j++) {
                        if(btnOccurs[i][j]!=null) {

                            if(newline) {
                                newline = false;
                                add(new JLabel("" + (i+1) + " " + ((i+1)==1?
                                                                occurence:
                                                                occurences)) );
                            }

                            // Avec saut de lihgne ("wrap").
                            // -----------------------------
                            if(j==last) {
                                add(btnOccurs[i][j], "wrap");
                                newline = true;
                            }

                            // Sans saut de ligne.
                            // -------------------
                            else {
                                add(btnOccurs[i][j]);
                            }
                        }
                    }
            }
        }
        /* Panneau des ecarts. */
        /* ------------------- */
        else {
            int igap = 0;
/*
            JLabel lblGapsEndLast = new JLabel("Ecarts du dernier tirage de chaque numéro");
            lblGapsEndLast.setFont(font16);

            add(lblGapsEndLast, "wrap");
            //Prépare la création des boutons à afficher.
            // ------------------------------------------
            for(int i=0; i<gaps.length; i++) {
                if(gaps[i]<0)
                    igap = gaps[i]*-1;
                else
                    igap = gaps[i];

                if(igap>0) {
                    btnGaps[igap-1][i] = new JButton( ((i+1)<10?
                                                            "0" + (i+1):
                                                            "" +  (i+1)) );
                    btnGaps[igap-1][i].setForeground(Color.black);
                }
            }

            boolean newline = true;

            for(int i=0; i<100; i++) {
                int last = 0;

                // Affiche le nombre d'écarts.
                // ---------------------------
                    // Determine le dernier bouton pour
                    // pouvoir faire un saut de ligne.
                    // -------------------------------
                    for(int j=49; j>=0; j--)
                        if(btnGaps[i][j]!=null) {
                            last = j;
                            break;
                        }

                    // Affiche les boutonss créés.
                    // ---------------------------
                    for(int j=0; j<50; j++) {
                        if(btnGaps[i][j]!=null) {

                            if(newline) {
                                newline = false;
                                add(new JLabel("Ecart de " + (i+1) + ((i+1)==1?
                                                                " " + tirage:
                                                                " " + tirages)) );
                            }

                            // Avec saut de lihgne ("wrap").
                            // -----------------------------
                            if(j==last) {
                                add(btnGaps[i][j], "wrap");
                                newline = true;
                            }

                            // Sans saut de ligne.
                            // -------------------
                            else {
                                add(btnGaps[i][j]);
                            }
                        }
                    }
            }
*/
            JLabel lblGapsEndCycle = new JLabel("Ecarts de fin de cycle");
            lblGapsEndCycle.setFont(font16);

            add(lblGapsEndCycle, "wrap");

            igap = 0;
            //Prépare la création des boutons à afficher.
            // ------------------------------------------
            for(int i=0; i<gapsend.length; i++) {
                if(gapsend[i]<0)
                    igap = gapsend[i]*-1;
                else
                    igap = gapsend[i];

                if(igap>0) {
                    btnGapsEnd[igap-1][i] = new JButton( ((i+1)<10?
                                                            "0" + (i+1):
                                                            "" +  (i+1)) );
                    btnGapsEnd[igap-1][i].setForeground(Color.black);
                }
            }

            boolean newline = true;

            for(int i=0; i<100; i++) {
                int last = 0;

                    // Detrmine le dernier bouton pour
                    // pouvoir faire un saut de ligne.
                    // -------------------------------
                    for(int j=49; j>=0; j--)
                        if(btnGapsEnd[i][j]!=null) {
                            last = j;
                            break;
                        }

                    // Affiche les boutons créés.
                    // --------------------------
                    for(int j=0; j<50; j++) {
                        if(btnGapsEnd[i][j]!=null) {

                            if(newline) {
                                newline = false;
                                add(new JLabel("Ecart de " + (i+1) + ((i+1)==1?
                                                                " " + tirage:
                                                                " " + tirages)) );
                            }

                            // Avec saut de lihgne ("wrap").
                            // -----------------------------
                            if(j==last) {
                                add(btnGapsEnd[i][j], "wrap");
                                newline = true;
                            }

                            // Sans saut de ligne.
                            // -------------------
                            else {
                                add(btnGapsEnd[i][j]);
                            }
                        }
                    }
            }
/*
            JLabel lblGapsDiff = new JLabel("Difference écarts du dernier tirage et écart de fin de cycle");
            lblGapsDiff.setFont(font16);

            add(lblGapsDiff, "wrap");

            int igap1=0, igap2=0, gapd=0;

            for(int i=0; i<gaps.length; i++) {
                if(gaps[i]<0)
                    igap1 = gaps[i]*-1;
                else
                    igap1 = gaps[i];

                if(gapsend[i]<0)
                    igap2 = gapsend[i]*-1;
                else
                    igap2 = gapsend[i];

                gapd = igap1 - igap2;

                if(gapd < 0)
                    gapd *= -1;
                else if(gapd > 0)
                    gapd += 100;

                btnGapsDiff[gapd][i] = new JButton( ((i+1)<10?
                                                            "0" + (i+1):
                                                            "" +  (i+1)) );
                btnGapsDiff[gapd][i].setForeground(Color.black);
            }

            newline = true;

            for(int i=0; i<200; i++) {
                int last = 0;

                // Detrmine le dernier bouton pour
                // pouvoir faire un saut de ligne.
                // -------------------------------
                for(int j=49; j>=0; j--)
                    if(btnGapsDiff[i][j]!=null) {
                        last = j;
                        break;
                    }

                // Affiche les boutons créés.
                // --------------------------
                for(int j=0; j<50; j++) {
                    if(btnGapsDiff[i][j]!=null) {
                        if(newline) {
                            newline = false;
                            add(new JLabel("Différence de " + ((i==0)?
                                                    "" + i: i<100?
                                                            "-" + i:
                                                            "+" + (i-100))));
                        }

                        // Avec saut de lihgne ("wrap").
                        // -----------------------------
                        if(j==last) {
                            add(btnGapsDiff[i][j], "wrap");
                            newline = true;
                        }

                        // Sans saut de ligne.
                        // -------------------
                        else {
                            add(btnGapsDiff[i][j]);
                        }
                    }
                }
            }
*/
        }

        // Fire bottons action.
        // --------------------
        for(int i=0; i<100; i++) {
            for(int j=0; j<50; j++) {
                if(booloccurs) {
                    if(btnOccurs[i][j]  != null)
                        btnOccurs[i][j].addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                ctrlr.selectBall(this,
                                          ((JButton) ae.getSource()).getText());
                                }
                            });
                }
                else if(boolgaps) {
/*
                    if(btnGaps[i][j]    != null)
                        btnGaps[i][j].addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                ctrlr.selectBall(this,
                                          ((JButton) ae.getSource()).getText().substring(0, 2));
                            }
                        });
*/
                    if(btnGapsEnd[i][j] != null)
                        btnGapsEnd[i][j].addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                ctrlr.selectBall(this,
                                          ((JButton) ae.getSource()).getText());
                            }
                        });
                }
            }
        }
/*
        if(boolgaps) {
            for(int i=0; i<200; i++) {
                for(int j=0; j<50; j++) {
                    if(btnGapsDiff[i][j] != null)
                        btnGapsDiff[i][j].addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent ae) {
                                ctrlr.selectBall(this,
                                          ((JButton) ae.getSource()).getText());
                            }
                        });
                }
            }
        }
*/
    }


    @Override
    public void NewDrawRow(DrawEvent nte) {}

    @Override
    public void EndDraw(DrawEvent nte) {}

    @Override
    public void DrawBallSelected(DrawBallEvent tbe) {
        // Cette méthode met en évidence
        // les numéros sélectionnés.
        // -----------------------------

        // Determine la valeur du numéro choisie.
        // --------------------------------------
        int iball = Integer.parseInt( tbe.getBallNumber()) -1;
        boolean found  = false;
        // Mise en évidence ou pas du numéro choisi parmi les occurences.
        // --------------------------------------------------------------
        if(booloccurs) {
            for(int i=0; i<100 && !found; i++) {
                if(btnOccurs[i][iball] != null) {
                    found = true;
                    if(btnOccurs[i][iball].getForeground() == Color.black) {
                        btnOccurs[i][iball].setForeground(euromillions.EuroMillions.SELECTED_COLOR);
                        btnOccurs[i][iball].setFont(font16);
                    }
                    else {
                        btnOccurs[i][iball].setForeground(Color.black);
                        btnOccurs[i][iball].setFont(font12);
                    }
                }
            }
        }
        // Mise en évidence ou pas du numéro choisi parmi les écarts.
        // ----------------------------------------------------------
        else {
            for(int i=0; i<100 && !found; i++) {
                if(btnGaps[i][iball] != null) {
                    found = true;
                    if(btnGaps[i][iball].getForeground() == Color.black) {
                        btnGaps[i][iball].setForeground(euromillions.EuroMillions.SELECTED_COLOR);
                        btnGaps[i][iball].setFont(font16);
                    }
                    else {
                        btnGaps[i][iball].setForeground(Color.black);
                        btnGaps[i][iball].setFont(font12);
                    }
                }
            }

            found = false;

            for(int i=0; i<100 && !found; i++) {
                if(btnGapsEnd[i][iball] != null) {
                    found = true;
                    if(btnGapsEnd[i][iball].getForeground() == Color.black) {
                        btnGapsEnd[i][iball].setForeground(euromillions.EuroMillions.SELECTED_COLOR);
                        btnGapsEnd[i][iball].setFont(font16);
                    }
                    else {
                        btnGapsEnd[i][iball].setForeground(Color.black);
                        btnGapsEnd[i][iball].setFont(font12);
                    }
                }
            }

            found = false;

            for(int i=0; i<200 && !found; i++) {
                if(btnGapsDiff[i][iball] != null) {
                    found = true;
                    if(btnGapsDiff[i][iball].getForeground() == Color.black) {
                        btnGapsDiff[i][iball].setForeground(euromillions.EuroMillions.SELECTED_COLOR);
                        btnGapsDiff[i][iball].setFont(font16);
                    }
                    else {
                        btnGapsDiff[i][iball].setForeground(Color.black);
                        btnGapsDiff[i][iball].setFont(font12);
                    }
                }
            }
        }
    }

    @Override
    public void StatNbDraw(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatNbDrawE(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatAvNbDraw(SynthesesAvTirageEvent sate) {}
}

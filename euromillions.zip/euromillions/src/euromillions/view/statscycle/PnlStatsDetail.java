/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.statscycle;

import euromillions.controller.Controller;
import euromillions.event.DateEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import euromillions.event.SynthesesAvTirageEvent;
import euromillions.event.SynthesesNbTirageEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import euromillions.listener.DateDetailRowListener;
import euromillions.listener.NewDataListener;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import euromillions.listener.GrpDetailRowListener;
import euromillions.listener.IntegrationListener;
import euromillions.listener.DrawListener;

/**
 *
 * @author Stéphane
 */
public class PnlStatsDetail extends     JPanel
                            implements  NewDataListener,
                                        DrawListener,
                                        GrpDetailRowListener,
                                        DateDetailRowListener,
                                        IntegrationListener {
    private final   Controller              ctrlr;

    private final   MigLayout           mglyt;

    private         PnlStatsDetailRow       pnlOccurs,
                                            pnlGaps;
    private         PnlStatsDetailRowFinal  pnlOccursFinal,
                                            pnlGapsFinal;

    private         PnlStatsDetailNbTirageRow pnlStatsDetailNbTirageRow;

    private final   int[]       occurs;
    private final   boolean[][] booloccs;
    private final   int[]       gaps;
    private final   int[][]     gapsocc;
    private         int         nbtirage = 0;

    private         DrawEvent lastTirageEvent;

    public PnlStatsDetail(Controller _ctrlr) {
        ctrlr = _ctrlr;

        occurs      =   new int[30];
        booloccs    =   new boolean[30][50];
        gaps        =   new int[100];
        gapsocc     =   new  int[100][50];

        ctrlr.addNewDataListener(this);
        ctrlr.addTirageListener(this);
        ctrlr.addCycleDetailRowListener(this);
        ctrlr.addDateDetailRowListener(this);
        ctrlr.addIntegrationListener(this);

        mglyt = new MigLayout("wrap 1", "3 [7] 3 [7] 3 [7]");
        this.setLayout(mglyt);
    }

    private void resetPanel() {
        nbtirage = 0;

        for(int i=0; i<occurs.length; i++)
            occurs[i] = 0;

        for(int i=0; i<30; i++)
            for(int j=0; j<50; j++)
                booloccs[i][j] = false;

        for(int i = 0; i<gaps.length; i++)
            gaps[i] = 0;

        for(int i=0; i<100; i++)
            for(int j=0; j<50; j++)
                gapsocc[i][j] = 0;

        ctrlr.removeTirageListener(pnlOccursFinal);
        ctrlr.removeTirageListener(pnlGapsFinal);
        ctrlr.removeTirageListener(pnlOccurs);
        ctrlr.removeTirageListener(pnlGaps);

        removeAll();
        getParent().getParent().getParent().getParent().revalidate();
        repaint();
    }

    @Override
    public void NewDrawRow(DrawEvent nte) {
        int[] boules    = nte.getBoules();
        int[] occur     = nte.getOccurences();
        int[] gap       = nte.getLinearGapStart();
        int gp;

        lastTirageEvent = nte;

        for(int i=0; i<boules.length; i++) {
            if(!booloccs[occur[boules[i]-1]] [boules[i]-1]) {
                booloccs[occur[boules[i]-1]] [boules[i]-1] = true;
                occurs  [occur[boules[i]-1]]  += 1;
            }

            if(gap[boules[i]-1]< 0)
                gp = gap[boules[i]-1]*-1;
            else
                gp = gap[boules[i]-1];

            gaps[gp]                    += 1;
            gapsocc[gp] [boules[i]-1]   += 1;
        }

        nbtirage += 1;
    }

    /**
     *
     * @param nte
     */
    @Override
    public void EndDraw(DrawEvent nte) {
        int total = nbtirage ;
        int sommeoccurs = 0, sommegaps = 0;

        add(new PnlStatsDetailRowHeader(ctrlr, "OCCURENCES"));

        for(int i=0; i<occurs.length; i++) {
            if(occurs[i]> 0) {
                sommeoccurs += occurs[i];
            }
        }

        pnlOccurs = new PnlStatsDetailRow(  ctrlr,  nbtirage,
                                            occurs, booloccs,
                                            null,   null);
        add(pnlOccurs);


        // Affichage des numéros classés par écart rencontrés sur tous les tirage du cycle.
        // --------------------------------------------------------------------------------
        add(new PnlStatsDetailRowHeader(ctrlr, "ECARTS"));

        for(int i=0; i<gaps.length; i++) {
            if(gaps[i]> 0) {
                sommegaps += gaps[i];
            }
        }

        pnlGaps = new PnlStatsDetailRow( ctrlr, nbtirage,
                                                null,   null,
                                                gaps,   gapsocc);

        add(pnlGaps);

        // Affichage des occurences total des numéros sur tout le cycle et classés par occurence.
        // --------------------------------------------------------------------------------------
        add(new PnlStatsDetailRowHeader(ctrlr, "Occurences de Fin de cycle au dernier tirage"));
        pnlOccursFinal  =   new PnlStatsDetailRowFinal(ctrlr, lastTirageEvent, occurs, null, nte.getLinearGapEnd());
        ctrlr.addTirageListener(pnlOccursFinal);
        add(pnlOccursFinal);

        // Affichage des numéro classé par écart. Ecarts linéaire du dernier tirage du cycle.
        // ----------------------------------------------------------------------------------
        add(new PnlStatsDetailRowHeader(ctrlr, "Ecarts de la dernière sortie et de fin de cycle"));
        pnlGapsFinal    =   new PnlStatsDetailRowFinal(ctrlr, lastTirageEvent, null, gaps, nte.getLinearGapEnd());
        ctrlr.addTirageListener(pnlGapsFinal);
        add(pnlGapsFinal);
    }


    @Override
    public void DrawBallSelected(DrawBallEvent tbe) {}

    // Affichage stats pour un nombre de tirage les occurences et les écarts linéaires cumulés.
    // ----------------------------------------------------------------------------------------
    @Override
    public void StatNbDraw(SynthesesNbTirageEvent _snte) {}
    /*public void StatNbDraw(StatNbTirageEvent _snte) {
        add(new PnlStatsDetailRowHeader(ctrlr, "Occurences et ecarts cumulés sur les cycles de " + _snte.getNbTirage() + " tirages"));
        pnlStatsDetailNbTirageRow = new PnlStatsDetailNbTirageRow(ctrlr,
                                                                  _snte.getNbTirage(),
                                                                  _snte.getAOcc(),
                                                                  _snte.getAGap());
        add(pnlStatsDetailNbTirageRow);
    }*/

    @Override
    public void newCycleDate() {
        resetPanel();
    }

    @Override
    public void newNumber() {}

    @Override
    public void newLinearGap() {}

    @Override
    public void newTirage() {}

    @Override
    public void grpDetailRowSelected(GrouppEvent gce) {
        resetPanel();
    }

    @Override
    public void dateDetailRowSelected(DateEvent dce) {
        resetPanel();
    }

    @Override
    public void integrationStart(IntegrationEvent ie) {
        resetPanel();
    }

    @Override
    public void integrationEnd(IntegrationEvent ie) {}

    @Override
    public void integrationAddGrpRow(GrouppEvent gce) {}

    @Override
    public void integrationAddDateRow(DateEvent dce) {}

    @Override
    public void StatNbDrawE(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatAvNbDraw(SynthesesAvTirageEvent sate) {}
}

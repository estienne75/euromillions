/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.statscycle;

import euromillions.controller.Controller;
import euromillions.event.SynthesesAvTirageEvent;
import euromillions.event.SynthesesNbTirageEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import euromillions.listener.DrawListener;

/**
 *
 * @author Stéphane
 */
public class PnlStatsDetailRow  extends     JPanel
                                implements  DrawListener {
    private Controller ctrlr;

    private final MigLayout mglyt;

    private final Font  font12,
                        font16;

    private final   JLabel[][] lblOccurs;
    private final   JLabel[][] lblOccursfalse;
    private final   JLabel[][] lblGaps;

    private final   int[]   occurs;
    private final   boolean booloccs[][];
    private final   int[]   gaps;
    private final   int[][] gapsocc;

    private final   String  numero          =   "numéro",
                            numeros         =   "numéros",
                            sorti           =   "Sorti",
                            sortis          =   "Sortis",
                            represente      =   "représente",
                            representent    =   "représentent";

    public PnlStatsDetailRow(   Controller  _ctrlr,
                                int         _nbtirage,
                                int[]       _occurs,
                                boolean[][] _booloccs,
                                int[]       _gaps,
                                int[][]     _gapsocc) {
        ctrlr = _ctrlr;

        mglyt = new MigLayout("wrap 53", "3 [7] 3 [7] 3[7]");
        this.setLayout(mglyt);

        setOpaque(true);

        font12 = new Font("Courrier New", Font.PLAIN, 12);
        font16 = new Font("Courrier New", Font.PLAIN, 16);

        occurs      = _occurs;
        booloccs    = _booloccs;
        gaps        = _gaps;
        gapsocc     = _gapsocc;

        lblOccurs       = new JLabel[100][50];
        lblOccursfalse  = new JLabel[100][50];
        lblGaps         = new JLabel[100][50];


        /* Panneau des occurences. */
        /* ----------------------- */
        if(occurs != null) {
            for(int i=0; i<occurs.length; i++) {
                if(occurs[i]> 0) {
                    float f;
                    f = ((float)occurs[i]/((float)_nbtirage*5)) * 100;

                    add(new JLabel("" + (occurs[i]==1?
                                                    sorti:
                                                    sortis)
                                        + " " + i + " fois -> "));
                    add(new JLabel("" + (occurs[i]<10?
                                                "0" +   occurs[i]:
                                                        occurs[i])
                                                + " " + (occurs[i]==1?  numero:
                                                                        numeros)
                                                                    + " ->"));
                    add(new JLabel( (occurs[i] == 1?
                                                    represente:
                                                    representent)
                                        + " " + f + "% soit:"));

                    for(int j=0; j<50; j++) {
                        if(booloccs[i][j]) {
                            lblOccurs[i][j] = new JLabel((j+1)<10?
                                                "0" + (j+1):
                                                ""  + (j+1));
                            lblOccurs[i][j].setForeground(Color.black);

                            add(lblOccurs[i][j]);
                        }
                    }

                    for(int j=0; j<50; j++) {
                        if(!booloccs[i][j]) {
                            lblOccursfalse[i][j] = new JLabel((j+1)<10?
                                                        "0" + (j+1):
                                                        ""  + (j+1));

                            lblOccursfalse[i][j].setForeground(Color.red);
                            add(lblOccursfalse[i][j]);
                        }
                    }
                }
            }
        }
        /* Panneau des ecarts. */
        /* ------------------- */
        else {
            for(int i=0; i<gaps.length; i++) {
                if(gaps[i]> 0) {
                    float f;
                    f = ((float)gaps[i]/((float)_nbtirage*5)) * 100;

                    add(new JLabel("Ecart de " + i + " -> "));
                    add(new JLabel("" + (gaps[i]<10?
                                                    "0" +gaps[i]:
                                                    ""  + gaps[i]) + " "
                                                        + (gaps[i]==1?
                                                                        numero:
                                                                        numeros)
                                                        + " ->"));
                    add(new JLabel( (gaps[i] == 1?
                                                represente:
                                                representent)
                                        + " " + f + "% soit:"));

                    int last = 0;

                    // determine le dernier ecart présent dans gapsocc
                    // pour savoir quand faire un retour à la ligne
                    // ("wrap") lors de l'affichage des ecarts.
                    // -----------------------------------------------
                    for(int j=49; j>=0; j--)
                        if(gapsocc[i][j]>0) {
                            last = j;
                            break;
                        }

                    for(int j=0; j<50; j++) {
                        if(gapsocc[i][j]>0) {
                            //lblOccurs[j] =
                            if(j == last) {
                                lblGaps[i][j] = new JLabel((j+1)<10?
                                            "0" + (j+1) + "," + gapsocc[i][j]:
                                            ""  + (j+1) + "," + gapsocc[i][j]);
                                add(lblGaps[i][j], "wrap");
                            }
                            else {
                                lblGaps[i][j] = new JLabel((j+1)<10?
                                            "0" + (j+1) + "," + gapsocc[i][j]:
                                            ""  + (j+1) + "," + gapsocc[i][j]);

                                add(lblGaps[i][j]);
                            }

                            lblGaps[i][j].setForeground(Color.black);
                        }
                    }
                }
            }
        }

        ctrlr.addTirageListener(this);
    }


    @Override
    public void NewDrawRow(DrawEvent nte) {}

    @Override
    public void EndDraw(DrawEvent nte) {}

    @Override
    public void DrawBallSelected(DrawBallEvent tbe) {
        // Cette méthode met en évidence les numéros
        // sélectionnés dans la grille de synthèse.
        // -----------------------------------------


        // Determine la valeur ddu numéro choisie.
        // ---------------------------------------
        int iball = Integer.parseInt( tbe.getBallNumber()) -1;

        // Mise en évidence ou pas du numéro choisi parmi les occurences.
        // --------------------------------------------------------------
        if(occurs != null) {
            for(int i =0; i<occurs.length; i++) {
                if(occurs[i] > 0) {
                    if(booloccs[i][iball]) {
                        if(lblOccurs[i][iball].getForeground() == Color.black) {

                            lblOccurs[i][iball].setForeground(euromillions.EuroMillions.SELECTED_COLOR);
                            lblOccurs[i][iball].setFont(font16);
                        }
                        else {
                            lblOccurs[i][iball].setForeground(Color.black);
                            lblOccurs[i][iball].setFont(font12);
                        }
                    }
                    else if(lblOccursfalse[i][iball]!=null){
                        if(lblOccursfalse[i][iball].getForeground() == Color.red) {
                            lblOccursfalse[i][iball].setForeground(Color.magenta);
                            lblOccursfalse[i][iball].setFont(font16);
                        }
                        else {
                            lblOccursfalse[i][iball].setForeground(Color.red);
                            lblOccursfalse[i][iball].setFont(font12);
                        }
                    }
                }
            }
        }
        // Mise en évidence ou pas du numéro choisi parmi les écarts.
        // ----------------------------------------------------------
        else {
            for(int i =0; i<gaps.length; i++) {
                if(lblGaps[i][iball]!=null) {
                    if(lblGaps[i][iball].getForeground() == Color.black) {
                        lblGaps[i][iball].setForeground(euromillions.EuroMillions.SELECTED_COLOR);
                        lblGaps[i][iball].setFont(font16);
                    }
                    else {
                        lblGaps[i][iball].setForeground(Color.black);
                        lblGaps[i][iball].setFont(font12);
                    }
                }
            }
        }
    }

    @Override
    public void StatNbDraw(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatNbDrawE(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatAvNbDraw(SynthesesAvTirageEvent sate) {}
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.statscycle;

import euromillions.controller.Controller;
import euromillions.event.SynthesesNbTirageEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import euromillions.listener.DrawListener;

/**
 *
 * @author Stéphane
 */
public class PnlStatsDetailNbTirageRow  extends JPanel {
    private Controller ctrlr;

    private final MigLayout mglyt;

    private final Font  font12,
                        font16;

    private final   JLabel[] lblOccurs;
    private final   JLabel[] lblGaps;

    private final   int[]   occurs;
    private final   int[]   gaps;

    private final   String  numero          =   "numéro",
                            numeros         =   "numéros",
                            sorti           =   "Sorti",
                            sortis          =   "Sortis",
                            represente      =   "représente",
                            representent    =   "représentent";

    public PnlStatsDetailNbTirageRow(   Controller  _ctrlr,
                                        int         _nbtirage,
                                        int[]       _occurs,
                                        int[]       _gaps) {
        ctrlr = _ctrlr;

        mglyt = new MigLayout("wrap 100", "20[7] 20[7] 20[7]");
        this.setLayout(mglyt);

        setOpaque(true);

        font12 = new Font("Courrier New", Font.PLAIN, 12);
        font16 = new Font("Courrier New", Font.PLAIN, 16);

        occurs      = _occurs;
        gaps        = _gaps;

        lblOccurs       = new JLabel[100];
        lblGaps         = new JLabel[100];
        
        int svi = 0;


        /* Liste des occurences */
        /* -------------------- */
        add(new JLabel("Occurences"));
        
        for(int i=occurs.length-1; i>=0; i--)
            if(occurs[i] != 0) {
                svi = i;
                break;
            }
        
        for(int i=0; i<occurs.length; i++) {
            if(occurs[i]> 0) {
                lblOccurs[i] = new JLabel(
                                (i<10? "0" + i: "" + i)
                            + "," +
                                (occurs[i]<10? "0"  + occurs[i]:
                                               ""   + occurs[i])
                     );
                
                if(i!=svi)
                    add(lblOccurs[i]);
                else
                    add(lblOccurs[i], "wrap");
            }
        }
        
        /* Liste des écarts. */
        /* ----------------- */
        add(new JLabel("Ecarts"));
        
        for(int i=gaps.length-1; i>=0; i--)
            if(gaps[i] != 0) {
                svi = i;
                break;
            }
        
        for(int i=0; i<gaps.length; i++) {
            if(gaps[i]> 0) {
                lblGaps[i] = new JLabel(
                                (i<10? "0" + i: "" + i)
                            + "," +
                                (gaps[i]<10?    "0"  + gaps[i]:
                                                ""   + gaps[i])
                     );
                
                if(i!=svi)
                    add(lblGaps[i]);
                //else
                //    add(lblGaps[i], "wrap");
            }
        }

        //ctrlr.addTirageListener(this);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.drawcycles;

import euromillions.EuroMillions;
import euromillions.controller.Controller;
import euromillions.event.SynthesesAvTirageEvent;
import euromillions.event.SynthesesNbTirageEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import euromillions.listener.DrawListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlDrawDetailRows  extends     JPanel
                                implements  DrawListener {
    private Controller ctrlr;


    private final MigLayout mglyt;

    private final JLabel    lblRowCount;
    private final JLabel    lblDateTirage;
    private final JButton[] btnBoules;
    private final JLabel[]  lblOccur;
    private final JLabel[]  lblLinGap;
    private final int[]     boules;
    private final  boolean[] selected;

    private final Font  font20, font16;

    int ball=0;

    public PnlDrawDetailRows(  Controller _ctrlr,
                                 String _datetirage,
                                 int[]  _boules,
                                 int[]  _occur,
                                 int[]  _lingap,
                                 int    _rowcount) {
        ctrlr = _ctrlr;

        //boules = _boules;
        boules  =   new int[5];

        for(int i=0; i<5; i++) {
            boules[i] = _boules[i];
        }

        selected = new boolean[5];

        mglyt = new MigLayout("wrap 22", "10 [60] 10 [60] 10 [60]");
        this.setLayout(mglyt);

        setOpaque(true);

        font16 = new Font("Courrie New", Font.BOLD, 16);
        font20 = new Font("Courrie New", Font.BOLD, 20);


        lblRowCount   = new JLabel( (   _rowcount<10?
                                            "0" + _rowcount:
                                            ""  + _rowcount)
                                        + ")");

        lblRowCount.setFont(font16);
        lblRowCount.setForeground(Color.blue);

        add(lblRowCount,   "align center");

        lblDateTirage = new JLabel(_datetirage);
        add(lblDateTirage,   "align center");

        btnBoules   = new JButton[5];
        lblOccur    = new JLabel[5];
        lblLinGap   = new JLabel[5];

        String sball=null;

        for(ball=0; ball<5; ball++) {
            btnBoules[ball] = new JButton("" + (_boules[ball]<10?"0"+_boules[ball]:""+_boules[ball]) );

            btnBoules[ball].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent ae) {
                    ctrlr.selectBall(this, ((JButton) ae.getSource()).getText());
                }
            });

            btnBoules[ball].setFont(font20);
            add(btnBoules[ball],   "align center");

            lblOccur[ball] = new JLabel("" + _occur[_boules[ball]-1]);
            add(lblOccur[ball]);

            lblLinGap[ball] = new JLabel("" + _lingap[_boules[ball]-1]);
            add(lblLinGap[ball]);
        }
    }

    private void switchSelectdBall(String _ball, boolean _selected) {
        int iball = Integer.parseInt(_ball);

        for(int i=0; i<5; i++) {
            if(boules[i] == iball) {
                //selected[i] = !selected[i];
                selected[i] = _selected;

                if(selected[i])
                    btnBoules[i].setForeground(euromillions.EuroMillions.SELECTED_COLOR);
                else
                    btnBoules[i].setForeground(Color.black);
            }
        }
    }

    @Override
    public void NewDrawRow(DrawEvent nte) {}

    @Override
    public void EndDraw(DrawEvent nte) {}

    @Override
    public void DrawBallSelected(DrawBallEvent tbe) {
        switchSelectdBall(tbe.getBallNumber(), tbe.getBallStatus());
    }

    @Override
    public void StatNbDraw(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatNbDrawE(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatAvNbDraw(SynthesesAvTirageEvent sate) {}
}

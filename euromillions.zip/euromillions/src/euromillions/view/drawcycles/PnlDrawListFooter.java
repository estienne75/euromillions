/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.drawcycles;

import euromillions.controller.Controller;
import euromillions.event.SynthesesAvTirageEvent;
import euromillions.event.SynthesesNbTirageEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import euromillions.listener.NewDataListener;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import net.miginfocom.swing.MigLayout;
import euromillions.listener.DrawListener;

/**
 *
 * @author Stéphane
 */
public class PnlDrawListFooter    extends JPanel
                                    implements  DrawListener,
                                                NewDataListener {
    private final Controller ctrlr;

    private final MigLayout migLyt;

    private final JButton[] btnNumberOccur;

    private final Font font;

    private final boolean[] selected;

    public PnlDrawListFooter(Controller _ctrlr) {
        selected = new boolean[50];

        ctrlr = _ctrlr;

        migLyt = new MigLayout("wrap 25", "1 [43] 1 [43] 1 [43]");
        setLayout(migLyt);


        btnNumberOccur = new JButton[50];
        font = new Font("Courrie New", Font.BOLD, 8);

        ctrlr.addNewDataListener(this);
        ctrlr.addTirageListener(this);
    }

    private void resetPanel() {
        this.removeAll();
        setBorder (new LineBorder(Color.pink));
        repaint();
    }

    @Override
    public void NewDrawRow(DrawEvent nte) {}

    @Override
    public void newCycleDate() {
        resetPanel();
    }

    @Override
    public void newNumber() {
        resetPanel();
    }

    @Override
    public void newLinearGap() {}

    @Override
    public void newTirage() {
        resetPanel();
    }

    @Override
    public void EndDraw(DrawEvent nte) {
        int[] occ = nte.getOccurences();

        for(int i=0; i<50; i++) {
            btnNumberOccur[i] = new JButton( ((i+1)<10?   "0" + (i+1):    "" + (i+1))
                                            + "="
                                            + (occ[i]<10? "0" + occ[i]:   "" + occ[i])) ;




            Dimension dim =  btnNumberOccur[i].getPreferredSize();

            //System.out.println("w=" + dim.getWidth() + " h=" + dim.getHeight());

            //dim = new Dimension(53, 28);

            //btnNumberOccur[i].setPreferredSize(dim);
            //btnNumberOccur[i].setMaximumSize(dim);
            //btnNumberOccur[i].setMinimumSize(dim);

            btnNumberOccur[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent ae) {
                    ctrlr.selectBall(this, ((JButton) ae.getSource()).getText().substring(0, 2));
                }
            });

            btnNumberOccur[i].setFont(font);
            add(btnNumberOccur[i]);

        }

    }

    private void switchSelectdBall(String _ball, boolean _selected) {
        int iball = Integer.parseInt(_ball);

        //selected[iball-1] = !selected[iball-1];
        selected[iball-1] = _selected;

        if(selected[iball-1])
            btnNumberOccur[iball-1].setForeground(euromillions.EuroMillions.SELECTED_COLOR);
        else
            btnNumberOccur[iball-1].setForeground(Color.black);
    }


    @Override
    public void DrawBallSelected(DrawBallEvent tbe) {
        if(btnNumberOccur != null && btnNumberOccur[0] != null)
            switchSelectdBall(tbe.getBallNumber(), tbe.getBallStatus());
    }

    @Override
    public void StatNbDraw(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatNbDrawE(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatAvNbDraw(SynthesesAvTirageEvent sate) {}
}

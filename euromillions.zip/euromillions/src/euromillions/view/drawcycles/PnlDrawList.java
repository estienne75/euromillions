/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.drawcycles;

import euromillions.controller.Controller;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;

/**
 *
 * @author Stéphane
 */
public class PnlDrawList extends JPanel {

    private final Controller ctrlr;

    private final PnlDrawListHeader   pnlTirageListHeader;
    private final JScrollPane           scrlTirageDetail;
    private final PnlDrawDetail       pnlTirageDetail;


    public PnlDrawList(Controller _ctrlr) {
        ctrlr = _ctrlr;

        pnlTirageListHeader =   new PnlDrawListHeader(ctrlr);

        pnlTirageDetail     =   new PnlDrawDetail(ctrlr);
        scrlTirageDetail    =   new JScrollPane(pnlTirageDetail);
        scrlTirageDetail.getVerticalScrollBar().setUnitIncrement(16);

        setBorder (new LineBorder(Color.pink));

    }

    public void mkView() {
        setLayout(new BorderLayout());
        add(pnlTirageListHeader, BorderLayout.NORTH);
        add(scrlTirageDetail,    BorderLayout.CENTER);
    }


}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.drawcycles;

import euromillions.controller.Controller;
import euromillions.event.DateEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import euromillions.event.SynthesesAvTirageEvent;
import euromillions.event.SynthesesNbTirageEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import euromillions.listener.IntegrationListener;
import euromillions.listener.NewDataListener;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import euromillions.listener.DrawListener;

/**
 *
 * @author Stéphane
 */
public class PnlDrawListHeader    extends     JPanel
                                    implements  NewDataListener,
                                                DrawListener,
                                                IntegrationListener {
    Controller ctrlr;


    private final JLabel lblTirageInfo;
    private final Font font;

    public PnlDrawListHeader(Controller _ctrlr) {
        ctrlr = _ctrlr;

        setLayout(new FlowLayout());
        font = new Font("Courrie New", Font.BOLD, 40);


        lblTirageInfo       = new JLabel("?");
        lblTirageInfo.setFont(font);
        lblTirageInfo.setForeground(Color.blue);

        add(lblTirageInfo);

        ctrlr.addNewDataListener(this);
        ctrlr.addTirageListener(this);
        ctrlr.addIntegrationListener(this);
    }


    @Override
    public void newCycleDate() {
        lblTirageInfo.setText("?");
    }

    @Override
    public void newNumber() {
        lblTirageInfo.setText("?");
    }

    @Override
    public void newLinearGap() {}

    @Override
    public void newTirage() {
        lblTirageInfo.setText("?");
    }

    @Override
    public void NewDrawRow(DrawEvent nte) {}

    @Override
    public void EndDraw(DrawEvent nte) {
        lblTirageInfo.setText( nte.getRowCount()+ " tirages du cycle " + nte.getFirstDate()+ " / " + nte.getDateTirage());
    }

    @Override
    public void DrawBallSelected(DrawBallEvent tbe) {}

    @Override
    public void integrationStart(IntegrationEvent ie) {
        lblTirageInfo.setText("?");
    }

    @Override
    public void integrationEnd(IntegrationEvent ie) {}

    @Override
    public void integrationAddGrpRow(GrouppEvent gce) {}

    @Override
    public void integrationAddDateRow(DateEvent dce) {}

    @Override
    public void StatNbDraw(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatNbDrawE(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatAvNbDraw(SynthesesAvTirageEvent sate) {}
}

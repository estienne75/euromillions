/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.drawcycles;

import euromillions.controller.Controller;
import euromillions.event.DateEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import euromillions.event.SynthesesAvTirageEvent;
import euromillions.event.SynthesesNbTirageEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import euromillions.listener.IntegrationListener;
import euromillions.listener.NewDataListener;
import java.util.ArrayList;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import euromillions.listener.DrawListener;

/**
 *
 * @author Stéphane
 */
public class PnlDrawDetail    extends     JPanel
                                implements  NewDataListener,
                                            DrawListener,
                                            IntegrationListener {
    private final Controller    ctrlr;

    private final MigLayout     mglyt;

    private final ArrayList<PnlDrawDetailRows> innerModel;

    public PnlDrawDetail(Controller _ctrlr) {
        ctrlr = _ctrlr;
        innerModel = new ArrayList<PnlDrawDetailRows>(100);

        ctrlr.addNewDataListener(this);
        ctrlr.addTirageListener(this);
        ctrlr.addIntegrationListener(this);

        mglyt = new MigLayout("wrap 1", "3 [7] 3 [7] 3 [7]");
        this.setLayout(mglyt);
    }

    private void resetPanel() {
        for(PnlDrawDetailRows ptdr: innerModel)
            ctrlr.removeTirageListener(ptdr);

        innerModel.clear();
        this.removeAll();
        getParent().getParent().getParent().getParent().revalidate();
        repaint();
    }


    @Override
    public void newCycleDate() {
        resetPanel();
    }

    @Override
    public void newNumber() {
        resetPanel();
    }

    @Override
    public void newLinearGap() {}

    @Override
    public void newTirage() {}

    @Override
    public void NewDrawRow(DrawEvent nte) {

        PnlDrawDetailRows row = new PnlDrawDetailRows(  ctrlr,
                                                        nte.getDateTirage(),
                                                        nte.getBoules(),
                                                        nte.getOccurences(),
                                                        nte.getLinearGapStart(),
                                                        nte.getRowCount());

        ctrlr.addTirageListener(row);
        innerModel.add(row);
        add(row);
    }

    @Override
    public void EndDraw(DrawEvent nte) {}

    @Override
    public void DrawBallSelected(DrawBallEvent tbe) {}

    @Override
    public void integrationStart(IntegrationEvent ie) {
        resetPanel();
    }

    @Override
    public void integrationEnd(IntegrationEvent ie) {}

    @Override
    public void integrationAddGrpRow(GrouppEvent gce) {}

    @Override
    public void integrationAddDateRow(DateEvent dce) {}

    @Override
    public void StatNbDraw(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatNbDrawE(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatAvNbDraw(SynthesesAvTirageEvent sate) {}
}

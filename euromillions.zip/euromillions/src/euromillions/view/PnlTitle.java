/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author © Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class PnlTitle extends JPanel {
    private final JLabel  lbltitle;

    private final int position;

    public PnlTitle(int _position, String _title, Color _color, int _fontsize) {
        position    = _position;
        lbltitle    = new JLabel(_title);
        lbltitle.setForeground(_color);
        lbltitle.setFont(new Font("Courrie New", Font.BOLD, _fontsize));
    }

    public void mkView() {
        setLayout(new FlowLayout(position));
        add(lbltitle);
    }
}

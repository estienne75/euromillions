/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view;

import euromillions.view.grouppcycles.PnlGrpList;
import euromillions.view.datescycles.PnlDateList;
import euromillions.controller.Controller;
import euromillions.controller.ControllerView;
import euromillions.event.MHMIHideEvent;
import euromillions.event.MHMIShowEvent;
import euromillions.listener.MHMIListener;
import java.awt.GridBagConstraints;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JFrame;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class MainHMI    extends     JFrame
                        implements  WindowListener,
                                    MHMIListener {

    private final   Controller      ctrlr;
    private final   ControllerView  ctrlvw;


    private final   GridBagConstraints  grdBgCstrts;

    private PnlGrpList        pnlGrpCycleList;
    private PnlDateList       pnlDateCycleList;
    private PnlGridAndTabs    pnlNumberCycleGrid;
//    private final DlgIntegre        dlgIntegre;

    public MainHMI(Controller _ctrlr, ControllerView _ctrlvw) {
        ctrlr   = _ctrlr;
        ctrlvw  = _ctrlvw;

        grdBgCstrts =   new GridBagConstraints();
    }

    public void makeIHM() {
        if(pnlGrpCycleList != null)
            return;

        pnlGrpCycleList = new PnlGrpList(ctrlr);
        pnlGrpCycleList.mkView();
        grdBgCstrts.gridx       = 0;
        grdBgCstrts.gridy       = 0;
        grdBgCstrts.gridwidth   = 1;
        grdBgCstrts.gridheight  = 1;
        grdBgCstrts.weightx     = 02;
        grdBgCstrts.weighty     = 1;
        //grdBgCstrt.anchor       = GridBagConstraints.FIRST_LINE_START;
        grdBgCstrts.fill         = GridBagConstraints.BOTH;
        add(pnlGrpCycleList, grdBgCstrts);

        pnlDateCycleList = new PnlDateList(ctrlr);
        pnlDateCycleList.mkView();
        grdBgCstrts.gridx       = 1;
        grdBgCstrts.gridy       = 0;
        grdBgCstrts.gridwidth   = 1;
        grdBgCstrts.gridheight  = 1;
        grdBgCstrts.weightx     = 30;
        grdBgCstrts.weighty     = 1;
        //grdBgCstrt.anchor       = GridBagConstraints.FIRST_LINE_END;
        grdBgCstrts.fill        = GridBagConstraints.BOTH;
        add(pnlDateCycleList, grdBgCstrts);

        pnlNumberCycleGrid = new PnlGridAndTabs(ctrlr);
        pnlNumberCycleGrid.mkView();
        grdBgCstrts.gridx       = 2;
        grdBgCstrts.gridy       = 0;
        grdBgCstrts.gridwidth   = 1;
        grdBgCstrts.gridheight  = 1;
        grdBgCstrts.weightx     = 68;
        grdBgCstrts.weighty     = 1;
        //grdBgCstrt.anchor       = GridBagConstraints.FIRST_LINE_END;
        grdBgCstrts.fill        = GridBagConstraints.BOTH;
        add(pnlNumberCycleGrid, grdBgCstrts);
    }

    @Override
    public void windowOpened(WindowEvent e) {
        ctrlvw.showMHMI(this);
    }

    @Override
    public void windowClosing(WindowEvent e) {
        ctrlvw.hideMHMI(this);
    }

    @Override
    public void windowClosed(WindowEvent e) {}

    @Override
    public void windowIconified(WindowEvent e) {}

    @Override
    public void windowDeiconified(WindowEvent e) {}

    @Override
    public void windowActivated(WindowEvent e) {}

    @Override
    public void windowDeactivated(WindowEvent e) {}


    @Override
    public void showMHMI(MHMIShowEvent mhmie) {
        this.setVisible(true);
        this.toFront();
    }

    @Override
    public void hideMHMI(MHMIHideEvent mhmie) {
        this.setVisible(false);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.datescycles;

import euromillions.controller.Controller;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author Stéphane
 */
public class PnlDateList extends JPanel{

    private final Controller ctrlr;

    private final PnlDateHeader pnlDateCycleHeader;
    private final JScrollPane   scrlDateCycleDetail;
    private final PnlDateDetail pnlDateCycleDetail;

    public PnlDateList(Controller _ctrlr) {
        ctrlr = _ctrlr;

        pnlDateCycleHeader      =   new PnlDateHeader(ctrlr);
        pnlDateCycleDetail      =   new PnlDateDetail(ctrlr);
        scrlDateCycleDetail     =   new JScrollPane(pnlDateCycleDetail);
        scrlDateCycleDetail.getVerticalScrollBar().setUnitIncrement(16);

    }

    public void mkView() {
        setLayout(new BorderLayout());
        add(pnlDateCycleHeader,     BorderLayout.NORTH);
        add(scrlDateCycleDetail,    BorderLayout.CENTER);
    }


}

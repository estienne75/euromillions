/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.datescycles;

import euromillions.controller.Controller;
import euromillions.event.DateEvent;
import euromillions.event.DateSecondaryEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import euromillions.listener.IntegrationListener;
import euromillions.listener.NewDataListener;
import java.util.ArrayList;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import euromillions.listener.DateSecondaryListener;
import java.awt.FlowLayout;

/**
 *
 * @author Stéphane
 */
public class PnlDateDetail  extends     JPanel
                            implements  IntegrationListener,
                                        NewDataListener,
                                        DateSecondaryListener{
    private final   Controller ctrlr;

    private final   MigLayout mglyt;
    //private final   FlowLayout flowlyt;

    private final ArrayList<PnlDatesDetailRows> alPnlDCDR;

    private boolean secondarycycleselected;
    private boolean Ecycletypelist;

    public PnlDateDetail(Controller _ctrlr) {
        ctrlr = _ctrlr;
        ctrlr.addIntegrationListener(this);
        ctrlr.addNewDataListener(this);
        ctrlr.addDateSecondaryCycle(this);

        mglyt = new MigLayout("wrap 1", "[100] [100] [100]");
        //flowlyt = new FlowLayout(FlowLayout.LEFT);

        alPnlDCDR = new ArrayList<PnlDatesDetailRows>(1000);

        this.setLayout(mglyt);
        //this.setLayout(flowlyt);
    }

    private void resetPanel() {
        alPnlDCDR.clear();
        this.removeAll();
        getParent().getParent().getParent().getParent().revalidate();
        repaint();
    }

    @Override
    public void integrationStart(IntegrationEvent ie) {
        resetPanel();
    }

    @Override
    public void integrationEnd(IntegrationEvent ie) {}

    @Override
    public void integrationAddGrpRow(GrouppEvent gce) {}

    @Override
    public void integrationAddDateRow(DateEvent dce) {

        PnlDatesDetailRows pnlDCDR = new PnlDatesDetailRows(ctrlr,
                                                            dce.getBeginDate(),
                                                            dce.getEnDate(),
                                                            dce.getCycleType(),
                                                            dce.getNbTirage());

        alPnlDCDR.add(pnlDCDR);

        // Ajoute par défaut tous les paneaux de type 'P'rimaire et 'E'n cours.
        // ---------------------------------------------------------------------
        if(dce.getCycleType().equalsIgnoreCase("P") ||
           dce.getCycleType().equalsIgnoreCase("E")   ) {

            // Savoir si la liste ne concerne que les paneaux de type 'E'.
            // -----------------------------------------------------------
            if(dce.getCycleType().equalsIgnoreCase("E"))
                Ecycletypelist = true;
            else
                Ecycletypelist = false;

            add(pnlDCDR);
        }
        // Sinon affiche aussi les panneaux de tye 'S'econdaire.
        // -----------------------------------------------------
        else if(dce.getCycleType().equalsIgnoreCase("S") &&
                secondarycycleselected)
            add(pnlDCDR);
    }

    @Override
    public void newCycleDate() {
        resetPanel();
    }

    @Override
    public void newNumber() {}

    @Override
    public void newLinearGap() {}

    @Override
    public void newTirage() {}

    @Override
    public void headerSecondaryStateChanged(DateSecondaryEvent dsce) {
        secondarycycleselected = dsce.getSelectedState();

        if(!Ecycletypelist) {
            this.removeAll();

            for(PnlDatesDetailRows pnlDCDR: alPnlDCDR) {

                // Ajoute que les panneaux de type est 'P'rimaire
                // si la case à cocher dans le paneau d'entête
                // n'est pas cochée.
                // --------------------------------------------
                if(!secondarycycleselected) {
                    if(pnlDCDR.getCycleType().equalsIgnoreCase("P")) {
                        add(pnlDCDR);
                    }
                }
                // Sinon affiche tout type de paneaux.
                // -----------------------------------
                else
                    add(pnlDCDR);

                getParent().getParent().getParent().getParent().revalidate();
                repaint();
            }
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.datescycles;

import euromillions.controller.Controller;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlDateHeader extends JPanel {
    Controller ctrlr;

    MigLayout migLyt;

    private final JLabel    lblBeginDateCycle;
    private final JLabel    lblEndDateCycle;
    private final JLabel    lblCycleType;
    private final JLabel    lblNbTirage;
    private final JCheckBox chkSecondaire;

    public PnlDateHeader(Controller _ctrlr) {
        ctrlr = _ctrlr;
        migLyt = new MigLayout("wrap 4", "20 [50] 20 [50] 20 [50]");
        setLayout(migLyt);

        lblBeginDateCycle  = new JLabel("Date Début");
        lblBeginDateCycle.setOpaque(true);
        lblBeginDateCycle.setBackground(Color.blue);
        lblBeginDateCycle.setForeground(Color.white);

        lblEndDateCycle = new JLabel("Date Fin");
        lblEndDateCycle.setOpaque(true);
        lblEndDateCycle.setBackground(Color.blue);
        lblEndDateCycle.setForeground(Color.white);

        lblCycleType = new JLabel("Type de Cycle");
        lblCycleType.setOpaque(true);
        lblCycleType.setBackground(Color.blue);
        lblCycleType.setForeground(Color.white);

        lblNbTirage = new JLabel("Nb tirage");
        lblNbTirage.setOpaque(true);
        lblNbTirage.setBackground(Color.blue);
        lblNbTirage.setForeground(Color.white);

        chkSecondaire = new JCheckBox("Cycle S", false);

        add(lblBeginDateCycle);
        add(lblEndDateCycle);
        add(lblCycleType);
        add(lblNbTirage);
        add(chkSecondaire);

        chkSecondaire.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ctrlr.cycleDateSecondaryCycle(  this, ((JCheckBox)
                                                e.getSource()).isSelected());
            }
        });
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.datescycles;

import euromillions.controller.Controller;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlDatesDetailRows extends    JPanel
                                    implements  MouseListener {
    private final Controller ctrlr;


    private final MigLayout mglyt;

    private final JLabel lblBeginDate;
    private final JLabel lblEndDate;
    private final JLabel lblCycleType;
    private final JLabel lblNbTirage;

    private final String cycletype;

    private boolean selected;

    public PnlDatesDetailRows(  Controller _ctrlr,
                                String _begindate,
                                String _enddate,
                                String _cycletype,
                                String _nbtirage) {
        ctrlr = _ctrlr;

        mglyt = new MigLayout("wrap 4", "20 [50] 20 [50] 20 [50]");
        this.setLayout(mglyt);

        cycletype =_cycletype;


        //setBorder(new LineBorder(Color.pink));
        setOpaque(true);
        lblBeginDate    = new JLabel(_begindate);
        lblEndDate      = new JLabel(_enddate);
        lblCycleType    = new JLabel(_cycletype);
        lblNbTirage     = new JLabel(_nbtirage);

        lblBeginDate.setOpaque(false);
        //lblNbCycle.setBackground(Color.darkGray);
        lblBeginDate.setForeground(Color.blue);

        lblEndDate.setOpaque(false);
        //lblNbTirage.setBackground(Color.darkGray);
        lblEndDate.setForeground(Color.blue);

        lblCycleType.setOpaque(false);
        //lblCycleType.setBackground(Color.darkGray);
        if(_cycletype.equalsIgnoreCase("P"))
            lblCycleType.setForeground(Color.white);
        else
            lblCycleType.setForeground(Color.blue);

        lblNbTirage.setOpaque(false);
        //lblNbTirage.setBackground(Color.darkGray);
        lblNbTirage.setForeground(Color.blue);


        add(lblBeginDate,   "align center");
        add(lblEndDate,     "align center");
        add(lblCycleType,   "align center");
        add(lblNbTirage,    "align center");

        addMouseListener(this);
    }

    public void switchSelectedState() {
        selected = !selected;

        if(selected) {
            lblBeginDate.setForeground(Color.magenta);
            lblEndDate.setForeground(Color.white);
            lblCycleType.setForeground(Color.white);
            lblNbTirage.setForeground(Color.white);
            this.setBackground(Color.blue);
            this.repaint();
        }
        else {
            lblBeginDate.setForeground(Color.blue);
            lblEndDate.setForeground(Color.blue);
            lblNbTirage.setForeground(Color.blue);

            if(cycletype.equalsIgnoreCase("P"))
                lblCycleType.setForeground(Color.white);
            else
                lblCycleType.setForeground(Color.blue);
            this.setBackground(Color.lightGray);
            this.repaint();
        }
    }

    protected String getCycleType() {
        return cycletype;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(!selected)
            ctrlr.cyleDateDetailRowSelected(this,
                                            lblBeginDate.getText(),
                                            lblEndDate.getText(),
                                            lblCycleType.getText(),
                                            lblNbTirage.getText());
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}

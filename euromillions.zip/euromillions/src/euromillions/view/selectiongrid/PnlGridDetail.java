/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.selectiongrid;

import euromillions.controller.Controller;
import euromillions.event.DateEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import euromillions.event.NumberGridEvent;
import euromillions.listener.CycleNumberGridListener;
import euromillions.listener.IntegrationListener;
import euromillions.listener.NewDataListener;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlGridDetail  extends     JPanel
                            implements  NewDataListener,
                                        CycleNumberGridListener,
                                        IntegrationListener {

    private final Controller  ctrlr;
    private final MigLayout   mglyt;

    private PnlGridSelection pnlNumberCycleSelection;

    public PnlGridDetail(Controller _ctrlr) {
        ctrlr = _ctrlr;

        ctrlr.addNewDataListener(this);
        ctrlr.addCycleNumberGridListener(this);
        ctrlr.addIntegrationListener(this);

        mglyt = new MigLayout("wrap 1", "[grow][grow][grow]");

        this.setLayout(mglyt);
    }

    private void resetPanel() {
        ctrlr.removeTirageListener(pnlNumberCycleSelection);
        this.removeAll();
        getParent().getParent().getParent().getParent().revalidate();
        repaint();
    }


    @Override
    public void newCycleDate() {
        resetPanel();
    }

    @Override
    public void newNumber() {
        resetPanel();
    }

    @Override
    public void newLinearGap() {}

    @Override
    public void cyleNumberNewGrid(NumberGridEvent nge) {

        pnlNumberCycleSelection = new PnlGridSelection(
                                                        ctrlr,
                                                        nge.getBeginDate(),
                                                        nge.getEnDate(),
                                                        nge.getOccurences(),
                                                        nge.getLinearGap1(),
                                                        nge.getLinearGap2());

        add(pnlNumberCycleSelection, BorderLayout.CENTER);
        ctrlr.addTirageListener(pnlNumberCycleSelection);
    }

    @Override
    public void cycleNumberGridRemoved() {}

    @Override
    public void newTirage() {}

    @Override
    public void integrationStart(IntegrationEvent ie) {
        resetPanel();
    }

    @Override
    public void integrationEnd(IntegrationEvent ie) {}

    @Override
    public void integrationAddGrpRow(GrouppEvent gce) {}

    @Override
    public void integrationAddDateRow(DateEvent dce) {}
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.selectiongrid;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlGridHeader2 extends JPanel {
    MigLayout mglyt;

    JLabel lblNumber[];
    JLabel lblOcc[];
    JLabel lblLinGap[];

    public PnlGridHeader2() {
        mglyt = new MigLayout("wrap 15", "30 [30] 30 [30] 30 [30]");
        setLayout(mglyt);

        lblNumber   = new JLabel[5];
        lblOcc      = new JLabel[5];
        lblLinGap   = new JLabel[5];

        for(int i=0; i<5; i++) {
            lblNumber[i]    = new JLabel("Numéro");
            lblOcc[i]       = new JLabel("Occurence");
            lblLinGap[i]    = new JLabel("Ecart Linéaire");
        }

        for(int i=0; i<5; i++) {
            lblNumber[i].setOpaque(true);
            lblOcc[i].setOpaque(true);
            lblLinGap[i].setOpaque(true);

            lblNumber[i].setBackground(Color.green);
            lblOcc[i].setBackground(Color.green);
            lblLinGap[i].setBackground(Color.green);

            lblNumber[i].setForeground(Color.black);
            lblOcc[i].setForeground(Color.black);
            lblLinGap[i].setForeground(Color.black);

            if(i==0)
                add(lblNumber[i], "gapleft 75");
            else
                add(lblNumber[i]);
            add(lblOcc[i]);
            add(lblLinGap[i]);
        }
    }
}

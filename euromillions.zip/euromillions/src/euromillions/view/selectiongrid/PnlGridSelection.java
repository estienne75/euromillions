/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.selectiongrid;

import euromillions.controller.Controller;
import euromillions.event.SynthesesAvTirageEvent;
import euromillions.event.SynthesesNbTirageEvent;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import net.miginfocom.swing.MigLayout;
import euromillions.listener.DrawListener;

/**
 *
 * @author Stéphane
 */
public class PnlGridSelection   extends     JPanel
                                implements  DrawListener {
    private final Controller ctrlr;

    private final MigLayout mglyt;

    private final String startcycledate;
    private final String endcycledate;

    private final JButton   btnNumber[];
    private final JLabel    lblOcc[];
    private final JLabel    lblLinGap[];

    private final Color darkgreen       = new Color(0, 100, 40);

    private final Font font;

    private final String    startdate;
    private final String    enddate;
    private final int[]     occurence;
    private final int[]     lingap1;
    private final int[]     lingap2;


    private final LineBorder lnbrd;

    private final Color[]   prvcolor    = new Color[50];
    private final boolean[] selected    = new boolean[50];

    public PnlGridSelection(Controller  _ctrlr,
                            String      _startdate,
                            String      _enddate,
                            int[]       _occurences,
                            int[]       _lineargap1,
                            int[]       _lineargap2) {
        ctrlr       = _ctrlr;
        startdate   = _startdate;
        enddate     = _enddate;
        occurence   = _occurences;
        lingap1     = _lineargap1;
        lingap2     = _lineargap2;

        mglyt = new MigLayout("wrap 15", "10 [80] 10 [80] 10 [80]");
        setLayout(mglyt);

        lnbrd = new LineBorder(Color.yellow);

        font = new Font("Courrie New", Font.BOLD, 20);
        setBorder(lnbrd);

        btnNumber   = new JButton[50];
        lblOcc      = new JLabel[50];
        lblLinGap   = new JLabel[50];

        startcycledate  = _startdate;
        endcycledate    = _enddate;


        for(int j=0; j<10; j++) {
            for(int k=0; k<50; k+=10) {
                int i = j+k;

                btnNumber[i]    = new JButton((i+1)<10? "0" + (i+1): "" + (i+1));
                btnNumber[i].setFont(font);
                btnNumber[i].setForeground(darkgreen);
                lblOcc[i]       = new JLabel( _occurences[i]<10 ? "0"+_occurences[i]: ""+_occurences[i]);
/*
                lblLinGap[i]    = new JLabel(    (_lineargap1[i]<10 && _lineargap1[i]>=0?
                                                        "0" + _lineargap1[i]:
                                                        ""  + _lineargap1[i])
                                                + "/"
                                                +   (_lineargap2[i]<10 && _lineargap2[i]>=0?
                                                        "0" + _lineargap2[i]:
                                                        ""  + _lineargap2[i]) );
*/
                lblLinGap[i]    = new JLabel( (     _lineargap2[i]<10
                                                &&  _lineargap2[i]>=0?
                                                        "0" + _lineargap2[i]:
                                                        ""  + _lineargap2[i]) );

                prvcolor[i] = Color.black;
/*
                if(_lineargap1[i]<0) { // sortie du premier tirage du cycle.
                    btnNumber[i].setForeground(Color.magenta);
                    btnNumber[i].setBackground(Color.blue);
                    prvcolor[i] = Color.magenta;
                }
                else */
                if(_lineargap2[i]<0) { // Sortie du dernier tirage du cycle.
                    btnNumber[i].setForeground(Color.white);
                    btnNumber[i].setBackground(darkgreen);
                    prvcolor[i] = Color.white;
                }

                if(_occurences[i]==0) {
                    btnNumber[i].setForeground(Color.red);
                    lblOcc[i].setForeground(Color.red);
                    lblLinGap[i].setForeground(Color.red);
                    prvcolor[i] = Color.red;
                }

                add(btnNumber[i],   "align center");

                btnNumber[i].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        ctrlr.selectBall(this,
                                        ((JButton) ae.getSource()).getText());
                    }
                });

                add(lblOcc[i],      "align center");
                add(lblLinGap[i],   "align center");
            }
        }
    }

    private void resetPanel() {
        removeAll();
        getParent().getParent().getParent().revalidate();
        repaint();
        ctrlr.numberGridReseted();
    }

    private void switchSelectdBall(String _ball, boolean _selected) {
        int iball = Integer.parseInt(_ball);

        selected[iball-1] = _selected;

        if(selected[iball-1])
            btnNumber[iball-1].setForeground(euromillions.EuroMillions.SELECTED_COLOR);
        else
            btnNumber[iball-1].setForeground(prvcolor[iball-1]);
    }

    @Override
    public void NewDrawRow(DrawEvent nte) {}

    @Override
    public void EndDraw(DrawEvent nte) {}

    @Override
    public void DrawBallSelected(DrawBallEvent tbe) {
        switchSelectdBall(tbe.getBallNumber(), tbe.getBallStatus());
    }

    @Override
    public void StatNbDraw(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatNbDrawE(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatAvNbDraw(SynthesesAvTirageEvent sate) {
    }
 }
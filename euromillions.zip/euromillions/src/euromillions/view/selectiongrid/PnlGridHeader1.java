/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.selectiongrid;

import euromillions.controller.Controller;
import euromillions.event.DateEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import euromillions.event.NumberGridEvent;
import euromillions.listener.CycleNumberGridListener;
import euromillions.listener.IntegrationListener;
import euromillions.listener.NewDataListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

/**
 *
 * @author Stéphane
 */
public class PnlGridHeader1   extends     JPanel
                                    implements  NewDataListener,
                                                CycleNumberGridListener,
                                                IntegrationListener{
    private final Controller ctrlr;

//    private final MigLayout mglyt;
//    private final BorderLayout brdLyt;

    private final JLabel lblBigTitle;
    private final JCheckBox conserveselectedballs;
    private final JButton    reset;

    private final Font font;
    private final LineBorder lnbrd;

    public PnlGridHeader1(Controller _ctrlr) {
        ctrlr =_ctrlr;
        ctrlr.addCycleNumberGridListener(this);
        ctrlr.addNewDataListener(this);
        ctrlr.addIntegrationListener(this);
        //mglyt = new MigLayout("wrap 1", "0 [700] 0 [700] 0 [700]");
        //brdLyt = new BorderLayout();
        //setLayout(brdLyt);
        //setLayout(mglyt);

        lnbrd = new LineBorder(Color.yellow);
        //setBorder(lnbrd);

        font = new Font("Courrie New", Font.BOLD, 32);

        lblBigTitle = new JLabel("Grille de sélection de numéros du cycle ?");
        lblBigTitle.setFont(font);
        lblBigTitle.setForeground(Color.yellow);
        lblBigTitle.setBorder(lnbrd);

        conserveselectedballs = new JCheckBox("Conserve", true);

        conserveselectedballs.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ctrlr.conserve( ((JCheckBox) e.getSource()).isSelected());
            }
        });

        reset = new JButton("Reset");

        reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ctrlr.reset(this);
            }

        });

        add(reset);
        add(lblBigTitle);
        add(conserveselectedballs);
    }

    private void resetTitle() {
        lblBigTitle.setText("Grille de sélection de numéros du cycle ?");
    }


    @Override
    public void newCycleDate() {
        resetTitle();
    }

    @Override
    public void newNumber() {}

    @Override
    public void newLinearGap() {}

    @Override
    public void newTirage() {}

    @Override
    public void cyleNumberNewGrid(NumberGridEvent nge) {
        String lbltc=null;  // libellé type de cycle

        switch(nge.getCycleType()) {
            case "E":
                lbltc = "en cours ";
                break;

            case "P":
                lbltc = "primaire ";
                break;

            case "S":
                lbltc = "secondaire ";
                break;

            default:
                lbltc = "indéterminé ";
        }


        lblBigTitle.setText("Grille de sélection de numéros du cycle "
                            + lbltc
                            + nge.getBeginDate() + "/" + nge.getEnDate());
    }

    @Override
    public void cycleNumberGridRemoved() {}

    @Override
    public void integrationStart(IntegrationEvent ie) {
        lblBigTitle.setText("Grille de sélection de numéros du cycle ?");
    }

    @Override
    public void integrationEnd(IntegrationEvent ie) {

    }

    @Override
    public void integrationAddGrpRow(GrouppEvent gce) {

    }

    @Override
    public void integrationAddDateRow(DateEvent dce) {

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view;

import euromillions.view.synthesescycles.PnlSynthesesList;
import euromillions.controller.Controller;
import java.awt.BorderLayout;
import javax.swing.JPanel;

/**
 *
 * @author Stéphane
 */
public class PnlTabSynthesis extends JPanel {

    private final Controller ctrlr;

    private final PnlSynthesesList pnlSynthesesList;

    public PnlTabSynthesis(Controller _ctrlr) {

        ctrlr = _ctrlr;

        pnlSynthesesList   = new PnlSynthesesList(ctrlr);
        pnlSynthesesList.mkView();

        setLayout(new BorderLayout());

        add(pnlSynthesesList, BorderLayout.CENTER);

    }
}

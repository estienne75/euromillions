/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.synthesescycles;

import euromillions.controller.Controller;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlSynthesesDetailAvNbTirageRow  extends JPanel {
    private Controller ctrlr;

    private final MigLayout mglyt;

    private final Font  font12,
                        font16;

    private final   JLabel[] lblOccurs;
    private final   JLabel[] lblGaps;

    private final   int[]   avoccurs;
    private final   int[]   avgaps;

    public PnlSynthesesDetailAvNbTirageRow( Controller  _ctrlr,
                                            int         _nbcycle,
                                            int         _nbtirage,
                                            int[]       _avoccurs,
                                            int[]       _avgaps) {
        ctrlr = _ctrlr;

        mglyt = new MigLayout("wrap 100", "20[7] 20[7] 20[7]");
        this.setLayout(mglyt);

        setOpaque(true);

        font12 = new Font("Courrier New", Font.PLAIN, 12);
        font16 = new Font("Courrier New", Font.PLAIN, 16);

        avoccurs      = _avoccurs;
        avgaps        = _avgaps;

        lblOccurs       = new JLabel[100];
        lblGaps         = new JLabel[100];

        int lnze = 0;


        /* Liste des occurences */
        /* -------------------- */
        add(new JLabel("Occurences"));

        for(int i=avoccurs.length-1; i>=0; i--) // Loocking for the last non zero element.
            if(avoccurs[i] != 0) {
                lnze = i;
                break;
            }

        for(int i=0; i<avoccurs.length; i++) {
            if(avoccurs[i]> 0) {
                lblOccurs[i] = new JLabel((     i<9? "0" + (i+1): "" + (i+1))
                                            +    ","
                                            + (avoccurs[i]<10?  "0"  + (avoccurs[i]):
                                                                ""   + (avoccurs[i])) );
                // Is the last (lnze) element.
                if(i==lnze)
                    add(lblOccurs[i], "wrap");
                else
                    add(lblOccurs[i]);
            }
        }

        /* Liste des écarts. */
        /* ----------------- */
        add(new JLabel("Ecarts"));

        for(int i=avgaps.length-1; i>=0; i--) // Loocking for the last non zero element.
            if(avgaps[i] != 0) {
                lnze = i;
                break;
            }

        for(int i=0; i<avgaps.length; i++) {
            if(avgaps[i]> 0) {
                lblGaps[i] = new JLabel(    (i<9? "0" + (i+1): "" + (i+1))
                                        +   ","
                                        +   (avgaps[i]<9?   "0"  + (avgaps[i]+1):
                                                            ""   + (avgaps[i]+1)) );

                // Is the last (lnze) element.
                if(i==lnze)
                    add(lblGaps[i], "wrap");
                else
                    add(lblGaps[i]);
            }
        }

        //ctrlr.addTirageListener(this);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.synthesescycles;

import euromillions.controller.Controller;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

/**
 *
 * @author Stéphane
 */
public class PnlSynthesesList extends JPanel{

    private final Controller ctrlr;

    private final PnlSynthesesHeader    pnlSynthsesHeader;
    //private final JScrollPane           scrlSynthesesDetail;
    private final PnlSynthesesDetail    pnlSynthsesListDetail;

    public PnlSynthesesList(Controller _ctrlr) {
        ctrlr   =   _ctrlr;

        pnlSynthsesHeader      =   new PnlSynthesesHeader(ctrlr);
        pnlSynthsesListDetail  =   new PnlSynthesesDetail(ctrlr);
        //scrlAnalysesDetail     =   new JScrollPane(pnlAnalysesListDetail);
        //scrlAnalysesDetail.getVerticalScrollBar().setUnitIncrement(16);
    }

    public void mkView() {
        setLayout(new BorderLayout());
        setBorder(new LineBorder(Color.blue));

        add(pnlSynthsesHeader,  BorderLayout.NORTH);
        //add(scrlSynthesesDetail, BorderLayout.CENTER);
        add(pnlSynthsesListDetail, BorderLayout.CENTER);
    }
}

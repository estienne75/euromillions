/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.synthesescycles;

import euromillions.controller.Controller;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane Delpech - stephane.delpech@sdelpech.fr
 */
public class PnlSynthesesDetailNbDrawRow  extends JPanel {
    private Controller ctrlr;

    private final MigLayout mglyt;

    private final Font  font12,
                        font16;

    private final   JLabel[] lblOccurs;
    private final   JLabel[] lblGaps;

    private final   int[]   occurs;
    private final   int[]   gaps;

    public PnlSynthesesDetailNbDrawRow(Controller  _ctrlr,
                                        int         _nbtirage,
                                        int[]       _glboccurs,
                                        int[]       _occurs,
                                        int[]       _gaps,
                                        String      _startDate,
                                        String      _endDate) {
        ctrlr = _ctrlr;

        mglyt = new MigLayout("wrap 100", "20[7] 20[7] 20[7]");
        this.setLayout(mglyt);

        //setOpaque(true);

        font12 = new Font("Courrier New", Font.PLAIN, 12);
        font16 = new Font("Courrier New", Font.PLAIN, 16);


        //if(_glboccurs == null)
            occurs      = _occurs;
/*
        else {
            occurs      = _glboccurs;
            occurs = new int[50];

            for(int i =0; i<occurs.length; i++) {
                occurs[_glboccurs[i]] ++;
            }
        }
*/
        gaps        = _gaps;

        lblOccurs       = new JLabel[100];
        lblGaps         = new JLabel[100];

        int svi = 0;

        /* Liste des occurences */
        /* -------------------- */
        add(new JLabel("Occurences"));

        for(int i=occurs.length-1; i>=0; i--)
            if(occurs[i] != 0) {
                svi = i;
                break;
            }

        for(int i=0; i<occurs.length; i++) {
            if(occurs[i]> 0) {
                lblOccurs[i] = new JLabel(
                                (i<9? "0" + (i+1): "" + (i+1))
                            + "," +
                                (occurs[i]<10? "0"  + occurs[i]:
                                               ""   + occurs[i])
                     );

                if(i!=svi)
                    add(lblOccurs[i]);
                else
                    add(lblOccurs[i], "wrap");
            }
        }

        /* Liste des écarts. */
        /* ----------------- */
        add(new JLabel("Ecarts"));

        for(int i=gaps.length-1; i>=0; i--)
            if(gaps[i] != 0) {
                svi = i;
                break;
            }

        for(int i=0; i<gaps.length; i++) {
            if(gaps[i]> 0) {
                lblGaps[i] = new JLabel((i<9? "0" + (i+1): "" + (i+1))
                                        + "," +
                                        (gaps[i]<10? "0"  + gaps[i]:
                                                     ""   + gaps[i])
                     );

                if(i!=svi)
                    add(lblGaps[i]);
                else
                    add(lblGaps[i], "wrap");
            }
        }

        //ctrlr.addTirageListener(this);
    }
}

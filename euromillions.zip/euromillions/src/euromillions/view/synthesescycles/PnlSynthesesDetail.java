/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.synthesescycles;

import euromillions.controller.Controller;
import euromillions.event.DateEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import euromillions.event.SynthesisEvent;
import euromillions.listener.DateDetailRowListener;
import euromillions.listener.GrpDetailRowListener;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import euromillions.listener.IntegrationListener;
import euromillions.listener.NewDataListener;
import euromillions.listener.SynthesisListener;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JScrollPane;

/**
 *
 * @author Stéphane
 */
public class PnlSynthesesDetail extends      JPanel
                               implements   NewDataListener,
                                            SynthesisListener,
                                            GrpDetailRowListener,
                                            DateDetailRowListener,
                                            IntegrationListener {
    private final   Controller              ctrlr;

    private final   MigLayout       mglyt;
    private   BorderLayout    brdrlyt;

    private         PnlSynthesesDetailNbDrawRow pnlSynthesesDetailNbTirageRow;
    private         JPanel                        pnlsyntheses, pnlnorth, pnlcenter, pnlsouth;
    private         JScrollPane                   scrlpnprospect;

    public PnlSynthesesDetail(Controller _ctrlr) {
        ctrlr = _ctrlr;

        ctrlr.addNewDataListener(this);
        ctrlr.addCycleDetailRowListener(this);
        ctrlr.addDateDetailRowListener(this);
        ctrlr.addIntegrationListener(this);
        ctrlr.addSynthesisListener(this);

        mglyt = new MigLayout("wrap 1", "3 [7] 3 [7] 3 [7]");
        this.setLayout(mglyt);
    }

    private void resetPanel() {
        removeAll();
        getParent().getParent().getParent().getParent().revalidate();
        repaint();
        pnlsyntheses = pnlnorth = pnlcenter = pnlsouth = null;
        scrlpnprospect = null;
    }

    @Override
    public void newCycleDate() {
        resetPanel();
    }

    @Override
    public void newNumber() {}

    @Override
    public void newLinearGap() {}

    @Override
    public void newTirage() {}

    @Override
    public void grpDetailRowSelected(GrouppEvent gce) {
        resetPanel();
    }

    @Override
    public void dateDetailRowSelected(DateEvent dce) {
        resetPanel();
    }

    @Override
    public void integrationStart(IntegrationEvent ie) {
        resetPanel();
    }

    @Override
    public void integrationEnd(IntegrationEvent ie) {}

    @Override
    public void integrationAddGrpRow(GrouppEvent gce) {}

    @Override
    public void integrationAddDateRow(DateEvent dce) {}

    @Override
    public void SyntheseCycles(SynthesisEvent se) {
        switch(se.getCycleType()) {
            case "E":   // In progress cycle synthesis.
                pnlsyntheses    = new JPanel(new BorderLayout());
                pnlnorth        = new JPanel(new MigLayout("wrap 1"));

                pnlnorth.add(new PnlSynthesesDetailRowHeader(ctrlr, "Occurences et ecarts cumulés du cycle en cours", Color.magenta));
                pnlnorth.add( new PnlSynthesesDetailNbDrawRow(    ctrlr,
                                                                    se.getNbTirage(),
                                                                    se.getGloablOccurences(),
                                                                    se.getOccurences(),
                                                                    se.getLinearGap(),
                                                                    se.getDateDeb(),
                                                                    se.getDateFin()));

                pnlsyntheses.add(pnlnorth, BorderLayout.NORTH);
                this.add(pnlsyntheses);
                break;

            case "P":   // Primary cycle synthesis.
            case "S":   // Secondary cycle synthesis.
                if(pnlsyntheses==null) {
                    pnlsyntheses    =   new JPanel(new BorderLayout());

                    pnlnorth        = new JPanel(new MigLayout("wrap 1"));
                    pnlnorth.add(new PnlSynthesesDetailRowHeader(   ctrlr,  "Occurences et ecarts cumulés sur le cycle du "
                                                                            + se.getDateDeb()
                                                                            + " au "
                                                                            + se.getDateFin()
                                                                            + " de " + se.getNbTirage() + " tirages",
                                                                    Color.magenta));

                    pnlnorth.add(new PnlSynthesesDetailNbDrawRow( ctrlr,
                                                                    se.getNbTirage(),
                                                                    null,
                                                                    se.getOccurences(),
                                                                    se.getLinearGap(),
                                                                    se.getDateDeb(),
                                                                    se.getDateFin()));
                    pnlsyntheses.add(pnlnorth, BorderLayout.NORTH);
                    this.add(pnlsyntheses);

                }
                else {
                    if(pnlcenter == null) {
                        pnlcenter       =   new JPanel(new MigLayout("wrap 1"));
                        scrlpnprospect  =   new JScrollPane(pnlcenter);
                        scrlpnprospect.getVerticalScrollBar().setUnitIncrement(16);
                        pnlsyntheses.add(scrlpnprospect, BorderLayout.CENTER);
                    }

                    pnlcenter.add(new PnlSynthesesDetailRowHeader(ctrlr,    "Occurences et ecarts cumulés sur le cycle du " + se.getRefDateDeb()
                                                                            + " au " + se.getRefDateFin()
                                                                            + " de " + se.getNbTirage() + " tirages",
                                                                  new Color(10, 170, 10)));

                    pnlcenter.add(new PnlSynthesesDetailNbDrawRow(ctrlr,
                                                                    se.getNbTirage(),
                                                                    null,
                                                                    se.getOccurences(),
                                                                    se.getLinearGap(),
                                                                    se.getRefDateDeb(),
                                                                    se.getRefDateFin()));

                    //           new Color(10, 170, 10);
                }

                break;

            case "A":   // Average cycle synthesis.
                if(pnlsouth == null) {
                        pnlsouth        =   new JPanel(new MigLayout("wrap 1"));
                        pnlsyntheses.add(pnlsouth, BorderLayout.SOUTH);
                }

                pnlsouth.add(new PnlSynthesesDetailRowHeader(ctrlr, "Moyenne des occurences et ecarts cumulés des cycles de " + se.getNbTirage() + " tirages", Color.blue));


                pnlsouth.add(pnlSynthesesDetailNbTirageRow = new PnlSynthesesDetailNbDrawRow( ctrlr,
                                                                                                se.getNbTirage(),
                                                                                                null,
                                                                                                se.getOccurences(),
                                                                                                se.getLinearGap(),
                                                                                                se.getRefDateDeb(),
                                                                                                se.getRefDateFin()));
                break;
        }
    }
}

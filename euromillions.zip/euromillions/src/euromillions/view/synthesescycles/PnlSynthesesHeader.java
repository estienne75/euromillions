/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.synthesescycles;

import euromillions.controller.Controller;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Stéphane
 */
public class PnlSynthesesHeader extends JPanel{

    private final Controller ctrlr;
    private final   JLabel Title;

    public PnlSynthesesHeader(Controller _ctrlr) {
        ctrlr = _ctrlr;

        setLayout(new FlowLayout());

        Title = new JLabel("Synthèses");
        Title.setFont(new Font("Courrie New", Font.BOLD, 40));
        Title.setForeground(Color.blue);

        add(Title);
    }
}

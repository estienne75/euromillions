/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view;

import euromillions.view.playgrid.PnlTabPlayedList;
import euromillions.view.selectiongrid.PnlGridDetail;
import euromillions.view.selectiongrid.PnlGridHeader2;
import euromillions.view.selectiongrid.PnlGridHeader1;
import euromillions.controller.Controller;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class PnlGridAndTabs extends JPanel {

    private final Controller ctrlr;

    private final PnlGridHeader1    pnlGridHeader1;
    private final PnlGridHeader2    pnlGridHeader2;
    private final PnlGridDetail     pnlGridDetail;
    private final JTabbedPane       tbbdp;

    private final PnlTabDraw        pnlTabDraw;
    private final PnlTabStats       pnlTabStatsCycle;
    private final PnlTabSynthesis   pnlTabSynthesis;
    private final PnlTabSchemas     pnlTabSchemas;
    private final PnlTabIntuition   pnlTabIntuition;

    private final JSplitPane        splitPlay;
    private final PnlTabPlay        pnlTabPlay;
    private final PnlTabPlayedList  pnlTabPlayedList;

    public PnlGridAndTabs(Controller _ctrlr) {
        ctrlr = _ctrlr;

        pnlGridHeader1  = new PnlGridHeader1(ctrlr);
        pnlGridHeader2  = new PnlGridHeader2();
        pnlGridDetail   = new PnlGridDetail(ctrlr);
        tbbdp           = new JTabbedPane();

        pnlTabDraw          = new PnlTabDraw(ctrlr);
        pnlTabStatsCycle    = new PnlTabStats(ctrlr);
        pnlTabSynthesis     = new PnlTabSynthesis(ctrlr);
        pnlTabSchemas       = new PnlTabSchemas(_ctrlr);
        pnlTabIntuition     = new PnlTabIntuition(_ctrlr);

        pnlTabPlay          = new PnlTabPlay(_ctrlr);
        pnlTabPlayedList    = new PnlTabPlayedList(_ctrlr);
        splitPlay           = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
    }

    protected void mkView() {
        GridBagLayout       grdBgLyt    = new GridBagLayout();
        GridBagConstraints  grdBgCstrts = new GridBagConstraints();
        grdBgCstrts.insets              = new Insets(3,3,3,3);
        setLayout(grdBgLyt);

        grdBgCstrts.insets      = new Insets(0,0,0,0);
        grdBgCstrts.ipadx       = 0;
        grdBgCstrts.ipady       = 0;

        grdBgCstrts.gridx       = 0;
        grdBgCstrts.gridy       = 0;
        grdBgCstrts.gridwidth   = 1;
        grdBgCstrts.gridheight  = 1;
        grdBgCstrts.weightx     = 1;
        grdBgCstrts.weighty     = 0;
        grdBgCstrts.fill        = GridBagConstraints.BOTH;
        add(pnlGridHeader1, grdBgCstrts);

        grdBgCstrts.gridx       = 0;
        grdBgCstrts.gridy       = 1;
        grdBgCstrts.gridwidth   = 1;
        grdBgCstrts.gridheight  = 1;
        grdBgCstrts.weightx     = 1;
        grdBgCstrts.weighty     = 0;
        grdBgCstrts.fill        = GridBagConstraints.BOTH;
        add(pnlGridHeader2, grdBgCstrts);

        grdBgCstrts.gridx       = 0;
        grdBgCstrts.gridy       = 2;
        grdBgCstrts.gridwidth   = 1;
        grdBgCstrts.gridheight  = 1;
        grdBgCstrts.weightx     = 0.5;
        grdBgCstrts.weighty     = 0.01;
        grdBgCstrts.fill        = GridBagConstraints.BOTH;
        add(pnlGridDetail, grdBgCstrts);

        grdBgCstrts.gridx       = 0;
        grdBgCstrts.gridy       = 3;
        grdBgCstrts.gridwidth   = 1;
        grdBgCstrts.gridheight  = 1;
        grdBgCstrts.weightx     = 1;
        grdBgCstrts.weighty     = 0.99;
        grdBgCstrts.fill        = GridBagConstraints.BOTH;
        add(tbbdp, grdBgCstrts);

        tbbdp.add("Tirages",        pnlTabDraw);
        tbbdp.add("Stats cycle",    pnlTabStatsCycle);
        tbbdp.add("Synthèse",       pnlTabSynthesis);
        tbbdp.add("Schémas",        pnlTabSchemas);
        tbbdp.add("Intuition",      pnlTabIntuition);
        tbbdp.add("Jouer",          splitPlay);

        pnlTabSchemas.mkView();

        pnlTabPlay.mkView();
        pnlTabPlayedList.mkView();
        splitPlay.setLeftComponent(pnlTabPlay);
        splitPlay.setRightComponent(pnlTabPlayedList);

        ctrlr.loadPlayedGrids(this);
    }
}

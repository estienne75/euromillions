/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view;

import euromillions.view.statscycle.PnlStatsList;
import euromillions.controller.Controller;
import java.awt.BorderLayout;
import javax.swing.JPanel;

/**
 *
 * @author Stéphane
 */
public class PnlTabStats extends JPanel {

    private final Controller ctrlr;

    private final PnlStatsList pnlStatsCycleList;

    public PnlTabStats(Controller _ctrlr) {

        ctrlr = _ctrlr;

        pnlStatsCycleList   = new PnlStatsList(ctrlr);
        pnlStatsCycleList.mkView();

        setLayout(new BorderLayout());

        add(pnlStatsCycleList, BorderLayout.CENTER);

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.grouppcycles;

import euromillions.controller.Controller;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlGrpDetailRows extends     JPanel
                                    implements  MouseListener {
    private final Controller ctrlr;


    private final MigLayout mglyt;

    private final JLabel lblNbCycle;
    private final JLabel lblNbTirage;
    private final JLabel lblCycleType;

    private boolean selected;

    public PnlGrpDetailRows(  Controller _ctrlr,
                                    String _nbcycle,
                                    String _nbtirage,
                                    String _cycletype) {
        ctrlr = _ctrlr;

        mglyt = new MigLayout("wrap 3", "[100] 10 [80] 3 [80]");
        this.setLayout(mglyt);

        setOpaque(true);
        lblNbCycle      = new JLabel(_nbcycle);
        lblNbTirage     = new JLabel(_nbtirage);
        lblCycleType    = new JLabel(_cycletype);
/*
        lblNbCycle.setOpaque(true);
        lblNbCycle.setBackground(Color.darkGray);
        lblNbCycle.setForeground(Color.white);

        lblNbTirage.setOpaque(true);
        lblNbTirage.setBackground(Color.darkGray);
        lblNbTirage.setForeground(Color.white);

        lblCycleType.setOpaque(true);
        lblCycleType.setBackground(Color.darkGray);
        lblCycleType.setForeground(Color.white);
*/
        add(lblNbCycle,     "align center");
        add(lblNbTirage,    "align center");
        add(lblCycleType,   "align center");

        addMouseListener(this);
    }

    public void switchSelectedState() {
        selected = !selected;

        if(selected) {
            lblNbCycle.setForeground(Color.white);
            lblNbTirage.setForeground(Color.white);
            lblCycleType.setForeground(Color.white);
            this.setBackground(Color.black);
            this.repaint();
        }
        else {
            lblNbCycle.setForeground(Color.black);
            lblNbTirage.setForeground(Color.black);
            lblCycleType.setForeground(Color.black);
            this.setBackground(Color.lightGray);
            this.repaint();
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(!selected)
            ctrlr.grpDetailRowSelected(this,
                                        lblNbCycle.getText(),
                                        lblNbTirage.getText(),
                                        lblCycleType.getText());
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}

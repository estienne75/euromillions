/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.grouppcycles;

import euromillions.controller.Controller;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author Stéphane
 */
public class PnlGrpList extends JPanel{

    private final Controller ctrlr;

    private final PnlGrpHeader  pnlCycleHeader;
    private final JScrollPane   scrlCycleDetail;
    private final PnlGrpDetail  pnlCycleDetail;

    public PnlGrpList(Controller _ctrlr) {
        ctrlr = _ctrlr;

        pnlCycleHeader      =   new PnlGrpHeader();
        pnlCycleDetail      =   new PnlGrpDetail(ctrlr);
        scrlCycleDetail     =   new JScrollPane(pnlCycleDetail);
        scrlCycleDetail.getVerticalScrollBar().setUnitIncrement(16);

    }

    public void mkView() {
        setLayout(new BorderLayout());
        add(pnlCycleHeader, BorderLayout.NORTH);
        add(scrlCycleDetail, BorderLayout.CENTER);
    }


}

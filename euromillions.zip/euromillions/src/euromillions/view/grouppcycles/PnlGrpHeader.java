/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.grouppcycles;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlGrpHeader extends JPanel {
    MigLayout migLyt;

    JLabel lblNbCycle;
    JLabel lblNbTirage;
    JLabel lblcycleType;

    public PnlGrpHeader() {
        migLyt = new MigLayout("wrap 3", "[100] [100] [100]");
        setLayout(migLyt);

        lblNbCycle  = new JLabel("Nombre de Cycle");
        lblNbCycle.setOpaque(true);
        lblNbCycle.setBackground(Color.black);
        lblNbCycle.setForeground(Color.white);

        lblNbTirage = new JLabel("Nombre de Tirage");
        lblNbTirage.setOpaque(true);
        lblNbTirage.setBackground(Color.black);
        lblNbTirage.setForeground(Color.white);

        lblcycleType = new JLabel("Type de cycle");
        lblcycleType.setOpaque(true);
        lblcycleType.setBackground(Color.black);
        lblcycleType.setForeground(Color.white);

        add(lblNbCycle);
        add(lblNbTirage);
        add(lblcycleType);
    }
}

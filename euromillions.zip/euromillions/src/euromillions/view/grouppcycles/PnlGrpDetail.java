/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.grouppcycles;

import euromillions.controller.Controller;
import euromillions.event.DateEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import euromillions.listener.IntegrationListener;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlGrpDetail   extends    JPanel
                            implements IntegrationListener {
    private final Controller ctrlr;

    MigLayout mglyt;

    public PnlGrpDetail(Controller _ctrlr) {
        ctrlr = _ctrlr;
        ctrlr.addIntegrationListener(this);

        mglyt = new MigLayout("wrap 1", "[300] [300] [300]");
        this.setLayout(mglyt);
    }

    private void resetPanel() {
        this.removeAll();
        getParent().getParent().getParent().revalidate();
        this.repaint();
    }

    @Override
    public void integrationStart(IntegrationEvent ie) {
        resetPanel();
    }

    @Override
    public void integrationEnd(IntegrationEvent ie) {
        getParent().getParent().revalidate();
    }


    @Override
    public void integrationAddGrpRow(GrouppEvent gce) {
        add(new PnlGrpDetailRows( ctrlr,
                                        gce.getNbCycle(),
                                        gce.getNbTirage(),
                                        gce.getCycleType()));
    }

    @Override
    public void integrationAddDateRow(DateEvent dce) {}
}

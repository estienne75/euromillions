/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view;

import euromillions.controller.Controller;
import euromillions.controller.ControllerView;
import euromillions.event.DateEvent;
import euromillions.event.GrouppEvent;
import euromillions.event.IntegrationEvent;
import euromillions.event.IntegreSystrayMessageEvent;
import euromillions.event.MHMIHideEvent;
import euromillions.event.MHMIShowEvent;
import euromillions.listener.IntegrationListener;
import euromillions.listener.IntegreSystrayListener;
import euromillions.listener.MHMIListener;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;
import javax.swing.*;


import net.miginfocom.swing.MigLayout;
/**
 *
 * @author sdelpech
 */
public class SysTray implements MHMIListener,
                                IntegrationListener,
                                IntegreSystrayListener{
    private final   ControllerView  ctrlrvw;
    private final   Controller      ctrlr;


    private         SystemTray      tray;
    private         boolean         systraysupported=false;
    private         PopupMenu       ppupmenu;
    private         TrayIcon        trayIcon;
    private         MenuItem        aboutItem;
    private         MenuItem        showItem;
    private         MenuItem        hideItem;
    private         MenuItem        integreItem;
    private         MenuItem        exitItem;

    private         boolean         hideitemstate;
    private         boolean         showitemstate;

    private   JWindow jwndwAbout;
    private   JPanel  jpnlwndwAbout=null;

    public SysTray(ControllerView _ctrlrvw, Controller _ctrlr) {
        ctrlrvw = _ctrlrvw;
        ctrlr   = _ctrlr;

        //Check the SystemTray is supported
        if(SystemTray.isSupported()) {
            ppupmenu = new PopupMenu();
            trayIcon = new TrayIcon(createImage("Images/etoile.png",
                                                "EuroMillions"));
        }
        else {
            System.out.println("SystemTray is not supported");
            return;
        }

        // Create popup menu & items
        aboutItem   = new MenuItem("A propos...");
        showItem    = new MenuItem("Montrer");
        hideItem    = new MenuItem("Cacher");
        integreItem = new MenuItem("Integrer");
        exitItem    = new MenuItem("Quiter");

        ppupmenu.add(aboutItem);
        aboutItem.setEnabled(true);

        ppupmenu.addSeparator();
        ppupmenu.add(showItem);
        ppupmenu.add(hideItem);
        showItem.setEnabled(true);
        hideItem.setEnabled(false);

        ppupmenu.addSeparator();
        ppupmenu.add(integreItem);
        integreItem.setEnabled(true);

        ppupmenu.addSeparator();
        ppupmenu.add(exitItem);
        exitItem.setEnabled(true);

        jwndwAbout = new JWindow();
        jwndwAbout.setBackground(Color.gray);

        jwndwAbout.setLayout(new MigLayout("nogrid", "[grow]", "[grow]"));
        jwndwAbout.setBackground(Color.gray);

        jpnlwndwAbout = new JPanel();
        jpnlwndwAbout.setOpaque(false);

        jpnlwndwAbout.setLayout(new MigLayout("nogrid", "[][][]", ""));

        URL imageURL;// = SysTray.class.getResource("/Images/Cupid_128.png");

        imageURL = SysTray.class.getClassLoader().getResource("Images/euromillions.png");

        JLabel jlblVersionImage = new JLabel( new ImageIcon(imageURL, "HeureuxMillions" ));
        JLabel jlblVersionTitle = new JLabel("HeureuxMillions.eu");
        jlblVersionTitle.setForeground(Color.blue);
        jlblVersionTitle.setFont(new Font("Tahoma", 0, 48));
        jpnlwndwAbout.add(jlblVersionImage, "center,wrap");
        jpnlwndwAbout.add(jlblVersionTitle, "center,wrap");

        JLabel jlblVersionDesignation = new JLabel("Application de gestion Euro Millions");
        jlblVersionDesignation.setForeground(Color.magenta);
        jlblVersionDesignation.setFont(new Font("Tahoma", 0, 16));
        jpnlwndwAbout.add(jlblVersionDesignation, "center,wrap");

        JLabel jlblVersionTxt = new JLabel("Version 1.0");
        jlblVersionTxt.setForeground(Color.blue);
        jlblVersionTxt.setFont(new Font("Tahoma", 0, 12));
        jpnlwndwAbout.add(jlblVersionTxt, "center,wrap");

        JLabel jlblVersionCopyright = new JLabel("Heureux-Millions © 2016 Stéphane Delpech - stephane.delpech@sdelpech.fr");
        jlblVersionCopyright.setForeground(Color.black);
        jlblVersionCopyright.setFont(new Font("Tahoma", 0, 12));
        jpnlwndwAbout.add(jlblVersionCopyright, "center,wrap");

        JLabel jlblVersionAuthor = new JLabel("Réalisé par Stéphane Delpech");
        jlblVersionAuthor.setForeground(Color.black);
        jlblVersionAuthor.setFont(new Font("Tahoma", 0, 8));
        jpnlwndwAbout.add(jlblVersionAuthor, "center,wrap");

        jwndwAbout.add(jpnlwndwAbout);
        jwndwAbout.pack();
        Dimension ssz = Toolkit.getDefaultToolkit().getScreenSize();
        jwndwAbout.setLocation(( (int) ssz
                                        .getWidth()-jwndwAbout.getWidth())/2,
                                   (int) (ssz
                                      .getHeight()-jwndwAbout.getHeight())/2);

        jwndwAbout.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                jwndwAbout.setVisible(false);
            }
        });

        // *---------------------*/
        // *- Menu items action -*/
        // *---------------------*/
        exitItem.addActionListener((ActionEvent e) -> {
            aboutItem.setEnabled(false);
            showItem.setEnabled(false);
            hideItem.setEnabled(false);
            integreItem.setEnabled(false);
            exitItem.setEnabled(false);

            //if(!jwndwAbout.isVisible())
            //    jwndwAbout.setVisible(true);

            //jwndwAbout.toFront();

            //JOptionPane.showMessageDialog(null, "Au revoir et à bientôt alors...", "A bientôt", JOptionPane.INFORMATION_MESSAGE);
            ctrlr.exit();
        });

        aboutItem.addActionListener((ActionEvent ae) -> {
            if(!jwndwAbout.isVisible()) {
                jwndwAbout.setVisible(true);
                jwndwAbout.toFront();
            }
            else
                jwndwAbout.toFront();
        });

        hideItem.addActionListener((ActionEvent e) -> {
            ctrlrvw.hideMHMI(this);
        });

        showItem.addActionListener((ActionEvent e) -> {
            ctrlrvw.showMHMI(this);
        });

        integreItem.addActionListener((ActionEvent e) -> {
            ctrlr.Integre(this);
        });

        systraysupported=true;

        ctrlr.addIntegrationListener(this);
    }

    // *-------------------------------*/
    // *- Mise en place du popup menu -*/
    // *-------------------------------*/
    public boolean show() {
        if(systraysupported && tray==null) {
            tray = SystemTray.getSystemTray();

            if(trayIcon!=null) {
                trayIcon.setPopupMenu(ppupmenu);

                try {
                    trayIcon.setImageAutoSize(true);
                    tray.add(trayIcon);
                } catch (AWTException e) {
                    System.out.println("TrayIcon could not be added.");
                }
            }
        }

        ctrlrvw.addMHMIListener(this);
        return systraysupported;
    }

    // *---*/
    public boolean isSysTraySupported() {
        return systraysupported;
    }

    // *---*/
    protected static Image createImage(String path, String description) {
        URL imageURL;// = SysTray.class.getResource(path);

        imageURL = SysTray.class.getClassLoader().getResource(path);

        if (imageURL == null) {
            System.err.println("Pas de film de boule :-( " + path);
            return null;
        }
        else {
            return (new ImageIcon(imageURL, description)).getImage();
        }
    }

    // *-----------------------------*/
    // *- Les évgènements du modèle -*/
    // *-----------------------------*/
    @Override
    public void showMHMI(MHMIShowEvent mhmie) {
        showItem.setEnabled(false);
        hideItem.setEnabled(true);
    }

    @Override
    public void hideMHMI(MHMIHideEvent mhmie) {
        showItem.setEnabled(true);
        hideItem.setEnabled(false);
    }

    @Override
    public void integrationStart(IntegrationEvent ie) {
        //ctrlrvw.hideMHMI(this);
        exitItem.setEnabled(false);

        showitemstate = showItem.isEnabled();
        hideitemstate = hideItem.isEnabled();

        showItem.setEnabled(false);
        hideItem.setEnabled(false);
        integreItem.setEnabled(false);
    }

    @Override
    public void integrationEnd(IntegrationEvent ie) {
        //ctrlrvw.hideMHMI(this);
        integreItem.setEnabled(true);
        exitItem.setEnabled(true);

        if(showitemstate)
            showItem.setEnabled(true);

        if(hideitemstate)
            hideItem.setEnabled(true);

        //ctrlrvw.showMHMI(this);
    }

    @Override
    public void integrationAddGrpRow(GrouppEvent gce) {}

    @Override
    public void integrationAddDateRow(DateEvent dce) {
    }

    @Override
    public void SystrayMessage(IntegreSystrayMessageEvent ime) {
        trayIcon.displayMessage("Intégration", ime.getMessage(), TrayIcon.MessageType.INFO);
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.playgrid;

import euromillions.controller.Controller;
import euromillions.event.PlayGridEvent;
import euromillions.event.PlayedGridEvent;
import euromillions.listener.PlayGridListener;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlPlayedGridsList extends JPanel
                                implements PlayGridListener{
    private final   Controller ctrlr;

    private         PnlPlayedGridsAllLines pnlplayedAllLines;

    public PnlPlayedGridsList(Controller _ctrlr) {
        ctrlr   =   _ctrlr;
    }

    public void mkView() {
        setLayout(new MigLayout("wrap 1"));
        ctrlr.addPlayGridListener(this);
    }

    private void resetPanel() {
        this.removeAll();
        getParent().getParent().getParent().revalidate();
        this.repaint();
    }

    @Override
    public void PlayGridChange(PlayGridEvent pge) {}

    @Override
    public void newPlayedGridSet() {
        resetPanel();
    }

    @Override
    public void endPlayedGridSet() {

    }

    @Override
    public void PlayedGridFeched(PlayedGridEvent pge) {

        pnlplayedAllLines = new PnlPlayedGridsAllLines( ctrlr,
                                        pge.getDrawDate(),
                                        pge.getPlayedDate(),
                                        pge.getGridNumber(),
                                        pge.getPlayedId(),
                                        pge.getFirsName(),
                                        pge.getLastName(),
                                        pge.getPlyedBalls(),
                                        pge.getPlayedStars());

        pnlplayedAllLines.mkView();
        add(pnlplayedAllLines);
    }
}

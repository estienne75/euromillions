/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.playgrid;

import euromillions.controller.Controller;
import euromillions.event.DrawBallEvent;
import euromillions.event.DrawEvent;
import euromillions.event.SynthesesAvTirageEvent;
import euromillions.event.SynthesesNbTirageEvent;
import euromillions.listener.DrawListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class PnlPlayBallsGrid    extends     JPanel
                                implements  ActionListener,
                                            DrawListener {
    private final Controller ctrlr;

    private final Font font20;
    private final JCheckBox[]   achbxBall;
    private final boolean[]     selected    = new boolean[50];

    public PnlPlayBallsGrid(Controller _ctrlr) {
        ctrlr       =_ctrlr;
        achbxBall   = new JCheckBox[50];
        font20      = new Font("Courrie New", Font.BOLD, 20);
    }

    public void mkView() {
        setLayout(new MigLayout("wrap 5", "50[80] 50[80] 50[80]"));

        for(int j=0; j<10; j++) {
            for(int k=0; k<50; k+=10) {
                int i = j+k;

                String sballnum = i<9 ? "0" + (i+1):
                                        "" + (i+1);

                achbxBall[i] = new JCheckBox(sballnum);
                achbxBall[i].setFont(font20);

                add(achbxBall[i]);

                achbxBall[i].addActionListener(this);
            }
        }

        ctrlr.addTirageListener(this);
    }

    private void switchSelectdBall(String _ball, boolean _selected) {
        int iball = Integer.parseInt(_ball);

        selected[iball-1] = _selected;
        achbxBall[iball-1].setSelected(selected[iball-1]);

        if(selected[iball-1])
            achbxBall[iball-1].setForeground(euromillions.EuroMillions.SELECTED_COLOR);
        else
            achbxBall[iball-1].setForeground(Color.black);
    }

    @Override
    public void NewDrawRow(DrawEvent nte) {}

    @Override
    public void EndDraw(DrawEvent nte) {}

    @Override
    public void DrawBallSelected(DrawBallEvent tbe) {
        switchSelectdBall(tbe.getBallNumber(), tbe.getBallStatus());
    }

    @Override
    public void StatNbDraw(SynthesesNbTirageEvent snte) {}

    @Override
    public void StatAvNbDraw(SynthesesAvTirageEvent sate) {}

    @Override
    public void StatNbDrawE(SynthesesNbTirageEvent snte) {}

    @Override
    public void actionPerformed(ActionEvent ae) {
        ctrlr.selectBall(this, ((JCheckBox) ae.getSource()).getText());
    }
}

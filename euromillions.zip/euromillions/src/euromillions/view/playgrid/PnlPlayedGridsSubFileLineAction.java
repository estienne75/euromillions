/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.playgrid;

import euromillions.controller.Controller;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public final class PnlPlayedGridsSubFileLineAction extends JPanel{

    /*-----------*/
    /*- E N U M -*/
    /*-----------*/
    public static enum EnumSFL1 {
        // Column Header.
        // --------------
        SELECTION          ("JLabel", "Selection",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        PRINT          (   "JLabel", "Impression",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray);


        public final static int ORDNL_SELECTION = SELECTION.ordinal();
        public final static int ORDNL_PRINT     = PRINT.ordinal();



        // HEADER
        private final String    hcomponenttype;
        private final String    htext;
        private final String    hfontfamily;
        private final int       hfontsize;
        private final int       hfontstyle;
        private final Color     hforegroundcolor;
        private final Color     hbackgroundcolor;

        // Data
        private final String    dcomponenttype;
        private String          dtext;
        private final String    dfontfamily;
        private final int       dfontsize;
        private final int       dfontstyle;
        private final Color     dforegroundcolor;
        private final Color     dbackgroundcolor;


        /*-----------------------------------------*/
        /*- E N U M   c o n s t r u c t o r (...) -*/
        /*-----------------------------------------*/
        EnumSFL1(
                // Header.
                String      _hcomponenttype,
                String      _htext,
                String      _hfontfamily,
                int         _hfontsize,
                int         _hfontstyle,
                Color       _hforegroundcolor,
                Color       _hbackgraoundcolor,

                // Data.
                String      _dcomponenttype,
                String      _dfontfamily,
                int         _dfontsize,
                int         _dfontstyle,
                Color       _dforegroundcolor,
                Color       _dbackgraoundcolor) {
            hcomponenttype      = _hcomponenttype;
            htext               = _htext;
            hfontfamily         = _hfontfamily;
            hfontsize           = _hfontsize;
            hfontstyle          = _hfontstyle;
            hforegroundcolor    = _hforegroundcolor;
            hbackgroundcolor    = _hbackgraoundcolor;

            dcomponenttype      = _dcomponenttype;
            dfontfamily         = _dfontfamily;
            dfontsize           = _dfontsize;
            dfontstyle          = _dfontstyle;
            dforegroundcolor    = _dforegroundcolor;
            dbackgroundcolor    = _dbackgraoundcolor;
        }

        public static int getNumberOfElement() {
            return PRINT.ordinal()+1;
        }

        public int getOrdinal() {
            return ordinal();
        }

        public String getHText() {
            return htext;
        }

        public String getHFontFamily() {
            return hfontfamily;
        }

        public int getHFontSize() {
            return hfontsize;

        }

        public int getHFontStyle() {
            return hfontstyle;
        }

        public Color getHForeground() {
            return hforegroundcolor;
        }

        public Color getHBackground() {
            return hbackgroundcolor;
        }

        //Column data
        public String getDataComponentType() {
            return dcomponenttype;
        }

        public String getDFontFamily() {
            return dfontfamily;
        }

        public int getDFontSize() {
            return dfontsize;
        }

        public int getDFontStyle() {
            return dfontstyle;
        }

        public Color getDForeground() {
            return dforegroundcolor;
        }

        public Color getDBackground() {
            return dbackgroundcolor;
        }
    }

    private final   Controller  ctrlr;
    private final   int[]       balls;
    private final   int[]       stars;
    private final   JPanel      pnl;
    private final   JLabel[]    ahjlbl  = new JLabel[EnumSFL1.getNumberOfElement()];                                    // Libellé des entêtes de colonnes.
    private final   JButton[]   adbttn  = new JButton[PnlPlayedGridsSubFileLineAction.EnumSFL1.getNumberOfElement()];   // Libellé des données.
    private final   String[]    astring = new String[EnumSFL1.getNumberOfElement()];                                    // Données des colonnes.
    private         boolean     viewbuilded;

    /*-------------------------------------------*/
    /*- C L A S S   c o n s t r u c t o r (...) -*/
    /*-------------------------------------------*/
    public PnlPlayedGridsSubFileLineAction(Controller _ctrlr, int[] _balls, int[] _stars) {
        ctrlr = _ctrlr;

        balls = _balls;
        stars = _stars;

        pnl = new JPanel();
        pnl.setLayout(new MigLayout("wrap 2", "20[60] 20[60] 20[60]"));

        for(PnlPlayedGridsSubFileLineAction.EnumSFL1 c: PnlPlayedGridsSubFileLineAction.EnumSFL1.values()) {
            ahjlbl[c.getOrdinal()] = new JLabel(c.getHText());

            ahjlbl[c.getOrdinal()]
                .setFont(new Font(  c.getHFontFamily(),
                                    c.getHFontStyle(),
                                    c.getHFontSize()));

            ahjlbl[c.getOrdinal()].setForeground(c.getHForeground());
        }

        for(PnlPlayedGridsSubFileLineAction.EnumSFL1 c: PnlPlayedGridsSubFileLineAction.EnumSFL1.values()) {
            if(c == PnlPlayedGridsSubFileLineAction.EnumSFL1.PRINT)
                pnl.add(getHComponent(c), "wrap");
            else
                pnl.add(getHComponent(c));
        }

        // Data line.
        for(PnlPlayedGridsSubFileLineAction.EnumSFL1 c: PnlPlayedGridsSubFileLineAction.EnumSFL1.values()) {

            switch(c.ordinal()) {
                case 0:
                    setDText(c, "Billes");
                    break;

                case 1:
                    setDText(c, "Imprimer");
                    break;
            }

            pnl.add(getDComponent(c));
        }
    }

    public void mkView() {
        if(!viewbuilded) {
            setLayout(new FlowLayout(FlowLayout.LEFT));
            add(pnl);

            adbttn[0].addActionListener((ActionEvent e) -> {
                ctrlr.reset(adbttn[0]);

                for(int i=0; i<balls.length; i++) {
                    if(balls[i]!=0)
                        ctrlr.selectBall(adbttn[0], (balls[i]<10)? "0" + balls[i]: "" + balls[i]);
                }
            });

            viewbuilded = true;
        }
    }


    public JLabel getHComponent(PnlPlayedGridsSubFileLineAction.EnumSFL1 _sfle) {
        return ahjlbl[_sfle.ordinal()];
    }

    public void setDText(PnlPlayedGridsSubFileLineAction.EnumSFL1 _c, String _text) {
        astring[_c.ordinal()] = _text;

        adbttn[_c.getOrdinal()] = new JButton(_text);
        adbttn[_c.getOrdinal()].setForeground(_c.getDForeground());
        adbttn[_c.getOrdinal()].setFont(new Font(_c.getDFontFamily(),
                                                _c.getDFontStyle(),
                                                _c.getDFontSize()));
    }

    public JButton getDComponent(PnlPlayedGridsSubFileLineAction.EnumSFL1 _sfle) {
        return adbttn[_sfle.ordinal()];
    }
}

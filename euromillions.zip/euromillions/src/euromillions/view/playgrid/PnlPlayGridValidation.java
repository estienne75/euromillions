/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.playgrid;

import euromillions.controller.Controller;
import euromillions.event.PlayGridEvent;
import euromillions.event.PlayedGridEvent;
import euromillions.listener.PlayGridListener;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import org.joda.time.DateTime;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */

public class PnlPlayGridValidation    extends JPanel
                                    implements PlayGridListener {
    private final Controller ctrlr;

    private final Font font16;

    private final JLabel  lblNextDrawDate;
    private String  snxtrdrwdt;
    private DateTime dt;

    private JButton bttnvValidate;
    private JLabel  lblValidateMsg;

    public PnlPlayGridValidation(Controller _ctrlr) {
        ctrlr =_ctrlr;
        font16 = new Font("Courrie New", Font.BOLD, 16);

        dt = new DateTime();

        switch(dt.getDayOfWeek()) {
            case 1:                 // Monday   ->  Tuesday -> +1
                dt = dt.plusDays(1);
                break;

            case 3:                 // Wednesday -> Friday  -> +2
                dt = dt.plusDays(2);
                break;

            case 4:                // Thurday   ->  Friday  -> +1
                dt = dt.plusDays(1);
                break;

            case 6:                 // Saturday ->  Tuesday -> +3
                dt = dt.plusDays(3);
                break;

            case 7:                 // Sunday   ->  Tuesday -> +2
                dt = dt.plusDays(2);
                break;
        }

        lblNextDrawDate = new JLabel("Date du prochain tirage: " + dt.toString("dd.MM.yyyy"));
        lblNextDrawDate.setFont(font16);

        bttnvValidate   = new JButton("Valider");
        bttnvValidate.setEnabled(false);
        lblValidateMsg  = new JLabel("<- Grille invalide !");
        lblValidateMsg.setForeground(Color.red);
    }

    public void mkView() {
        setLayout(new MigLayout());

        add(lblNextDrawDate);
        add(bttnvValidate);
        add(lblValidateMsg);

        ctrlr.addPlayGridListener(this);

        bttnvValidate.addActionListener((ActionEvent e) -> {
            ctrlr.validatePlayGrid(dt);
            ctrlr.loadPlayedGrids(this);
        });
    }

    @Override
    public void PlayGridChange(PlayGridEvent pge) {
        bttnvValidate.setEnabled(pge.isPlayGridValid());
        lblValidateMsg.setText( pge.isPlayGridValid()?
                                        "<- Validez votre grille de jeu.":
                                        "<- Grille de jeu invalide !");
        lblValidateMsg.setForeground(pge.isPlayGridValid()?
                                                            Color.black:
                                                            Color.red);
        bttnvValidate.setEnabled(pge.isPlayGridValid());
    }


    @Override
    public void newPlayedGridSet() {}

    @Override
    public void endPlayedGridSet() {}

    @Override
    public void PlayedGridFeched(PlayedGridEvent pge) {}
}

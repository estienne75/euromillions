/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.playgrid;

import euromillions.controller.Controller;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class PnlPlayStarsGrid    extends     JPanel
                                implements  ActionListener {
    private final Controller    ctrlr;

    private final Font          font20;
    private final JCheckBox[]   achbxStar;

    public PnlPlayStarsGrid(Controller _ctrlr) {
        ctrlr =_ctrlr;

        achbxStar = new JCheckBox[50];
        font20 = new Font("Courrie New", Font.BOLD, 20);
    }

    public void mkView() {
        setLayout(new MigLayout());

        for(int i=0; i<12; i++) {
            String sstarnum = i<9 ? "0" + (i+1):
                                    ""  + (i+1);

            achbxStar[i] = new JCheckBox(sstarnum);
            achbxStar[i].setFont(font20);

            add(achbxStar[i]);
            achbxStar[i].addActionListener(this);
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        ctrlr.playGridStarSelected(this, ((JCheckBox) ae.getSource()).getText(),
                                         ((JCheckBox) ae.getSource()).isSelected());

        if(((JCheckBox) ae.getSource()).isSelected())
            ((JCheckBox) ae.getSource()).setForeground(Color.yellow);
        else
            ((JCheckBox) ae.getSource()).setForeground(Color.black);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.playgrid;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public final class PnlPlayedGridsSubFileLineBalls extends JPanel{

    /*-----------*/
    /*- E N U M -*/
    /*-----------*/
    public static enum EnumSFL1 {
        // Column Header.
        // --------------
        BALL01          (   "JLabel", "Bille 01",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        BALL02          (   "JLabel", "Bille 02",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        BALL03          (   "JLabel", "Bille 03",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        BALL04          (   "JLabel", "Bille 04",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        BALL05          (   "JLabel", "Bille 05",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        BALL06          (   "JLabel", "Bille 06",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        BALL07          (   "JLabel", "Bille 07",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        BALL08          (   "JLabel", "Bille 08",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        BALL09          (   "JLabel", "Bille 09",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        BALL10          (   "JLabel", "Bille 10",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JButton",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray);


        public final static int ORDNL_BALL01    = BALL01.ordinal();
        public final static int ORDNL_BALL02    = BALL02.ordinal();
        public final static int ORDNL_BALL03    = BALL03.ordinal();
        public final static int ORDNL_BALL04    = BALL04.ordinal();
        public final static int ORDNL_BALL05    = BALL05.ordinal();
        public final static int ORDNL_BALL06    = BALL06.ordinal();
        public final static int ORDNL_BALL07    = BALL07.ordinal();
        public final static int ORDNL_BALL08    = BALL08.ordinal();
        public final static int ORDNL_BALL09    = BALL09.ordinal();
        public final static int ORDNL_BALL10    = BALL10.ordinal();


        // HEADER
        private final String    hcomponenttype;
        private final String    htext;
        private final String    hfontfamily;
        private final int       hfontsize;
        private final int       hfontstyle;
        private final Color     hforegroundcolor;
        private final Color     hbackgroundcolor;

        // Data
        private final String    dcomponenttype;
        private String          dtext;
        private final String    dfontfamily;
        private final int       dfontsize;
        private final int       dfontstyle;
        private final Color     dforegroundcolor;
        private final Color     dbackgroundcolor;


        /*-----------------------------------------*/
        /*- E N U M   c o n s t r u c t o r (...) -*/
        /*-----------------------------------------*/
        EnumSFL1(
                // Header.
                String      _hcomponenttype,
                String      _htext,
                String      _hfontfamily,
                int         _hfontsize,
                int         _hfontstyle,
                Color       _hforegroundcolor,
                Color       _hbackgraoundcolor,

                // Data.
                String      _dcomponenttype,
                String      _dfontfamily,
                int         _dfontsize,
                int         _dfontstyle,
                Color       _dforegroundcolor,
                Color       _dbackgraoundcolor) {
            hcomponenttype      = _hcomponenttype;
            htext               = _htext;
            hfontfamily         = _hfontfamily;
            hfontsize           = _hfontsize;
            hfontstyle          = _hfontstyle;
            hforegroundcolor    = _hforegroundcolor;
            hbackgroundcolor    = _hbackgraoundcolor;

            dcomponenttype      = _dcomponenttype;
            dfontfamily         = _dfontfamily;
            dfontsize           = _dfontsize;
            dfontstyle          = _dfontstyle;
            dforegroundcolor    = _dforegroundcolor;
            dbackgroundcolor    = _dbackgraoundcolor;
        }

        public static int getNumberOfElement() {
            return BALL10.ordinal()+1;
        }

        public int getOrdinal() {
            return ordinal();
        }

        public String getHText() {
            return htext;
        }

        public String getHFontFamily() {
            return hfontfamily;
        }

        public int getHFontSize() {
            return hfontsize;

        }

        public int getHFontStyle() {
            return hfontstyle;
        }

        public Color getHForeground() {
            return hforegroundcolor;
        }

        public Color getHBackground() {
            return hbackgroundcolor;
        }

        //Column data
        public String getDataComponentType() {
            return dcomponenttype;
        }

        public String getDFontFamily() {
            return dfontfamily;
        }

        public int getDFontSize() {
            return dfontsize;
        }

        public int getDFontStyle() {
            return dfontstyle;
        }

        public Color getDForeground() {
            return dforegroundcolor;
        }

        public Color getDBackground() {
            return dbackgroundcolor;
        }
    }

    private final   JPanel      pnl;
    private final   JLabel[]    ahjlbl  = new JLabel[EnumSFL1.getNumberOfElement()];        // Libellé des entêtes de colonnes.
    private final   JLabel[]    adlbl   = new JLabel[EnumSFL1.getNumberOfElement()];        // Libellé des données.
    private final   String[]    astring = new String[EnumSFL1.getNumberOfElement()];        // Données des colonnes.
    private         boolean     viewbuilded;

    /*-------------------------------------------*/
    /*- C L A S S   c o n s t r u c t o r (...) -*/
    /*-------------------------------------------*/
    public PnlPlayedGridsSubFileLineBalls(int[] _balls) {
        pnl = new JPanel();
        pnl.setLayout(new MigLayout("wrap 10", "20[80] 20[80] 20[80]"));


        for(PnlPlayedGridsSubFileLineBalls.EnumSFL1 c: PnlPlayedGridsSubFileLineBalls.EnumSFL1.values()) {
            ahjlbl[c.getOrdinal()] = new JLabel(c.getHText());

            ahjlbl[c.getOrdinal()]
                .setFont(new Font(  c.getHFontFamily(),
                                    c.getHFontStyle(),
                                    c.getHFontSize()));

            ahjlbl[c.getOrdinal()].setForeground(c.getHForeground());
        }

        // Header line.
        for(PnlPlayedGridsSubFileLineBalls.EnumSFL1 c: PnlPlayedGridsSubFileLineBalls.EnumSFL1.values()) {
            if(c == PnlPlayedGridsSubFileLineBalls.EnumSFL1.BALL10)
                pnl.add(getHComponent(c), "wrap");
            else
                pnl.add(getHComponent(c));
        }

        // Data line.
        for(PnlPlayedGridsSubFileLineBalls.EnumSFL1 c: PnlPlayedGridsSubFileLineBalls.EnumSFL1.values()) {
            if(_balls[c.ordinal()] == 0)
                setDText(c, "Néant");
            else
                setDText(c, (_balls[c.ordinal()] < 10)?
                                                    "0" + _balls[c.ordinal()]:
                                                    ""  + _balls[c.ordinal()]);

            if(c == PnlPlayedGridsSubFileLineBalls.EnumSFL1.BALL10)
                pnl.add(getDComponent(c), "wrap");
            else
                pnl.add(getDComponent(c));
        }
    }

    public void mkView() {
        if(!viewbuilded) {
            setLayout(new FlowLayout(FlowLayout.LEFT));
            add(pnl);
            viewbuilded = true;
        }
    }


    public JLabel getHComponent(PnlPlayedGridsSubFileLineBalls.EnumSFL1 _sfle) {
        return ahjlbl[_sfle.ordinal()];
    }

    public void setDText(PnlPlayedGridsSubFileLineBalls.EnumSFL1 _c, String _text) {
        astring[_c.ordinal()] = _text;

        adlbl[_c.getOrdinal()] = new JLabel(_text);
        adlbl[_c.getOrdinal()].setForeground(_c.getDForeground());
        adlbl[_c.getOrdinal()].setFont(new Font(_c.getDFontFamily(),
                                                _c.getDFontStyle(),
                                                _c.getDFontSize()));
    }

    public JLabel getDComponent(PnlPlayedGridsSubFileLineBalls.EnumSFL1 _sfle) {
        return adlbl[_sfle.ordinal()];
    }
}

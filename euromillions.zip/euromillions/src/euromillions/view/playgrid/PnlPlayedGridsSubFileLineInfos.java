/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.playgrid;

import euromillions.controller.Controller;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public final class PnlPlayedGridsSubFileLineInfos extends JPanel{

    /*-----------*/
    /*- E N U M -*/
    /*-----------*/
    public static enum EnumSFL1 {
        // Column Header.
        // --------------
        DRAW_DATE       (   "JLabel", "Date de tirage",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JLabel",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        PLAYED_DATE     (   "JLabel", "Date de valisation",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JLabel",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        GRID_NUMBER     (   "JLabel", "N° de grille",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JLabel",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        USER_ID         (   "JLabel", "Id utilisateur",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JLabel",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        FIRST_NAME      (   "JLabel", "Prénom",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JLabel",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray),

        LAST_NAME       (   "JLabel", "Nom",
                            "Tahoma", 14, Font.PLAIN, Color.blue, Color.gray,
                            /*----*/
                            "JLabel",
                            "Tahoma", 12, Font.BOLD, Color.black, Color.gray);


        public final static int ORDNL_DRAWS_DATE    = DRAW_DATE.ordinal();
        public final static int ORDNL_PLAYED_DATE   = PLAYED_DATE.ordinal();
        public final static int ORDNL_GRID_NUMBER   = GRID_NUMBER.ordinal();
        public final static int ORDNL_USER_ID       = USER_ID.ordinal();
        public final static int ORDNL_FIRST_NAME    = FIRST_NAME.ordinal();
        public final static int ORDNL_LAST_NAME     = LAST_NAME.ordinal();

        // HEADER
        private final String    hcomponenttype;
        private final String    htext;
        private final String    hfontfamily;
        private final int       hfontsize;
        private final int       hfontstyle;
        private final Color     hforegroundcolor;
        private final Color     hbackgroundcolor;

        // Data
        private final String    dcomponenttype;
        private String          dtext;
        private final String    dfontfamily;
        private final int       dfontsize;
        private final int       dfontstyle;
        private final Color     dforegroundcolor;
        private final Color     dbackgroundcolor;


        /*-----------------------------------------*/
        /*- E N U M   c o n s t r u c t o r (...) -*/
        /*-----------------------------------------*/
        EnumSFL1(
                // Header.
                String      _hcomponenttype,
                String      _htext,
                String      _hfontfamily,
                int         _hfontsize,
                int         _hfontstyle,
                Color       _hforegroundcolor,
                Color       _hbackgraoundcolor,

                // Data.
                String      _dcomponenttype,
                String      _dfontfamily,
                int         _dfontsize,
                int         _dfontstyle,
                Color       _dforegroundcolor,
                Color       _dbackgraoundcolor) {
            hcomponenttype      = _hcomponenttype;
            htext               = _htext;
            hfontfamily         = _hfontfamily;
            hfontsize           = _hfontsize;
            hfontstyle          = _hfontstyle;
            hforegroundcolor    = _hforegroundcolor;
            hbackgroundcolor    = _hbackgraoundcolor;

            dcomponenttype      = _dcomponenttype;
            dfontfamily         = _dfontfamily;
            dfontsize           = _dfontsize;
            dfontstyle          = _dfontstyle;
            dforegroundcolor    = _dforegroundcolor;
            dbackgroundcolor    = _dbackgraoundcolor;
        }

        public static int getNumberOfElement() {
            return LAST_NAME.ordinal()+1;
        }

        public int getOrdinal() {
            return ordinal();
        }

        public String getHText() {
            return htext;
        }

        public String getHFontFamily() {
            return hfontfamily;
        }

        public int getHFontSize() {
            return hfontsize;

        }

        public int getHFontStyle() {
            return hfontstyle;
        }

        public Color getHForeground() {
            return hforegroundcolor;
        }

        public Color getHBackground() {
            return hbackgroundcolor;
        }

        //Column data
        public String getDataComponentType() {
            return dcomponenttype;
        }

        public String getDFontFamily() {
            return dfontfamily;
        }

        public int getDFontSize() {
            return dfontsize;
        }

        public int getDFontStyle() {
            return dfontstyle;
        }

        public Color getDForeground() {
            return dforegroundcolor;
        }

        public Color getDBackground() {
            return dbackgroundcolor;
        }
    }

    private final   Controller  ctrlr;
    private final   JPanel      pnl;
    private final   JLabel[]    ahlbl  = new JLabel[EnumSFL1.getNumberOfElement()];        // Libellé des entêtes de colonnes.
    private final   JLabel[]    adlbl  = new JLabel[EnumSFL1.getNumberOfElement()];        // Libellé des données.
    private final   String[]    astring = new String[EnumSFL1.getNumberOfElement()];        // Données des colonnes.
    private         boolean     viewbuilded;

    /*-------------------------------------------*/
    /*- C L A S S   c o n s t r u c t o r (...) -*/
    /*-------------------------------------------*/
    public PnlPlayedGridsSubFileLineInfos(Controller _ctrlr,
                                          String    _drawdate,
                                          String    _playeddate,
                                          int       _gridnumber,
                                          int       _userid,
                                          String    _firstname,
                                          String    _lastname) {
        ctrlr = _ctrlr;

        pnl = new JPanel();
        pnl.setLayout(new MigLayout("wrap 6", "20[80] 20[80] 20[80]"));

        for(PnlPlayedGridsSubFileLineInfos.EnumSFL1 c: PnlPlayedGridsSubFileLineInfos.EnumSFL1.values()) {
            ahlbl[c.getOrdinal()] = new JLabel(c.getHText());

            ahlbl[c.getOrdinal()]
                .setFont(new Font(  c.getHFontFamily(),
                                    c.getHFontStyle(),
                                    c.getHFontSize()));



            ahlbl[c.getOrdinal()].setForeground(c.getHForeground());

            switch(c.ordinal()) {
                case 0:
                    setDText(c, _drawdate);
                    break;

                case 1:
                    setDText(c, _playeddate);
                    break;

                case 2:
                    setDText(c, "" + _gridnumber);
                    break;

                case 3:
                    setDText(c, "" + _userid);
                    break;

                case 4:
                    setDText(c, _firstname);
                    break;

                case 5:
                    setDText(c, _lastname);
                    break;
            }


        }

        // Header line.
        for(PnlPlayedGridsSubFileLineInfos.EnumSFL1 c: PnlPlayedGridsSubFileLineInfos.EnumSFL1.values()) {
            if(c == PnlPlayedGridsSubFileLineInfos.EnumSFL1.LAST_NAME)
                pnl.add(getHComponent(c), "wrap");
            else
                pnl.add(getHComponent(c));
        }

        // Data line.
        for(PnlPlayedGridsSubFileLineInfos.EnumSFL1 c: PnlPlayedGridsSubFileLineInfos.EnumSFL1.values()) {
            if(c == PnlPlayedGridsSubFileLineInfos.EnumSFL1.LAST_NAME)
                pnl.add(getDComponent(c), "wrap");
            else
                pnl.add(getDComponent(c));
        }
    }

    public void mkView() {
        if(!viewbuilded) {
            setLayout(new FlowLayout(FlowLayout.LEFT));
            add(pnl);
            viewbuilded = true;
        }
    }


    public JLabel getHComponent(PnlPlayedGridsSubFileLineInfos.EnumSFL1 _sfle) {
        return ahlbl[_sfle.ordinal()];
    }

    public void setDText(PnlPlayedGridsSubFileLineInfos.EnumSFL1 _c, String _text) {
        astring[_c.ordinal()] = _text;

        adlbl[_c.getOrdinal()] = new JLabel(_text);
        adlbl[_c.getOrdinal()].setForeground(_c.getDForeground());
        adlbl[_c.getOrdinal()].setFont(new Font(_c.getDFontFamily(),
                                                _c.getDFontStyle(),
                                                _c.getDFontSize()));

    }


    public JLabel getDComponent(PnlPlayedGridsSubFileLineInfos.EnumSFL1 _sfle) {
        return adlbl[_sfle.ordinal()];
    }
}

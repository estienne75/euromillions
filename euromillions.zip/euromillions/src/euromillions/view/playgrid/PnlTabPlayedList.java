/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.playgrid;

import euromillions.view.playgrid.PnlPlayedGridsList;
import euromillions.controller.Controller;
import euromillions.view.PnlTitle;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class PnlTabPlayedList extends JPanel {
    private final   Controller  ctrlr;

    private final   JScrollPane         scrlPlayedList;
    private         PnlTitle            pnltitleplayedlist;
    private final   PnlPlayedGridsList  pnlPlayedGridsList;

    public PnlTabPlayedList(Controller _ctrlr) {
        ctrlr = _ctrlr;

        pnlPlayedGridsList  = new PnlPlayedGridsList(ctrlr);
        scrlPlayedList      = new JScrollPane(pnlPlayedGridsList);
    }

    public void mkView() {
        setLayout(new BorderLayout());

        pnltitleplayedlist  = new PnlTitle( FlowLayout.CENTER,
                                            "Grille des jeux enrigistrés",
                                            euromillions.EuroMillions.SELECTED_COLOR,
                                            40);
        pnltitleplayedlist.mkView();
        add(pnltitleplayedlist, BorderLayout.NORTH);

        pnlPlayedGridsList.mkView();

        scrlPlayedList.getVerticalScrollBar().setUnitIncrement(16);
        add(scrlPlayedList, BorderLayout.CENTER);
    }

    private void resetPanel() {
        this.removeAll();
        getParent().getParent().getParent().revalidate();
        this.repaint();
    }
}

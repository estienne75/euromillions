/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.playgrid;

import euromillions.controller.Controller;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlPlayedGridsAllLines extends JPanel {

    private final Controller ctrlr;
    private final PnlPlayedGridsSubFileLineInfos    pnllineinfos;
    private final PnlPlayedGridsSubFileLineBalls    pnllineballs;
    private final PnlPlayedGridsSubFileLineStars    pnllinestars;
    private final PnlPlayedGridsSubFileLineAction   pnllineaction;

    public PnlPlayedGridsAllLines(Controller    _ctrlr,
                                    String      _drawdate,
                                    String      _playeddate,
                                    int         _gridnumber,
                                    int         _playerid,
                                    String      _firstname,
                                    String      _lastname,
                                    int[]       _balls,
                                    int[]       _stars) {
        ctrlr   =   _ctrlr;
        pnllineinfos = new PnlPlayedGridsSubFileLineInfos(  ctrlr,
                                                            _drawdate,
                                                            _playeddate,
                                                            _gridnumber,
                                                            _playerid,
                                                            _firstname,
                                                            _lastname);
        pnllineballs    = new PnlPlayedGridsSubFileLineBalls(_balls);
        pnllinestars    = new PnlPlayedGridsSubFileLineStars(_stars);
        pnllineaction   = new PnlPlayedGridsSubFileLineAction(_ctrlr, _balls, _stars);
    }

    protected void mkView() {
        setLayout(new MigLayout("wrap 1"));
        setBorder(new LineBorder(Color.white));

        pnllineinfos.mkView();
        pnllineballs.mkView();
        pnllinestars.mkView();
        pnllineaction.mkView();

        add(pnllineinfos);
        add(pnllineballs);
        add(pnllinestars);
        add(pnllineaction);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view;

import euromillions.view.schemas.PnlSchemasList;
import euromillions.controller.Controller;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.LineBorder;

/**
 *
 * @author Stéphane
 */
public class PnlTabSchemas extends JPanel {
    private final Controller ctrlr;

    private final PnlSchemasList    pnlschemaslist;
    private final JScrollPane       scrlpane;


    public PnlTabSchemas(Controller _ctrlr) {
        ctrlr = _ctrlr;

        pnlschemaslist = new PnlSchemasList(_ctrlr);
        scrlpane = new JScrollPane(pnlschemaslist);
        scrlpane.getVerticalScrollBar().setUnitIncrement(16);
    }

    public void mkView() {
        setLayout(new BorderLayout());
        setBorder(new LineBorder(Color.blue));

        PnlTitle pnlgridtitle = new PnlTitle(   FlowLayout.CENTER,
                                                "Schémas",
                                                Color.blue,
                                                40);
        pnlgridtitle.mkView();
        pnlschemaslist.mkView();

        add(pnlgridtitle, BorderLayout.NORTH);
        add(scrlpane, BorderLayout.CENTER);
    }
}

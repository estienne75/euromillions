/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.schemas;

import euromillions.controller.Controller;
import euromillions.event.SchemaOccsEvent;
import euromillions.listener.SchemaOccsListener;
import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author Stéphane
 */
public class PnlSchemasList extends     JPanel
                            implements  SchemaOccsListener{

    private final Controller ctrlr;


    public PnlSchemasList(Controller _ctrlr) {
        ctrlr   =   _ctrlr;
    }

    public void mkView() {
        setLayout(new MigLayout("wrap 1"));

        ctrlr.addSchemasListener(this);
    }

    private void resetPanel() {
        int cc = this.getComponentCount();

        for(int i=0; i<cc; i++)
            if(this.getComponent(i) instanceof PnlSchemaDetailRow)
                ((PnlSchemaDetailRow)this.getComponent(i)).removeButtonActionListener();

        this.removeAll();
        getParent().getParent().getParent().revalidate();
        this.repaint();
    }

    @Override
    public void newSchemasInProgress() {
        resetPanel();
    }

    @Override
    public void newSchema(SchemaOccsEvent soe) {
        PnlSchemaDetailRow pnlschema = new PnlSchemaDetailRow(  ctrlr,
                                                                soe.getCycleType(),
                                                                soe.getDrawDate(),
                                                                soe.getStartDate(),
                                                                soe.getEndDate(),
                                                                soe.getRefStartDate(),
                                                                soe.getRedEndDate(),
                                                                soe.getSchemaOccs(),
                                                                soe.getSchemaWeight());
        pnlschema.mkView();
        add(pnlschema);
    }
}

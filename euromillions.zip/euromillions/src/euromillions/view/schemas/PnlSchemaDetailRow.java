/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view.schemas;

import euromillions.controller.Controller;
import euromillions.view.PnlTitle;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import net.miginfocom.swing.MigLayout;

/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class PnlSchemaDetailRow extends     JPanel
                                implements  ActionListener{

    private final Controller    ctrlr;

    private final JButton[]     abttn;

    private final String        cycletype;
    private final String        drawdate;
    private final String        startdate;
    private final String        enddate;
    private final String        refstartdate;
    private final String        refenddate;
    private final int[]         schema;
    private final long          schemaweight;

    public PnlSchemaDetailRow(  Controller  _ctrlr,
                                String      _cyletype,
                                String      _drawdate,
                                String      _startdate,
                                String      _enddate,
                                String      _refstartdate,
                                String      _refenddate,
                                int[]       _schema,
                                long        _schemaweight) {
        ctrlr           =   _ctrlr;
        cycletype       =   _cyletype;
        drawdate        =   _drawdate;
        startdate        =   _startdate;
        enddate         =   _enddate;
        refstartdate    =   _refstartdate;
        refenddate      =   _refenddate;
        schema          =   _schema;
        schemaweight    =   _schemaweight;

        abttn = new JButton[5];
    }

    public void mkView() {
        setLayout(new MigLayout("wrap 5", "10[50] 10[50] 10[50]"));
        setBorder(new LineBorder(Color.white));

        PnlTitle pnldatetitle = new PnlTitle(FlowLayout.LEFT, "Dates tirage", Color.blue, 20);
        pnldatetitle.mkView();
        add(pnldatetitle);

        PnlTitle pnlstrccltitle = new PnlTitle(FlowLayout.LEFT, "Début cycle", Color.blue, 20);
        pnlstrccltitle.mkView();
        add(pnlstrccltitle);

        PnlTitle pnlendccltitle = new PnlTitle(FlowLayout.LEFT, "Fin cycle", Color.blue, 20);
        pnlendccltitle.mkView();
        add(pnlendccltitle);

        PnlTitle pnlrfstrccltitle = new PnlTitle(FlowLayout.LEFT, "Ref. Début", Color.blue, 20);
        pnlrfstrccltitle.mkView();
        add(pnlrfstrccltitle);

        PnlTitle pnlrfendccltitle = new PnlTitle(FlowLayout.LEFT, "Ref. Fin", Color.blue, 20);
        pnlrfendccltitle.mkView();
        add(pnlrfendccltitle, "wrap");

        add(new JLabel(drawdate));
        add(new JLabel(startdate));
        add(new JLabel(enddate));
        add(new JLabel(refstartdate));
        add(new JLabel(refenddate), "wrap");

        PnlTitle pnlocc1title = new PnlTitle(FlowLayout.LEFT, "Occ. 1", Color.yellow, 20);
        pnlocc1title.mkView();
        add(pnlocc1title);
        PnlTitle pnlocc2title = new PnlTitle(FlowLayout.LEFT, "Occ. 2", Color.yellow, 20);
        pnlocc2title.mkView();
        add(pnlocc2title);
        PnlTitle pnlocc3title = new PnlTitle(FlowLayout.LEFT, "Occ. 3", Color.yellow, 20);
        pnlocc3title.mkView();
        add(pnlocc3title);
        PnlTitle pnlocc4title = new PnlTitle(FlowLayout.LEFT, "Occ. 4", Color.yellow, 20);
        pnlocc4title.mkView();
        add(pnlocc4title);
        PnlTitle pnlocc5title = new PnlTitle(FlowLayout.LEFT, "Occ. 5", Color.yellow, 20);
        pnlocc5title.mkView();
        add(pnlocc5title, "wrap");
/*
        add(new JLabel( (schema[0]<10)? "0" + schema[0]:
                                         "" + schema[0]));
        add(new JLabel( (schema[1]<10)? "0" + schema[1]:
                                         "" + schema[1]));
        add(new JLabel( (schema[2]<10)? "0" + schema[2]:
                                         "" + schema[2]));
        add(new JLabel( (schema[3]<10)? "0" + schema[3]:
                                         "" + schema[3]));
        add(new JLabel( (schema[4]<10)? "0" + schema[4]:
                                         "" + schema[4]));
*/

        for(int i=0; i<abttn.length; i++) {
            abttn[i] = new JButton( (schema[i]<10)? "0" + schema[i]:
                                                    ""  + schema[i]);
            abttn[i].addActionListener(this);
            add(abttn[i]);
        }

        PnlTitle pnlweighttitle = new PnlTitle(FlowLayout.LEFT, "Poids", Color.yellow, 20);
        pnlweighttitle.mkView();
        add(pnlweighttitle, "wrap");

        add(new JLabel("" + schemaweight));
    }

    public void removeButtonActionListener() {
        for(int i=0; i<abttn.length; i++)
            abttn[i].removeActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ctrlr.reset(this);
        ctrlr.selectSchema(this, Integer.parseInt( ((JButton) e.getSource()).getText()));
    }
}

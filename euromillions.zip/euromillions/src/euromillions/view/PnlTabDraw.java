/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions.view;

import euromillions.view.drawcycles.PnlDrawList;
import euromillions.view.drawcycles.PnlDrawListFooter;
import euromillions.controller.Controller;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JPanel;

/**
 *
 * @author Stéphane
 */
public class PnlTabDraw extends JPanel {

private final Controller ctrlr;

private final GridBagLayout grdbglyt;

private final PnlDrawList         pnlTirageList;
private final PnlDrawListFooter   pnlTirageListFooter;


public PnlTabDraw(Controller _ctrlr) {

    ctrlr = _ctrlr;
    grdbglyt = new GridBagLayout();
    GridBagConstraints  grdBgCstrts =   new GridBagConstraints();

    pnlTirageList   = new PnlDrawList(ctrlr);
    pnlTirageList.mkView();
    pnlTirageListFooter =   new PnlDrawListFooter(ctrlr);

    setLayout(grdbglyt);

        grdBgCstrts.insets      = new Insets(0,0,0,0);
        grdBgCstrts.ipadx       = 0;
        grdBgCstrts.ipady       = 0;

        grdBgCstrts.gridx       = 0;
        grdBgCstrts.gridy       = 0;
        grdBgCstrts.gridwidth   = 1;
        grdBgCstrts.gridheight  = 1;
        grdBgCstrts.weightx     = 0.35;
        grdBgCstrts.weighty     = 1;
        //grdBgCstrt.anchor       = GridBagConstraints.FIRST_LINE_START;
        grdBgCstrts.fill        = GridBagConstraints.BOTH;
        add(pnlTirageList, grdBgCstrts);

        grdBgCstrts.gridx       = 0;
        grdBgCstrts.gridy       = 1;
        grdBgCstrts.gridwidth   = 2;
        grdBgCstrts.gridheight  = 1;
        grdBgCstrts.weightx     = 1;
        grdBgCstrts.weighty     = 0;
        grdBgCstrts.anchor      = GridBagConstraints.LAST_LINE_START;
        grdBgCstrts.fill        = GridBagConstraints.HORIZONTAL;
        add(pnlTirageListFooter, grdBgCstrts);

    }
}

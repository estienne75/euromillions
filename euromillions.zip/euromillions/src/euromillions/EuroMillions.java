/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package euromillions;

import euromillions.controller.Controller;
import euromillions.controller.ControllerView;
import euromillions.model.Model;
import euromillions.model.ModelView;
import java.awt.Color;
import javax.swing.SwingUtilities;


/**
 *
 * @author ©Stéphane Delpech (stephane.delpech@sdelpech.fr)
 */
public class EuroMillions {
    private final Model     mdl;
    private final ModelView mdlvw;
    private final Controller ctrlr;
    private final ControllerView ctrlrvw;

    /**
     *
     */
    public static final Color SELECTED_COLOR = Color.yellow;

    public EuroMillions() {
        mdlvw   = new ModelView();
        mdl     = new Model(mdlvw);

        ctrlr   = new Controller(mdl);
        ctrlrvw = new ControllerView(mdlvw, ctrlr);
        ctrlr.setControllerView(ctrlrvw);
        ctrlrvw.makeIHM();

        ctrlr.getGrouppsCycle(this);
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EuroMillions euromils = new EuroMillions();
        });
    }
}
